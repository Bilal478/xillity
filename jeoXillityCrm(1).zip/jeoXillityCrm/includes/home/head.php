<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;700&amp;family=Open+Sans:wght@400;700&amp;display=swap" rel="stylesheet">
<link rel="stylesheet" href="./assetshome/css/maincss.php">
<title><?echo $g_projectTitle?></title>
<link rel="shortcut icon" href="<?echo $g_modules_global['faviconlogo']?>" />
	
<style>
    .site-footer {
        padding: 1rem 0;
    }
</style>