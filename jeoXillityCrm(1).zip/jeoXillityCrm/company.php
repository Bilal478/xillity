<?require("./global.php");?>
<!DOCTYPE html>

<html lang="en" data-menu="vertical" data-nav-size="nav-default">

<head>


<?include("./includes/views/head2.php");?>

</head>

<body class="body-padding body-p-top">

    <!-- preloader start -->

    <div class="preloader d-none">

        <div class="loader">

            <span></span>

            <span></span>

            <span></span>

        </div>

    </div>

    <!-- preloader end -->



    <!-- header start -->

    <?include("./includes/views/navbar.php"); ?>

    <!-- header end -->



    <!-- profile right sidebar start -->

    <?include("./includes/views/rightsidebar.php"); ?>

    <!-- right sidebar end -->



    <!-- main sidebar start -->

    <?include("./includes/views/leftmenu2.php"); ?>

    <!-- main sidebar end -->



    <!-- main content start -->

    <div class="main-content">

        <div class="row">

            <div class="col-12">

                <div class="panel">

                    <div class="panel-header">

                        <h5>Companies</h5>

                        <div class="btn-box d-flex gap-2">

                            <div id="tableSearch"></div>

                            <button class="btn btn-sm btn-icon btn-outline-primary"><i class="fa-light fa-arrows-rotate"></i></button>

                            <div class="digi-dropdown dropdown">

                                <button class="btn btn-sm btn-icon btn-outline-primary" data-bs-toggle="dropdown" data-bs-auto-close="outside" aria-expanded="false"><i class="fa-regular fa-ellipsis-vertical"></i></button>

                                <ul class="digi-dropdown-menu dropdown-menu">

                                    <li class="dropdown-title">Show Table Title</li>

                                    <li>

                                        <div class="form-check">

                                            <input class="form-check-input" type="checkbox" id="showCompany" checked>

                                            <label class="form-check-label" for="showCompany">

                                                Company

                                            </label>

                                        </div>

                                    </li>

                                    <li>

                                        <div class="form-check">

                                            <input class="form-check-input" type="checkbox" id="showAddress" checked>

                                            <label class="form-check-label" for="showAddress">

                                                Address

                                            </label>

                                        </div>

                                    </li>

                                    <li>

                                        <div class="form-check">

                                            <input class="form-check-input" type="checkbox" id="showEmail" checked>

                                            <label class="form-check-label" for="showEmail">

                                                Email

                                            </label>

                                        </div>

                                    </li>

                                    <li>

                                        <div class="form-check">

                                            <input class="form-check-input" type="checkbox" id="showPhone" checked>

                                            <label class="form-check-label" for="showPhone">

                                                Phone

                                            </label>

                                        </div>

                                    </li>

                                    <li>

                                        <div class="form-check">

                                            <input class="form-check-input" type="checkbox" id="showContactPerson" checked>

                                            <label class="form-check-label" for="showContactPerson">

                                                Contact Person

                                            </label>

                                        </div>

                                    </li>

                                    <li>

                                        <div class="form-check">

                                            <input class="form-check-input" type="checkbox" id="showStatus" checked>

                                            <label class="form-check-label" for="showStatus">

                                                Status

                                            </label>

                                        </div>

                                    </li>

                                    <li class="dropdown-title pb-1">Showing</li>

                                    <li>

                                        <div class="input-group">

                                            <input type="number" class="form-control form-control-sm w-50" value="10">

                                            <button class="btn btn-sm btn-primary w-50">Apply</button>

                                        </div>

                                    </li>

                                </ul>

                            </div>

                        </div>

                    </div>

                    <div class="panel-body">

                        <div class="table-filter-option">

                            <div class="row g-3">

                                <div class="col-xl-10 col-9 col-xs-12">

                                    <div class="row g-3">

                                        <div class="col">

                                            <form class="row g-2">

                                                <div class="col">

                                                    <select class="form-control form-control-sm" data-placeholder="Bulk action">

                                                        <option value="">Bulk action</option>

                                                        <option value="0">Move to trash</option>

                                                    </select>

                                                </div>

                                                <div class="col">

                                                    <button class="btn btn-sm btn-primary w-100">Apply</button>

                                                </div>

                                            </form>

                                        </div>

                                    </div>

                                </div>

                                <div class="col-xl-2 col-3 col-xs-12 d-flex justify-content-end">

                                    <div id="employeeTableLength"></div>

                                </div>

                            </div>

                        </div>

                        <table class="table table-dashed table-hover digi-dataTable company-table table-striped" id="companyTable">

                            <thead>

                                <tr>

                                    <th class="no-sort">

                                        <div class="form-check">

                                            <input class="form-check-input" type="checkbox" id="markAllCompany">

                                        </div>

                                    </th>

                                    <th>Company</th>

                                    <th>Address</th>

                                    <th>Email</th>

                                    <th>Phone</th>

                                    <th>Contact Person</th>

                                    <th>Status</th>

                                </tr>

                            </thead>

                            <tbody>

                                <tr>

                                    <td>

                                        <div class="form-check">

                                            <input class="form-check-input" type="checkbox">

                                        </div>

                                    </td>

                                    <td>Strongbod</td>

                                    <td>38 Roker Terrace LANTON TD8 5YS</td>

                                    <td>info@example.com</td>

                                    <td>+1 23 456 789</td>

                                    <td>Isaac Davis</td>

                                    <td>

                                        <div class="form-check form-switch">

                                            <input class="form-check-input" type="checkbox" role="switch" checked>

                                        </div>

                                    </td>

                                </tr>

                                <tr>

                                    <td>

                                        <div class="form-check">

                                            <input class="form-check-input" type="checkbox">

                                        </div>

                                    </td>

                                    <td>Strongbod</td>

                                    <td>38 Roker Terrace LANTON TD8 5YS</td>

                                    <td>info@example.com</td>

                                    <td>+1 23 456 789</td>

                                    <td>Isaac Davis</td>

                                    <td>

                                        <div class="form-check form-switch">

                                            <input class="form-check-input" type="checkbox" role="switch" checked>

                                        </div>

                                    </td>

                                </tr>

                                <tr>

                                    <td>

                                        <div class="form-check">

                                            <input class="form-check-input" type="checkbox">

                                        </div>

                                    </td>

                                    <td>Strongbod</td>

                                    <td>38 Roker Terrace LANTON TD8 5YS</td>

                                    <td>info@example.com</td>

                                    <td>+1 23 456 789</td>

                                    <td>Isaac Davis</td>

                                    <td>

                                        <div class="form-check form-switch">

                                            <input class="form-check-input" type="checkbox" role="switch" checked>

                                        </div>

                                    </td>

                                </tr>

                                <tr>

                                    <td>

                                        <div class="form-check">

                                            <input class="form-check-input" type="checkbox">

                                        </div>

                                    </td>

                                    <td>Strongbod</td>

                                    <td>38 Roker Terrace LANTON TD8 5YS</td>

                                    <td>info@example.com</td>

                                    <td>+1 23 456 789</td>

                                    <td>Isaac Davis</td>

                                    <td>

                                        <div class="form-check form-switch">

                                            <input class="form-check-input" type="checkbox" role="switch" checked>

                                        </div>

                                    </td>

                                </tr>

                                <tr>

                                    <td>

                                        <div class="form-check">

                                            <input class="form-check-input" type="checkbox">

                                        </div>

                                    </td>

                                    <td>Strongbod</td>

                                    <td>38 Roker Terrace LANTON TD8 5YS</td>

                                    <td>info@example.com</td>

                                    <td>+1 23 456 789</td>

                                    <td>Isaac Davis</td>

                                    <td>

                                        <div class="form-check form-switch">

                                            <input class="form-check-input" type="checkbox" role="switch" checked>

                                        </div>

                                    </td>

                                </tr>

                                <tr>

                                    <td>

                                        <div class="form-check">

                                            <input class="form-check-input" type="checkbox">

                                        </div>

                                    </td>

                                    <td>Strongbod</td>

                                    <td>38 Roker Terrace LANTON TD8 5YS</td>

                                    <td>info@example.com</td>

                                    <td>+1 23 456 789</td>

                                    <td>Isaac Davis</td>

                                    <td>

                                        <div class="form-check form-switch">

                                            <input class="form-check-input" type="checkbox" role="switch" checked>

                                        </div>

                                    </td>

                                </tr>

                                <tr>

                                    <td>

                                        <div class="form-check">

                                            <input class="form-check-input" type="checkbox">

                                        </div>

                                    </td>

                                    <td>Strongbod</td>

                                    <td>38 Roker Terrace LANTON TD8 5YS</td>

                                    <td>info@example.com</td>

                                    <td>+1 23 456 789</td>

                                    <td>Isaac Davis</td>

                                    <td>

                                        <div class="form-check form-switch">

                                            <input class="form-check-input" type="checkbox" role="switch" checked>

                                        </div>

                                    </td>

                                </tr>

                                <tr>

                                    <td>

                                        <div class="form-check">

                                            <input class="form-check-input" type="checkbox">

                                        </div>

                                    </td>

                                    <td>Strongbod</td>

                                    <td>38 Roker Terrace LANTON TD8 5YS</td>

                                    <td>info@example.com</td>

                                    <td>+1 23 456 789</td>

                                    <td>Isaac Davis</td>

                                    <td>

                                        <div class="form-check form-switch">

                                            <input class="form-check-input" type="checkbox" role="switch" checked>

                                        </div>

                                    </td>

                                </tr>

                                <tr>

                                    <td>

                                        <div class="form-check">

                                            <input class="form-check-input" type="checkbox">

                                        </div>

                                    </td>

                                    <td>Strongbod</td>

                                    <td>38 Roker Terrace LANTON TD8 5YS</td>

                                    <td>info@example.com</td>

                                    <td>+1 23 456 789</td>

                                    <td>Isaac Davis</td>

                                    <td>

                                        <div class="form-check form-switch">

                                            <input class="form-check-input" type="checkbox" role="switch" checked>

                                        </div>

                                    </td>

                                </tr>

                                <tr>

                                    <td>

                                        <div class="form-check">

                                            <input class="form-check-input" type="checkbox">

                                        </div>

                                    </td>

                                    <td>Strongbod</td>

                                    <td>38 Roker Terrace LANTON TD8 5YS</td>

                                    <td>info@example.com</td>

                                    <td>+1 23 456 789</td>

                                    <td>Isaac Davis</td>

                                    <td>

                                        <div class="form-check form-switch">

                                            <input class="form-check-input" type="checkbox" role="switch" checked>

                                        </div>

                                    </td>

                                </tr>

                                <tr>

                                    <td>

                                        <div class="form-check">

                                            <input class="form-check-input" type="checkbox">

                                        </div>

                                    </td>

                                    <td>Strongbod</td>

                                    <td>38 Roker Terrace LANTON TD8 5YS</td>

                                    <td>info@example.com</td>

                                    <td>+1 23 456 789</td>

                                    <td>Isaac Davis</td>

                                    <td>

                                        <div class="form-check form-switch">

                                            <input class="form-check-input" type="checkbox" role="switch" checked>

                                        </div>

                                    </td>

                                </tr>

                                <tr>

                                    <td>

                                        <div class="form-check">

                                            <input class="form-check-input" type="checkbox">

                                        </div>

                                    </td>

                                    <td>Strongbod</td>

                                    <td>38 Roker Terrace LANTON TD8 5YS</td>

                                    <td>info@example.com</td>

                                    <td>+1 23 456 789</td>

                                    <td>Isaac Davis</td>

                                    <td>

                                        <div class="form-check form-switch">

                                            <input class="form-check-input" type="checkbox" role="switch" checked>

                                        </div>

                                    </td>

                                </tr>

                            </tbody>

                        </table>

                        <div class="table-bottom-control"></div>

                    </div>

                </div>

            </div>

        </div>



        <!-- footer start -->

        <?include("./includes/views/footer.php"); ?>

        <!-- footer end -->

    </div>

    <!-- main content end -->

    

    <?include("./includes/views/footerjs.php"); ?>

</body>

</html>