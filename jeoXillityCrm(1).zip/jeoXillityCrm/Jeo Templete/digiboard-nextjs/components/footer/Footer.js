import React from 'react'

const Footer = () => {
  return (
    <div className="footer">
        <p>Copyright© 2023 All Rights Reserved By <span className="text-primary">Digiboard</span></p>
    </div>
  )
}

export default Footer