import React from 'react'

const SaveBtn = () => {
  return (
    <div className="col-12 d-flex justify-content-end">
        <button className="btn btn-sm btn btn-success">Save Employee</button>
    </div>
  )
}

export default SaveBtn