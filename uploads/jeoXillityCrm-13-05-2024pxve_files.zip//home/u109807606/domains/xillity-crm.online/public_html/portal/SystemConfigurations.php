<? require("./global.php");
// $u_id = $_GET['id'];
$primaryTableName = "systemConfigurations";

array(
    "profile_pic" => ["input", "", "", "file"],
    "company" => ["input", "", "", "text"],
    "email" => ["input", "", "", "email"],
    "about" => ["input", "", "", "text"],
    "number" => ["input", "", "", "number"],
    "role" => ["input", "", "", "text"],
    "enable_disable" => ["input", "", "", "text"],
    "gmail" => ["input", "", "", "text"],
    "phone_number" => ["input", "", "", "number"],
    "company_mail" => ["input", "", "", "text"],
    "address" => ["input", "", "", "text"],
    "facebook_link" => ["input", "", "", "text"],
    "twitter_link" => ["input", "", "", "text"],
    "linkedin_link" => ["input", "", "", "text"],
    "instagram_link" => ["input", "", "", "text"],
    "youtube_link" => ["input", "", "", "text"],
    "pinterest_link" => ["input", "", "", "text"],
    "current_password" => ["input", "", "", "password"],
    "new_password" => ["input", "", "", "password"],
    "confirm_password" => ["input", "", "", "password"],
);

if (isset($_POST['create_record_package'])) {
    // Sanitize inputs and retrieve form data
    $actionId = mysqli_real_escape_string($con, $_POST['actionId']);
    $company = mysqli_real_escape_string($con, $_POST['company']);
    $email = mysqli_real_escape_string($con, $_POST['email']);
    $about = mysqli_real_escape_string($con, $_POST['about']);
    $number = mysqli_real_escape_string($con, $_POST['number']);
    $role = mysqli_real_escape_string($con, $_POST['role']);
    $enable_disable = mysqli_real_escape_string($con, $_POST['enable_disable']);
    $gmail = mysqli_real_escape_string($con, $_POST['gmail']);
    $phone_number = mysqli_real_escape_string($con, $_POST['phone_number']);
    $company_mail = mysqli_real_escape_string($con, $_POST['company_mail']);
    $address = mysqli_real_escape_string($con, $_POST['address']);
    $facebook_link = mysqli_real_escape_string($con, $_POST['facebook_link']);
    $twitter_link = mysqli_real_escape_string($con, $_POST['twitter_link']);
    $linkedin_link = mysqli_real_escape_string($con, $_POST['linkedin_link']);
    $instagram_link = mysqli_real_escape_string($con, $_POST['instagram_link']);
    $youtube_link = mysqli_real_escape_string($con, $_POST['youtube_link']);
    $pinterest_link = mysqli_real_escape_string($con, $_POST['pinterest_link']);
    $current_password = mysqli_real_escape_string($con, $_POST['current_password']);
    $new_password = mysqli_real_escape_string($con, $_POST['new_password']);
    $confirm_password = mysqli_real_escape_string($con, $_POST['confirm_password']);

    // Define or assign values to $timeAdded and $session_userId variables

    if ($actionId == "") {
        $id = generateRandomString();
        $actionId = $id;
        $query = "INSERT INTO jeoXillityCrm_systemConfigurations (id, company, email, about, number, role, enable_disable, gmail, phone_number, company_mail, address, facebook_link, twitter_link, linkedin_link, instagram_link, youtube_link, pinterest_link, current_password, new_password, confirm_password, timeAdded, userId) VALUES ('$id', '$company', '$email', '$about', '$number', '$role', '$enable_disable', '$gmail', '$phone_number', '$company_mail', '$address', '$facebook_link', '$twitter_link', '$linkedin_link', '$instagram_link', '$youtube_link', '$pinterest_link', '$current_password', '$new_password', '$confirm_password', '$timeAdded', '$session_userId')";
    } else {
        $query = "UPDATE jeoXillityCrm_systemConfigurations SET company='$company', email='$email', about='$about', number='$number', role='$role', enable_disable='$enable_disable', gmail='$gmail', phone_number='$phone_number', company_mail='$company_mail', address='$address', facebook_link='$facebook_link', twitter_link='$twitter_link', linkedin_link='$linkedin_link', instagram_link='$instagram_link', youtube_link='$youtube_link', pinterest_link='$pinterest_link', current_password='$current_password', new_password='$new_password', confirm_password='$confirm_password' WHERE id='$actionId'";
    }

    mysqli_query($con, $query);

    // Handle profile picture upload if needed
    $profile_pic = storeFile($_FILES['profile_pic']);
    if ($profile_pic != "") {
        $query = "UPDATE jeoXillityCrm_systemConfigurations SET profile_pic='$profile_pic' WHERE id='$actionId'";
        mysqli_query($con, $query);
    }

    // Redirect after processing the form
    header("Location: ?" . generateUrlParams_return(["m" => "Data was saved successfully!", "type" => "success"]));
    exit();
}

if (isset($_GET['delete-record'])) {
    $id = escape($_GET['delete-record']);
    $query = "delete from jeoXillityCrm_systemConfigurations where id='$id'";
    runQuery($query);
}


if (isset($_GET['delete-record'])) {
    $id = escape($_GET['delete-record']);
    $query = "delete from jeoXillityCrm_systemConfigurations where id='$id'";
    runQuery($query);
}

// Assuming $con is your database connection object

// $u_id = mysqli_real_escape_string($con, $_GET['id']);

// // Check if form is submitted for updating user data
// if (isset($_POST['create_record_package'])) {
//     // Get values from form
//     $company_name = mysqli_real_escape_string($con, $_POST['company']);
//     $email = mysqli_real_escape_string($con, $_POST['email']);
//     $about = mysqli_real_escape_string($con, $_POST['about']);
//     $phone = mysqli_real_escape_string($con, $_POST['phone']);
//     $role = mysqli_real_escape_string($con, $_POST['role']);
//     $status = mysqli_real_escape_string($con, $_POST['status']);
//     $gmail = mysqli_real_escape_string($con, $_POST['email']);
//     $alternative_phone = mysqli_real_escape_string($con, $_POST['alternative_phone']);
//     $website = mysqli_real_escape_string($con, $_POST['website']);
//     $address = mysqli_real_escape_string($con, $_POST['address']);
//     $facebook_link = mysqli_real_escape_string($con, $_POST['facebook_link']);
//     $twitter_link = mysqli_real_escape_string($con, $_POST['twitter_link']);
//     $linkedin_link = mysqli_real_escape_string($con, $_POST['linkedin_link']);
//     $instagram_link = mysqli_real_escape_string($con, $_POST['instagram_link']);
//     $youtube_link = mysqli_real_escape_string($con, $_POST['youtube_link']);
//     $pinterest_link = mysqli_real_escape_string($con, $_POST['pinterest_link']);

//     // Update user data
//     $sql_update = "UPDATE jeoXillityCrm_users SET company='$company_name', email='$email', description='$about', phone='$phone', role='$role', status='$status', email='$gmail', alternative_phone='$alternative_phone', website='$website', address='$address', facebook_link='$facebook_link', twitter_link='$twitter_link', linkedin_link='$linkedin_link', insta_link='$instagram_link', youtube_link='$youtube_link', pinterest_link='$pinterest_link' WHERE id='$u_id'";

//     if (mysqli_query($con, $sql_update)) {
//         header("Location: all-employee.php?m=Data was saved successfully!&type=success");
//         exit(); // Ensure no further code execution after redirection
//     } else {
//         echo "Error updating record: " . mysqli_error($con);
//     }
// }

// if (isset($_POST['create_record_package1'])) {
//     $current_password = mysqli_real_escape_string($con, $_POST['current_password']);
//     $new_password = mysqli_real_escape_string($con, $_POST['new_password']);
//     $confirm_password = mysqli_real_escape_string($con, $_POST['confirm_password']);
//     $u_id = mysqli_real_escape_string($con, $_GET['id']); 
//     if ($new_password !== $confirm_password) {
//         echo "New password and confirm password do not match.";
//         exit();
//     }
//     $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
//     $sql_update_password = "UPDATE jeoXillityCrm_users SET password='$hashed_password' WHERE id='$u_id'";
//     if (mysqli_query($con, $sql_update_password)) {
//         header("Location: all-employee.php?id=$u_id&m=Password updated successfully!&type=success");
//         exit(); 
//     } else {
//         echo "Error updating password: " . mysqli_error($con);
//     }
// } else {
//     // echo "Form submission not detected.";
// }
?>

<!DOCTYPE html>
<html lang="en" data-menu="vertical" data-nav-size="nav-default">

<head><? include("./includes/views/head2.php"); ?></head>

<body class="body-padding body-p-top">
    <!-- preloader start -->
    <div class="preloader d-none">
        <div class="loader">
            <span></span>
            <span></span>
            <span></span>
        </div>
    </div>
    <!-- preloader end -->
    <!-- header start -->
    <? include("./includes/views/navbar.php"); ?>
    <!-- header end -->
    <!-- profile right sidebar start -->
    <? include("./includes/views/rightsidebar.php"); ?>
    <!-- right sidebar end -->
    <!-- main sidebar start -->
    <? include("./includes/views/leftmenu2.php"); ?>
    <!-- main sidebar end -->
    <!-- main content start -->
    <div class="main-content">
        <div class="dashboard-breadcrumb mb-25">
            <h2>System Configurations</h2>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="panel">
                    <div class="panel-header">
                        <nav>
                            <div class="btn-box d-flex flex-wrap gap-1" id="nav-tab" role="tablist">
                                <button class="btn btn-sm btn-outline-primary active" id="nav-edit-profile-tab" data-bs-toggle="tab" data-bs-target="#nav-edit-profile" type="button" role="tab" aria-controls="nav-edit-profile" aria-selected="true">Company Details</button>
                                <button class="btn btn-sm btn-outline-primary" id="nav-change-password-tab" data-bs-toggle="tab" data-bs-target="#nav-change-password" type="button" role="tab" aria-controls="nav-change-password" aria-selected="false">Gateway</button>
                                <button class="btn btn-sm btn-outline-primary" id="nav-other-settings-tab" data-bs-toggle="tab" data-bs-target="#nav-other-settings" type="button" role="tab" aria-controls="nav-other-settings" aria-selected="false">Permissions</button>
                            </div>
                        </nav>
                    </div>
                    <div class="panel-body">
                        <div class="tab-content profile-edit-tab" id="nav-tabContent">
                            <div class="tab-pane fade show active" id="nav-edit-profile" role="tabpanel" aria-labelledby="nav-edit-profile-tab" tabindex="0">
                                <form method="Post" enctype="multipart/form-data">
                                    <div class="profile-edit-tab-title">
                                        <h6>Company Information</h6>
                                    </div>
                                    <!--/////////////////////// Tittle= Company Information-->
                                    <div class="public-information mb-25">
                                        <div class="row g-4">
                                            <div class="col-md-3">
                                                <div class="admin-profile">
                                                    <div class="image-wrap">
                                                        <div class="part-img rounded-circle overflow-hidden">
                                                            <img id="profilePicPreview" src="./updates/" alt="">
                                                            <input type="file" id="profile_pic" name="profile_pic" class="form-control d-none">
                                                        </div>
                                                        <span id="selectedFileName"></span> <!-- Span to display the selected file name -->
                                                        <button class="image-change"><i class="fa-light fa-camera"></i></button>
                                                    </div>
                                                    <!--////////////////////////////**Tittle**= USER PROFILE AND DEPARTMENT-->
                                                    <span class="admin-name">Name</span>
                                                    <span class="admin-role">Department Class Here</span>
                                                </div>
                                            </div>
                                            <div class="col-md-9">
                                                <div class="row g-3">
                                                    <div class="col-sm-6">
                                                        <div class="input-group">
                                                            <span class="input-group-text"><i class="fa-light fa-user"></i></span>
                                                            <input type="text" class="form-control" name="company" placeholder="Company Name">
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-6">
                                                        <div class="input-group">
                                                            <span class="input-group-text"><i class="fa-light fa-at"></i></span>
                                                            <input type="text" class="form-control" name="email" placeholder="Username">
                                                        </div>
                                                    </div>
                                                    <div class="col-12">
                                                        <textarea class="form-control h-150-p" name="about" placeholder="Description"></textarea>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="profile-edit-tab-title">
                                        <h6>Private Information</h6>
                                    </div>
                                    <div class="private-information mb-25">
                                        <div class="row g-3">
                                            <div class="col-md-4 col-sm-6">
                                                <div class="input-group">
                                                    <span class="input-group-text"><i class="fa-light fa-user"></i></span>
                                                    <input type="text" class="form-control" name="number" placeholder="Unique ID">
                                                </div>
                                            </div>
                                            <div class="col-md-4 col-sm-6">
                                                <div class="input-group flex-nowrap">
                                                    <span class="input-group-text"><i class="fa-light fa-user-tie"></i></span>
                                                    <select class="form-control select-search" name="role" data-placeholder="Role">
                                                        <option></option>
                                                        <option value="admin">Admin</option>
                                                        <option value="manager">Manager</option>
                                                        <option value="project_manager">Project Manager</option>
                                                        <option value="managing">Managing Director</option>
                                                        <option value="chairman">Chairman</option>
                                                        <option value="graphic_designer">Graphic Designer</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-4 col-sm-6">
                                                <div class="input-group flex-nowrap">
                                                    <span class="input-group-text"><i class="fa-light fa-circle-check"></i></span>
                                                    <select class="form-control" name="enable_disable" data-placeholder="Status">
                                                        <option></option>
                                                        <option value="enable">Enable</option>
                                                        <option value="disable">Disable</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-4 col-sm-6">
                                                <div class="input-group">
                                                    <span class="input-group-text"><i class="fa-light fa-envelope"></i></span>
                                                    <input type="email" class="form-control" name="gmail" placeholder="Email">
                                                </div>
                                            </div>
                                            <div class="col-md-4 col-sm-6">
                                                <div class="input-group">
                                                    <span class="input-group-text"><i class="fa-light fa-phone"></i></span>
                                                    <input type="tel" class="form-control" name="phone_number" placeholder="Phone">
                                                </div>
                                            </div>
                                            <div class="col-md-4 col-sm-6">
                                                <div class="input-group">
                                                    <span class="input-group-text"><i class="fa-light fa-globe"></i></span>
                                                    <input type="url" class="form-control" name="company_mail" placeholder="Website">
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <textarea class="form-control h-100-p" name="address" placeholder="Address"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="profile-edit-tab-title">
                                        <h6>Social Information</h6>
                                    </div>
                                    <div class="social-information">
                                        <div class="row g-3">
                                            <div class="col-sm-6">
                                                <div class="input-group">
                                                    <span class="input-group-text"><i class="fa-brands fa-facebook-f"></i></span>
                                                    <input type="url" class="form-control" name="facebook_link" placeholder="Facebook">
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="input-group">
                                                    <span class="input-group-text"><i class="fa-brands fa-twitter"></i></span>
                                                    <input type="url" class="form-control" name="twitter_link" placeholder="Twitter">
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="input-group">
                                                    <span class="input-group-text"><i class="fa-brands fa-linkedin-in"></i></span>
                                                    <input type="url" class="form-control" name="linkedin_link" placeholder="Linkedin">
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="input-group">
                                                    <span class="input-group-text"><i class="fa-brands fa-instagram"></i></span>
                                                    <input type="url" class="form-control" name="instagram_link" placeholder="Instagram">
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="input-group">
                                                    <span class="input-group-text"><i class="fa-brands fa-youtube"></i></span>
                                                    <input type="url" class="form-control" name="youtube_link" placeholder="Youtube">
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="input-group">
                                                    <span class="input-group-text"><i class="fa-brands fa-pinterest-p"></i></span>
                                                    <input type="url" class="form-control" name="pinterest_link" placeholder="Pinterest">
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <button type="submit" name="create_record_package" value="Confirm" class="btn btn-primary">Save Changes</button>
                                                <!-- <button type="submit" class="btn btn-primary">Save Changes</button> -->
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <div class="tab-pane fade" id="nav-change-password" role="tabpanel" aria-labelledby="nav-change-password-tab" tabindex="0">
                                <form>
                                    <div class="profile-edit-tab-title">
                                        <h6>Change Password</h6>
                                    </div>
                                    <div class="social-information">
                                        <div class="row g-3">
                                            <div class="col-12">
                                                <div class="input-group">
                                                    <span class="input-group-text"><i class="fa-light fa-lock"></i></span>
                                                    <input type="password" name="current_password" class="form-control" placeholder="Current Password">
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="input-group">
                                                    <span class="input-group-text"><i class="fa-light fa-lock"></i></span>
                                                    <input type="password" name="new_password" class="form-control" placeholder="New Password">
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="input-group">
                                                    <span class="input-group-text"><i class="fa-light fa-lock"></i></span>
                                                    <input type="password" name="confirm_password" class="form-control" placeholder="Confirm Password">
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <!-- <input type="submit" name="create_record_package" value="Confirm" class="btn btn-primary"> -->
                                                <button type="submit" name="create_record_package1" value="Confirm" class="btn btn-primary">Save Changes</button>
                                            </div>
                                        </div>
                                    </div>

                                </form>
                            </div>
                            <div class="tab-pane fade" id="nav-other-settings" role="tabpanel" aria-labelledby="nav-other-settings-tab" tabindex="0">
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="profile-edit-tab-title">
                                            <h6>Activity Email Settings</h6>
                                        </div>
                                        <div class="activity-email-settings">
                                            <form>
                                                <div class="form-check mb-15">
                                                    <input class="form-check-input" type="checkbox" value="" id="activity-email-settings-1">
                                                    <label class="form-check-label" for="activity-email-settings-1">
                                                        Someone adds you as a connection
                                                    </label>
                                                </div>
                                                <div class="form-check mb-15">
                                                    <input class="form-check-input" type="checkbox" value="" id="activity-email-settings-2">
                                                    <label class="form-check-label" for="activity-email-settings-2">
                                                        you're sent a direct message
                                                    </label>
                                                </div>
                                                <div class="form-check mb-15">
                                                    <input class="form-check-input" type="checkbox" value="" id="activity-email-settings-3">
                                                    <label class="form-check-label" for="activity-email-settings-3">
                                                        New membership approval
                                                    </label>
                                                </div>
                                                <div class="form-check mb-15">
                                                    <input class="form-check-input" type="checkbox" value="" id="activity-email-settings-4">
                                                    <label class="form-check-label" for="activity-email-settings-4">
                                                        Send Copy To Personal Email
                                                    </label>
                                                </div>
                                                <div class="form-check mb-15">
                                                    <input class="form-check-input" type="checkbox" value="" id="activity-email-settings-5">
                                                    <label class="form-check-label" for="activity-email-settings-5">
                                                        Tips on getting more out of PCT-themes
                                                    </label>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="profile-edit-tab-title">
                                            <h6>User Promisions </h6>
                                        </div>
                                        <div class="product-email-settings">
                                            <form>
                                                <div class="form-check mb-15">
                                                    <input class="form-check-input" type="checkbox" value="" id="product-email-settings-1">
                                                    <label class="form-check-label" for="product-email-settings-1">
                                                        User Can edit Ticket timestamp entry
                                                    </label>
                                                </div>
                                                <div class="form-check mb-15">
                                                    <input class="form-check-input" type="checkbox" value="" id="product-email-settings-1">
                                                    <label class="form-check-label" for="product-email-settings-1">
                                                        User can creat New locations
                                                    </label>
                                                </div>
                                                <div class="form-check mb-15">
                                                    <input class="form-check-input" type="checkbox" value="" id="product-email-settings-2">
                                                    <label class="form-check-label" for="product-email-settings-2">
                                                        User can edit Task
                                                    </label>
                                                </div>
                                                <div class="form-check mb-15">
                                                    <input class="form-check-input" type="checkbox" value="" id="product-email-settings-3">
                                                    <label class="form-check-label" for="product-email-settings-3">
                                                        User can edit schedule
                                                    </label>
                                                </div>
                                                <div class="form-check mb-15">
                                                    <input class="form-check-input" type="checkbox" value="" id="product-email-settings-4">
                                                    <label class="form-check-label" for="product-email-settings-4">
                                                        Send Copy To Personal Email
                                                    </label>
                                                </div>
                                                <!--/////////////////////////////////////Sub Title= Page Access-->
                                                <div class="profile-edit-tab-title">
                                                    <h6>User Access </h6>
                                                </div>
                                                <div class="form-check mb-15">
                                                    <input class="form-check-input" type="checkbox" value="" id="product-email-settings-5">
                                                    <label class="form-check-label" for="product-email-settings-5">
                                                        DashBoard Access
                                                    </label>
                                                </div>
                                                <div class="form-check mb-15">
                                                    <input class="form-check-input" type="checkbox" value="" id="product-email-settings-5">
                                                    <label class="form-check-label" for="product-email-settings-5">
                                                        Ticket Access
                                                    </label>
                                                </div>
                                                <div class="form-check mb-15">
                                                    <input class="form-check-input" type="checkbox" value="" id="product-email-settings-5">
                                                    <label class="form-check-label" for="product-email-settings-5">
                                                        Task Access
                                                    </label>
                                                </div>
                                                <div class="form-check mb-15">
                                                    <input class="form-check-input" type="checkbox" value="" id="product-email-settings-5">
                                                    <label class="form-check-label" for="product-email-settings-5">
                                                        Schedule Access
                                                    </label>
                                                </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- footer start -->
        <? include("./includes/views/footer.php"); ?>
        <!-- footer end -->
    </div>
    <!-- main content end -->
    <? include("./includes/views/footerjs.php"); ?>
</body>

<script>
    $(document).ready(function() {
        $("#create_record_modal").on('show.bs.modal', function(e) {
            var mydata = $(e.relatedTarget).data('mydata');
            console.log("mydata->", mydata);
            $("input[type='checkbox']").prop('checked', false);
            if (mydata != null) {
                $("#modelTitle").html("Update");
                $("input[name='company_name']").val(mydata['company_name'])
                $("input[name='email']").val(mydata['email'])
                $("input[name='about']").val(mydata['about'])
                $("input[name='number']").val(mydata['number'])
                $("input[name='role']").val(mydata['role'])
                $("input[name='enable_disable']").val(mydata['enable_disable'])
                $("input[name='gmail']").val(mydata['gmail'])
                $("input[name='phone_number']").val(mydata['phone_number'])
                $("input[name='company_mail']").val(mydata['company_mail'])
                $("input[name='address']").val(mydata['address'])
                $("input[name='facebook_link']").val(mydata['facebook_link'])
                $("input[name='twitter_link']").val(mydata['twitter_link'])
                $("input[name='linkedin_link']").val(mydata['linkedin_link'])
                $("input[name='instagram_link']").val(mydata['instagram_link'])
                $("input[name='youtube_link']").val(mydata['youtube_link'])
                $("input[name='pinterest_link']").val(mydata['pinterest_link'])
                $("input[name='current_password']").val(mydata['current_password'])
                $("input[name='new_password']").val(mydata['new_password'])
                $("input[name='confirm_password']").val(mydata['confirm_password'])
                $("input[name='actionId']").val(mydata['id'])
            } else {
                $("#modelTitle").html("Insert");
                $("input[name='company_name']").val("")
                $("input[name='email']").val("")
                $("input[name='about']").val("")
                $("input[name='number']").val("")
                $("input[name='role']").val("")
                $("input[name='enable_disable']").val("")
                $("input[name='gmail']").val("")
                $("input[name='phone_number']").val("")
                $("input[name='company_mail']").val("")
                $("input[name='address']").val("")
                $("input[name='facebook_link']").val("")
                $("input[name='twitter_link']").val("")
                $("input[name='linkedin_link']").val("")
                $("input[name='instagram_link']").val("")
                $("input[name='youtube_link']").val("")
                $("input[name='pinterest_link']").val("")
                $("input[name='current_password']").val("")
                $("input[name='new_password']").val("")
                $("input[name='confirm_password']").val("")
                $("input[name='actionId']").val("")
            }
        });
    })
</script>


<script>
    const profilePicInput = document.getElementById('profile_pic');
    const profilePicPreview = document.getElementById('profilePicPreview');
    const chooseImageBtns = document.querySelectorAll('.image-change');

    chooseImageBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            profilePicInput.click();
        });
    });

    profilePicInput.addEventListener('change', function() {
        if (profilePicInput.files && profilePicInput.files[0]) {
            const reader = new FileReader();
            reader.onload = function(e) {
                profilePicPreview.src = e.target.result;
            };
            reader.readAsDataURL(profilePicInput.files[0]);
        }
    });
</script>

</html>