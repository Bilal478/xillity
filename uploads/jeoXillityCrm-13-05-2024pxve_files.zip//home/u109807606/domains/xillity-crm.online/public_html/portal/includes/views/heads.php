<!DOCTYPE html>

<html lang="en" data-menu="vertical" data-nav-size="nav-default">

<head>

    <meta charset="UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Add Employee | Digiboard</title>

    

    <link rel="shortcut icon" href="favicon.png">

    <link rel="stylesheet" href="assets/vendor/css/all.min.css">

    <link rel="stylesheet" href="assets/vendor/css/OverlayScrollbars.min.css">

    <link rel="stylesheet" href="assets/vendor/css/jquery.uploader.css">

    <link rel="stylesheet" href="assets/vendor/css/select2.min.css">

    <link rel="stylesheet" href="assets/vendor/css/bootstrap-material-datetimepicker.css">

    <link rel="stylesheet" href="assets/vendor/css/jquery-ui.min.css">

    <link rel="stylesheet" href="assets/vendor/css/material-icon.css">

    <link rel="stylesheet" href="assets/vendor/css/selectize.css">

    <link rel="stylesheet" href="assets/vendor/css/bootstrap.min.css">

    <link rel="stylesheet" href="assets/css/style.css">

    <link rel="stylesheet" id="primaryColor" href="assets/css/blue-color.css">

    <link rel="stylesheet" id="rtlStyle" href="#">





