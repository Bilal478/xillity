<?
include_once("global.php");
// include("./includes/models/users.php");
// $role = 'user';
// if(!checkGlobalPermission('signupEnabled')){
//    // header("Location: ./");
// }

// if(isset($_GET['id'])){
//     $t_id = $_GET['id']; 
//     $getT_id = getRow($con, "select * from jeoXillityCrm_ticket where id='$t_id' ");
// }

?>

<!DOCTYPE html>
<html lang="en" data-menu="vertical" data-nav-size="nav-default">

<head><? include("./includes/views/head2.php"); ?></head>

<body class="body-padding body-p-top">
    <!-- header start -->
    <? include("./includes/views/navbar.php"); ?>
    <!-- header end -->
    <!-- right sidebar start -->
    <div class="right-sidebar-btn d-lg-block d-none">
        <button class="header-btn theme-settings-btn"><i class="fa-light fa-gear"></i></button>
    </div>
    <? include("./includes/views/rightsidebar.php"); ?>
    <!-- right sidebar end -->
    <!-- main sidebar start -->
    <? include("./includes/views/leftmenu2.php"); ?>
    <!-- main sidebar end -->
    <!-- main content start -->
    <div class="main-content">
        <div class="dashboard-breadcrumb mb-25">
            <h2>Tickets View</h2>
        </div>
        <div class="row g-4">
            <div class="col-md-9">
                <div class="panel">
                    <div class="panel-body">
                        <div class="col-12">
                            <label class="form-label">Tickets Description</label>
                            <textarea name="description" class="form-control editor form-control-sm" style="height: 200px;" placeholder="Description"></textarea>
                        </div>
                        <div class="profile-sidebar">
                            <div class="top">
                                <div class="image-wrap">
                                    <div class="part-img overflow-hidden">
                                        <label for="">Attachment</label>
                                        <?php
                                        if ($getCustomer['profile_pic'] != "") { ?>
                                            <img src="./uploads/<?php echo $getCustomer['profile_pic'] ?>" alt="admin">
                                        <?
                                        } else { ?>
                                            <img src="assets/images/admin.png" alt="admin">
                                        <?php
                                        }
                                        ?>
                                    </div>
                                    <button class="image-change"><i class="fa-light fa-camera"></i></button>
                                </div>
                            </div>
                            <div class="col-10 offset-1 text-center">
                                <button type="button" class="btn btn-primary btn-md w-100">Download All</button>
                            </div>
                            <div class="col-12 mt-3">
                                <label class="form-label">Comments</label>
                                <textarea name="comments" class="form-control editor form-control-sm" style="height: 100px;" placeholder="Add a comments here..."></textarea>
                            </div>
                            <div class="col-12 mt-3 d-flex justify-content-end">
                                <button type="button" class="btn btn-primary btn-md">Submit</button>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- <div class="panel">
                    <div class="panel-header">
                        <h5>User Activities</h5>
                        <div class="dropdown">
                            <a href="#" class="btn btn-sm btn-primary">View All</a>
                        </div>
                    </div>
                    <div class="panel-body">
                        <div class="user-activity">
                            <ul>
                                <li>
                                    <div class="left">
                                        <span class="user-activity-title">Your account is logged in</span>
                                        <span class="user-activity-details">From "RuthDyer" UiDesign Leave</span>
                                        <span class="user-activity-date">Monday 12 Jan 2020.</span>

                                    </div>

                                    <div class="right">

                                        <span class="user-activity-time">6 min ago</span>

                                    </div>

                                </li>

                                <li>

                                    <div class="left">

                                        <span class="user-activity-title">Current language has been changed</span>

                                        <span class="user-activity-details">From "RuthDyer" UiDesign Leave</span>

                                        <span class="user-activity-date">Monday 12 Jan 2020.</span>

                                    </div>

                                    <div class="right">

                                        <span class="user-activity-time">16 min ago</span>

                                    </div>

                                </li>

                                <li>

                                    <div class="left">

                                        <span class="user-activity-title">Leave Approval Request</span>

                                        <span class="user-activity-details">From "RuthDyer" UiDesign Leave</span>

                                        <span class="user-activity-date">Monday 12 Jan 2020.</span>

                                    </div>

                                    <div class="right">

                                        <span class="user-activity-time">6 min ago</span>

                                    </div>

                                </li>

                                <li>

                                    <div class="left">

                                        <span class="user-activity-title">Asked about this product</span>

                                        <span class="user-activity-details">From "RuthDyer" UiDesign Leave</span>

                                        <span class="user-activity-date">Monday 12 Jan 2020.</span>

                                    </div>

                                    <div class="right">

                                        <span class="user-activity-time">16 min ago</span>

                                    </div>

                                </li>

                            </ul>

                        </div>

                    </div>

                </div> -->
            </div>

            <div class="col-md-3">
                <div class="row">
                    <h6 class="mt-4">Tickets Info</h6>
                    <ul>
                        <li><span>Ticket No:</span><?php echo $getT_id['name']; ?></li>
                        <li><span>Department:</span><?php echo $getT_id['department']; ?></li>
                        <li><span>Start Date:</span><?php echo $getT_id['start_date']; ?></li>
                        <li><span>End Date:</span><?php echo $getT_id['end_date']; ?></li>
                        <li><span>Status:</span><?php echo $getT_id['status']; ?></li>
                        <li><span>Priority:</span><?php echo $getT_id['priority']; ?></li>
                    </ul>
                </div>
                <div class="col-12 mt-5">
                    <label class="form-label">Assign To</label>
                    <select class="form-control form-control-sm select-multiple" name="assign" data-placeholder="Eg: Natasha Hancock" multiple>
                        <?
                        $sql = "SELECT * FROM jeoXillityCrm_users";
                        $run = mysqli_query($con, $sql);
                        while ($fet = mysqli_fetch_assoc($run)) { ?>
                            <option value="<?= $fet['name'] ?>"><?= $fet['name'] ?></option>
                        <? } ?>
                    </select>
                </div>
                <div class="col-12 mt-3">
                    <button type="button" class="btn btn-primary mt-4 w-100">Follow Ticket</button>
                </div>
                <div class="col-12 mt-4">
                    <div class="d-flex align-items-center">
                        <label for="priority_status" class="me-2">Priority Status:</label>
                        <select name="priority_status" id="priority_status" class="form-control form-control-sm" data-placeholder="Select Priority Status">
                            <option value="">Select Priority Status</option>
                            <option value="Not Started">Not Started</option>
                            <option value="Pending">Pending</option>
                            <option value="Complete">Complete</option>
                            <option value="In_progress">In Progress</option>
                        </select>
                    </div>
                </div>
                <div class="col-12 mt-4">
                    <div class="d-flex align-items-center">
                        <label for="tickets_status" class="me-2">Tickets Status:</label>
                        <select name="tickets_status" id="tickets_status" class="form-control form-control-sm" data-placeholder="Select Tickets Status">
                            <option value="">Select Tickets Status</option>
                            <option value="Not Started">Not Started</option>
                            <option value="Pending">Pending</option>
                            <option value="Complete">Complete</option>
                            <option value="In_progress">In Progress</option>
                        </select>
                    </div>
                </div>
                <div class="row">
                    <div class="col-5 offset-1">
                        <button type="button" class="btn btn-light mt-4 w-100">Close</button>
                    </div>
                    <div class="col-5">
                        <button type="button" class="btn btn-success mt-4 w-100">Submit</button>
                    </div>
                </div>
            </div>
        </div>
        <!-- footer start -->
        <? include("./includes/views/footer.php"); ?>
        <!-- footer end -->
    </div>
    <!-- main content end -->
    <script src="assets/vendor/js/jquery-3.6.0.min.js"></script>
    <script src="assets/vendor/js/jquery.overlayScrollbars.min.js"></script>
    <script src="assets/vendor/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/main.js"></script>
</body>

</html>