<?php
require_once("./global.php");
/* connect to gmail */
// $hostname = '{imap.gmail.com:993/imap/ssl}INBOX';
// $username = 'azmlhh02@gmail.com';
// $password = 'rqkhbutt';
//Cannot connect to Gmail: Can not authenticate to IMAP server: [AUTHENTICATIONFAILED] Invalid credentials (Failure)
$query="select * from ".$g_projectSlug."_email_servers";
$resultServers=$con->query($query);
while($row_server=$resultServers->fetch_assoc()){
    $hostname='{'.$row_server['ip_address'].':'.$row_server['port_no'].'/imap/ssl/novalidate-cert}INBOX';
    $username = $row_server['email'];
    $password = $row_server['password']; 
    $server_id=$row_server['id'];
    
    // $hostname = '{mail.anomoz.com:993/imap/ssl}INBOX';
    // $username = 'test1@anomoz.com';
    // $password = 'testtestrqkhbutt1';
    /* try to connect */
    $inbox = imap_open($hostname,$username,$password) or die('Cannot connect to server: ' . imap_last_error());
    /* grab emails */
    $emails = imap_search($inbox,'ALL');
    
    if($emails) {
    
       $id = '';
       $subject = '';
       $from = '';
       $date = '';
       rsort($emails);
       foreach($emails as $email_number) {
          //https://www.php.net/manual/en/function.imap-fetch-overview.php
          /* get information specific to this email */
          $overview = imap_fetch_overview($inbox,$email_number,0);
          $message = imap_fetchbody($inbox,$email_number,2);
          
          $email_uid = $overview[0]->uid;
          
        //   echo "here1";
          $query_check="select * from ".$g_projectSlug."_emails where server_id='$server_id' and  email_uid='$email_uid'";
          $result_email_check=$con->query($query_check);
            if($result_email_check->num_rows==0)
            {
                $id=generateRandomString();
                $subject=$overview[0]->subject;
                
                $message=imap_fetchbody($inbox,$email_number,2);
                $email=$username;
                $date=$overview[0]->date;
                $from_email=$overview[0]->from;
                $query_insert="insert into ".$g_projectSlug."_emails set id='$id',subject='$subject',message='$message',email='$email',
                date='$date',from_email='$from_email',server_id='$server_id', email_uid='$email_uid'";
                $result=$con->query($query_insert);
                // echo "inserting";
            }
       
       /*
          $id= '<span class="subject">ID: '.($overview[0]->uid).'</span> ';
          $subject= '<span class="subject">SUB: '.$overview[0]->subject.'</span> ';
          $from= '<span class="from">FROM: '.$overview[0]->from.'</span>';
          $date= '<span class="date">on '.$overview[0]->date.'</span>';*/
          // $output.= '</div>';
          /* output the email body */
          // $output.= '<div class="body">'.$message.'</div><hr>';
       }
      
    }
    /* close the connection */
    imap_close($inbox);
}
?><hr>