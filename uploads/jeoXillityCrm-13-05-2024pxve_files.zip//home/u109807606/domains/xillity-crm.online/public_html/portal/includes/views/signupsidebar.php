<div class="kt-grid__item kt-grid__item--order-tablet-and-mobile-2 kt-grid kt-grid--hor kt-login__aside" style="padding:0px; height:90%;position:relative; margin-bottom:-100px;">
	  <div class="shortBlueBackgroundContainer" style="height:110%; position:fixed;">
        <div class="shortBlueBackground useAsMask lightBlue">
            <div class="shape-container">
                <div class="shape-first"></div>
                <div class="shape-second"></div>
                <div class="shape-third"></div>
            </div>
        </div>
    </div>
 <!--   <div class="kt-grid__item">-->
	<!--	<a href="#" class="kt-login__logo">-->
	<!--		<img src="<?echo $g_modules_global['logo']?>" style="height:20px;">-->
	<!--	</a>-->
	<!--</div>-->
	<div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--ver" style="padding:20px; top:30px;position:relative;">
		<div class="kt-grid__item kt-grid__item--middle">
			<h3 class="kt-login__title text-center">Welcome to <?echo $g_projectTitle?>!</h3>
			<h4 class="kt-login__subtitle"><?echo $g_tagline?></h4>
		</div>
	</div>
	<div class="kt-grid__item">
		<div class="kt-login__info">
			<div class="kt-login__copyright" style="text-align:center;width:100%;">
    &copy; 2023 <?php echo $g_projectTitle; ?>
</div>
		
		</div>
	</div>
</div>