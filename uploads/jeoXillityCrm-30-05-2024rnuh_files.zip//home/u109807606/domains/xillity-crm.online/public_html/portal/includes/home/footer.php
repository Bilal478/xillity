<div class="site-footer">
    <div class="container">
        <!--<div class="row mb-5">
            <div class="col-md-6 col-lg-4">
                <div class="widget">
                    <h3 class="heading"><?echo $g_projectTitle?></h3>
                    <p><?echo $g_tagline?></p>
                </div>
                <div class="widget">
                    <ul class="list-unstyled social">
                        <li>
                            <a href="#"><span class="icon-twitter"></span></a>
                        </li>
                        <li>
                            <a href="#"><span class="icon-instagram"></span></a>
                        </li>
                        <li>
                            <a href="#"><span class="icon-facebook"></span></a>
                        </li>
                    </ul>
                </div>
            </div>
            
        </div>-->
        <div class="row">
            <div class="col-lg-12 text-center">
                <p>
                    Copyright &copy;
                    <script data-cfasync="false" src="./assetshome/js/cloudflare-static-email-decode.min.js"></script>
                    <script>
                        document.write(new Date().getFullYear());
                    </script>
                    All rights reserved | Developed by <a href="https://anomoz.com?src=<?echo urlencode($g_website)?>" target="_blank" rel="nofollow noopener">Anomoz Softwares</a>
                </p>
            </div>
        </div>
    </div>
</div>

<!-- footer -->
<!--<div id="overlayer"></div>-->
<!--<div class="loader">-->
<!--    <div class="spinner-border text-primary" role="status">-->
<!--        <span class="visually-hidden">Loading...</span>-->
<!--    </div>-->
<!--</div>-->
<script src="./assetshome/js/3529-js-bootstrap.bundle.min.js"></script>
<script src="./assetshome/js/3027-js-tiny-slider.js"></script>
