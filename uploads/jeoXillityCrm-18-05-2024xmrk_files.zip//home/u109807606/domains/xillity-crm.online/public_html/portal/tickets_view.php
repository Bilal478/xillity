<?
include_once("global.php");
// include("./includes/models/users.php");
// $role = 'user';
// if(!checkGlobalPermission('signupEnabled')){
//    // header("Location: ./");
// }

// if(isset($_GET['id'])){
//     $t_id = $_GET['id']; 
//     $getT_id = getRow($con, "select * from jeoXillityCrm_ticket where id='$t_id' ");
// }
// Sanitize input


if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['create_package'])) {
    if (isset($_GET['id'])) {
        // Assuming generateRandomString() generates a unique ID
        // $name = escape($_POST['name']);
        $company_name = escape($_POST['company_name']);
        // $department = escape($_POST['department']);
        $site_name = escape($_POST['site_name']);
        $email = escape($_POST['email']);
        $status = escape($_POST['status']);
        $phone_number = escape($_POST['phone_number']);
        $primary_contact = escape($_POST['primary_contact']);
        $home_number = escape($_POST['home_number']);
        // $start_date = escape($_POST['start_date']);
        // $end_date = escape($_POST['end_date']);
        $priority = escape($_POST['priority']);
        $assign = escape($_POST['assign']);
        $description = escape($_POST['description']);
        $timeAdded = date('Y-m-d H:i:s');
        $ticket_id = $_GET['id'];
        $query = "UPDATE jeoXillityCrm_tickets SET company_name='$company_name', site_name='$site_name', email='$email', status='$status', phone_number='$phone_number', primary_contact='$primary_contact', home_number='$home_number', priority='$priority', assign='$assign', description='$description' WHERE id='$ticket_id'";
        // $query = "UPDATE jeoXillityCrm_tickets SET name='$name', company_name='$company_name', department='$department', site_name='$site_name', email='$email', status='$status', phone_number='$phone_number', primary_contact='$primary_contact', home_number='$home_number', start_date='$start_date', end_date='$end_date', priority='$priority', assign='$assign', description='$description' WHERE id='$ticket_id'";
        runQuery($query);

        $file = storeFile($_FILES['profile_pic']);
        if ($file != "") {
            $query = "update jeoXillityCrm_tickets set profile_pic='$file' where id='$actionId'";
            runQuery($query);
        }
        header("Location: Tickets.php?m=Data was saved successfully!&type=success");
    } else {
        echo "Invalid action ID.";
    }
}

$primaryTableName = "comments";
$t_id = $_GET['id'];
if (isset($_POST['create_package1'])) {
    $actionId = escape(($_POST['actionId']));
    $comments_name = escape($_POST['comments_name']);
    $Ticket_id = $t_id;
    $timeAdded = date('Y-m-d H:i:s');
    if ($actionId == "") {
        $id = generateRandomString();
        $actionId = $id;
        $query = "INSERT INTO jeoXillityCrm_comments (id, comments_name, Ticket_id, timeAdded, userId) 
              VALUES ('$id', '$comments_name', '$Ticket_id', '$timeAdded', '$session_userId')";
        runQuery($query);
        header("Location: ?" . generateUrlParams_return(["m" => "Data was saved successfully!", "type" => "success"]));
        exit();
    } else {
        // If actionId is not empty, update existing comment (if necessary)
    }
}

if (isset($_GET['delete-record'])) {
    $id = escape($_GET['delete-record']);
    $query = "delete from jeoXillityCrm_comments where id='$id'";
    runQuery($query);
}
?>

<!DOCTYPE html>
<html lang="en" data-menu="vertical" data-nav-size="nav-default">

<head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/habibmhamadi/multi-select-tag@3.0.1/dist/css/multi-select-tag.css">
    <? include("./includes/views/head2.php"); ?>
</head>

<body class="body-padding body-p-top">
    <!-- header start -->
    <? include("./includes/views/navbar.php"); ?>
    <!-- header end -->
    <!-- right sidebar start -->
    <div class="right-sidebar-btn d-lg-block d-none">
        <button class="header-btn theme-settings-btn"><i class="fa-light fa-gear"></i></button>
    </div>
    <? include("./includes/views/rightsidebar.php"); ?>
    <!-- right sidebar end -->
    <!-- main sidebar start -->
    <? include("./includes/views/leftmenu2.php"); ?>
    <!-- main sidebar end -->
    <!-- main content start -->
    <div class="main-content">
        <div class="dashboard-breadcrumb mb-25">
            <h2>Tickets View</h2>
        </div>
        <form action="" method="post">
            <div class="row g-4">
                <?php if (isset($_GET['id'])) {
                    // Assuming $con is your database connection object
                    // Fetch ticket information based on the provided ID
                    $ticket_id = mysqli_real_escape_string($con, $_GET['id']); // Sanitize input
                    $sql = "SELECT * FROM jeoXillityCrm_tickets WHERE id = '$ticket_id'";
                    $result = mysqli_query($con, $sql);
                    if (mysqli_num_rows($result) > 0) {
                        $ticket_info = mysqli_fetch_assoc($result);?>
                        <div class="col-md-9">
                            <div class="panel">
                                <div class="panel-body">
                                    <div class="col-12">
                                        <label class="form-label">Tickets Description</label>
                                        <textarea name="description" class="form-control editor form-control-sm" style="height: 200px;" placeholder="Description"><?php echo $ticket_info['description']; ?></textarea>
                                    </div>
                                    <div class="profile-sidebar">
                                        <div class="top">
                                            <div class="image-wrap">
                                                <div class="part-img overflow-hidden">
                                                    <label for="">Attachment</label>
                                                    <?php if ($ticket_info['profile_pic'] != "") { ?>
                                                        <img src="./uploads/<?php echo $ticket_info['profile_pic'] ?>" alt="admin">
                                                    <?php } else { ?>
                                                        <img src="assets/images/admin.png" alt="admin">
                                                    <?php } ?>
                                                </div>
                                                <!-- Add input for image upload -->
                                                <input type="file" id="imageUpload" style="display: none;">
                                                <button class="image-change" id="cameraButton"><i class="fa-light fa-camera"></i></button>
                                            </div>
                                        </div>
                                        <div class="col-10 offset-1 text-center">
                                            <button type="button" class="btn btn-primary btn-md w-100">Download All</button>
                                        </div>
                                        <div class="col-12 mt-3">
                                            <label class="form-label" for="comments_name">Comments</label>
                                            <textarea name="comments_name" id="comments_name" class="form-control" rows="3"></textarea>
                                        </div>
                                        <input type="hidden" name="Ticket_id" value="<?php echo $t_id; ?>">
                                        <div class="col-12 mt-3 d-flex justify-content-end">
                                            <button type="submit" class="btn btn-primary btn-md" name="create_package1">Add Comments</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12 mt-3">
                                <?php
                                $query = "SELECT * FROM jeoXillityCrm_comments WHERE Ticket_id='$t_id' ORDER BY timeAdded DESC";
                                $results = getAll($con, $query);
                                foreach ($results as $row) { ?>
                                    <div class="card mb-3">
                                        <div class="card-body">
                                            <p class="card-text"><?php echo $row['comments_name'] ?></p>
                                            <p class="card-text text-end"><?php echo $row['timeAdded'] ?></p>
                                        </div>
                                    </div>
                                <?php } ?>
                            </div>
                        </div>

                        <div class="col-md-3">
                            <div class="row">
                                <h6 class="mt-4">Tickets Info</h6>
                                <ul>
                                    <li><span>Ticket No:</span> <?php echo $ticket_info['name']; ?></li>
                                    <li><span>Department:</span> <?php echo $ticket_info['department']; ?></li>
                                    <li><span>Start Date:</span> <?php echo $ticket_info['start_date']; ?></li>
                                    <li><span>End Date:</span> <?php echo $ticket_info['end_date']; ?></li>
                                    <li><span>Status:</span> <?php echo $ticket_info['status']; ?></li>
                                    <li><span>Priority:</span> <?php echo $ticket_info['priority']; ?></li>
                                </ul>
                            </div>
                            <div class="col-12 mt-5">
                                <label class="form-label">Assign To</label>
                                <select class="form-control form-control-sm select-multiple" name="assign" id="assign" data-placeholder="Eg: Natasha Hancock" multiple>
                                    <?php
                                    $sql = "SELECT * FROM jeoXillityCrm_users";
                                    $run = mysqli_query($con, $sql);
                                    while ($fet = mysqli_fetch_assoc($run)) { ?>
                                        <option value="<?= $fet['name'] ?>"><?= $fet['name'] ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                            <div id="tagsContainer" class="col-12 mt-3"></div>

                            <div class="col-12 mt-3">
                                <button type="button" class="btn btn-primary mt-4 w-100">Follow Ticket</button>
                            </div>
                            <div class="col-12 mt-4">
                                <div class="d-flex align-items-center">
                                    <label for="priority_status" class="me-2">Priority Status:</label>
                                    <select name="priority" class="form-control form-control-sm" data-placeholder="Select Priority">
                                        <option value="">Select Priority</option>
                                        <option value="Low">Low</option>
                                        <option value="Medium">Medium</option>
                                        <option value="High">High</option>
                                        <option value="Urgent">Urgent</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-12 mt-4">
                                <div class="d-flex align-items-center">
                                    <label for="tickets_status" class="me-2">Tickets Status:</label>
                                    <select name="status" id="tickets_status" class="form-control form-control-sm" data-placeholder="Select Tickets Status">
                                        <option value="">Select Tickets Status</option>
                                        <option value="Pending">Pending</option>
                                        <option value="Complete">Complete</option>
                                        <option value="In_progress">In Progress</option>
                                    </select>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-5 offset-1">
                                    <button type="button" class="btn btn-light mt-4 w-100">Close</button>
                                </div>
                                <div class="col-5" id="create_record_modal">
                                    <button type="submit" class="btn btn-success mt-4 w-100" name="create_package">Submit</button>
                                </div>
                            </div>
                        </div>
        </form>
<?php
                    } else {
                        echo "No ticket found with the provided ID.";
                    }
                }
?>
    </div>
    <!-- footer start -->
    <? include("./includes/views/footer.php"); ?>
    <!-- footer end -->
    </div>
    <!-- main content end -->
    <script src="assets/vendor/js/jquery-3.6.0.min.js"></script>
    <script src="assets/vendor/js/jquery.overlayScrollbars.min.js"></script>
    <script src="assets/vendor/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/main.js"></script>
</body>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/gh/habibmhamadi/multi-select-tag@3.0.1/dist/js/multi-select-tag.js"></script>
<script>
    new MultiSelectTag('comments') // id
</script>

<script>
    const select = document.getElementById("assign");
    const tagsContainer = document.getElementById("tagsContainer");

    function createTags() {
        tagsContainer.innerHTML = ""; // Clear existing tags
        const selectedOptions = Array.from(select.selectedOptions);
        selectedOptions.forEach(option => {
            const tag = document.createElement("div");
            tag.className = "tag";
            tag.textContent = option.value;
            tagsContainer.appendChild(tag);
        });
    }
    select.addEventListener("change", createTags);
    createTags();
</script>


<script>
    // JavaScript to trigger file input click when camera button is clicked
    document.getElementById("cameraButton").addEventListener("click", function() {
        document.getElementById("imageUpload").click();
    });
</script>

</html>