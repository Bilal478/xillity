<?  require("./global.php");

//for generating table generation queries
$primaryTableName = "projects";

if(!checkGlobalPermission('enableProjectViewManagement')){header("Location: ./home.php?m=Oops! Error occured");}


$projectId = $_GET['_projectId'];
$getProject = getRow($con,"SELECT *, p.description  FROM ".$g_projectSlug."_projects p INNER join ".$g_projectSlug."_users u on u.id=p.customerId WHERE p.`id`='$projectId'");

if(is_null($getProject)){
// 	header("Location: ./projects.php?m=Project is not Found!");
// 	exit();
}


if(isset($_GET['tId_complete'])){
    $tagId = $_GET['tId_complete'];
    $timeAdded = time();
    $id = generateRandomString();
    
    $query = "insert into ".$g_projectSlug."_tags_completed set id='$id', tagId='$tagId', timeAdded ='$timeAdded', userId='$session_userId'";
	$stmt = $con->prepare($query);
	if(!$stmt){echo "err: <code>$query</code>";}
	if(!$stmt->execute()){echo "err: <code>$query</code>";}
	
	/*send notification - @notf*/
    $new_message = $tagId.' has been marked as completed';
    $notificationData = [
        'id' => generateRandomString(),
        'title' => $new_message,
        'desc' => $new_message,
        'redirectUrl' => $g_website.'/project_view.php?_projectId='.$projectId,
        'toUser' => $getProject['customerId'],
        'email' => $g_allUsersInfo[$getProject['customerId']]['email'],
    ];
    setNotification($con,$notificationData); // globalFunction 
    /*end of send notification - @notf*/
	
	if(isset($_GET['_projectId'])){$rStr =  "&_projectId=".$_GET['_projectId'];}
    header("Location: ?m=Data was saved successfully!".$rStr);
    
    
    
    
}


$getcustomersFromDB = getAll($con,"SELECT * FROM `".$g_projectSlug."_users` ");
$customersArr = [];
foreach($getcustomersFromDB as $k => $v){
	$customersArr[$v['id']] = ucfirst($v['name']); 
}


if(isset($_POST['json_input'])){
    $kanban_board_contents = $_POST['json_input'];
    $query = "update ".$g_projectSlug."_".$primaryTableName." set kanban_board_contents='$kanban_board_contents' where id='$projectId' ";
	$stmt = $con->prepare($query);
	if(!$stmt){echo "err: <code>$query</code>";}
	if(!$stmt->execute()){echo "err: <code>$query</code>";}
	
	$getProject['kanban_board_contents'] = $kanban_board_contents;
}


if(isset($_POST['long_description'])){
    $long_description = mb_htmlentities($_POST['long_description']);
    $query = "update ".$g_projectSlug."_".$primaryTableName." set long_description='$long_description' where id='$projectId' ";
    if(!mysqli_query($con,$query))
    {echo "err";}
// 	$stmt = $con->prepare($query);
// 	if(!$stmt){echo "err: <code>$query</code>";}
// 	if(!$stmt->execute(array())){echo "err: <code>$query</code>";}
	
	$getProject['long_description'] = $long_description;
	
	/*send notification - @notf*/
    $new_message = 'Your Project board have been changed successfully.';
    $notificationData = [
        'id' => generateRandomString(),
        'title' => $new_message,
        'desc' => $new_message,
        'redirectUrl' => $g_website.'/project_view.php?_projectId='.$projectId,
        'toUser' => $getProject['customerId'],
        'email' => $g_allUsersInfo[$getProject['customerId']]['email'],
    ];
    setNotification($con,$notificationData); // globalFunction 
    /*end of send notification - @notf*/
	
	if(isset($_GET['_projectId'])){$rStr =  "&_projectId=".$_GET['_projectId'];}
    header("Location: ?m=Data was saved successfully!".$rStr);
}

$primaryTableName = "project_files";
$arrayFields_crud = array(
    "file" => ["input", "required", "", "file"],
    "description" => ["textarea", "required", "", "text"],
    "projectId" => ["input", "required hidden value='$projectId'", "", "text"],
);

if(false){
	$t = "CREATE TABLE ".$g_projectSlug."_".$primaryTableName."(<br>id VARCHAR(200) PRIMARY KEY,<br>";
	foreach($arrayFields_crud as  $col => $info){
		$t.= "$col VARCHAR(256) DEFAULT '' ,<Br>";
	}
	$t.= "timeAdded VARCHAR(256) NULL,<br>userId VARCHAR(256) NULL);";
	echo "<code>$t</code>";
}


if(isset($_POST['create_package'])){
    $timeAdded = time();
    $actionId = mb_htmlentities(($_POST['actionId']));
    $files_array = [];
	$queryExtra = '';
	foreach($arrayFields_crud as  $col => $info){
	    //for text
	    if(!in_array($info[3], ["image", "file"])){
    	    $val = mb_htmlentities($_POST[$col]);
    	    if($val!='' && $val!=NULL){
    	        $queryExtra.= ", $col='".$val."' ";
    	    }
	    }else{
	        //for images
	        if(isset($_FILES[$col])){
                $files_array[$col] = storeFile($_FILES[$col]); 
            }
	    }
	}

    $timeAdded = time();
    
    if($actionId==""){
        $id = generateRandomString();
        $actionId = $id;
        $query = "insert into ".$g_projectSlug."_".$primaryTableName." set id='$id' $queryExtra, timeAdded='$timeAdded', userId='$session_userId' ";
        $stmt = $con->prepare($query);
        if(!$stmt){echo "err: <code>$query</code>";}
        if(!$stmt->execute()){echo "err: <code>$query</code>";}
    }else{
        //update
        $query = "update ".$g_projectSlug."_".$primaryTableName." set id='$actionId' $queryExtra where id='$actionId'";
        $stmt = $con->prepare($query);
        if(!$stmt){echo "err: <code>$query</code>";}
        if(!$stmt->execute()){echo "err: <code>$query</code>";}
    }
    
    //update files
    foreach($files_array as $col => $file){
        if($file!=""){
            $query = "update ".$g_projectSlug."_".$primaryTableName." set $col='$file' where id='$actionId'";
            $stmt = $con->prepare($query);
            if(!$stmt){echo "err: <code>$query</code>";}
            if(!$stmt->execute()){echo "err: <code>$query</code>";}
        }
    }

    if(isset($_GET['_projectId'])){$rStr =  "&_projectId=".$_GET['_projectId'];}
    header("Location: ?m=Data was saved successfully!".$rStr);
    
}


?>
<!DOCTYPE html>


<html lang="en">

<!-- begin::Head -->
<head>
	<link rel="stylesheet" type="text/css" href="https://projects.anomoz.com/ke/demo9/assets/plugins/custom/kanban/kanban.bundle.css">
	<?require("./includes/views/head.php")?>
	 <link rel="stylesheet" href="./assets/article-editor.min.css" />

    <style>
        img{
            /*width:100%;*/
        }
       
       .arx-editor [data-arx-type="column"]{
           outline:0;
       }
   </style>
   
   
   <style>
           


.sid_selector{
    display: flex;
    flex-direction: column;
    position: absolute;
    width: fit-content;
    height: fit-content;
    z-index: 1;
    color: #FFFFFF;
    background-color: rgb(56, 56, 56, .7);
    padding: 5px;
}

#sid-input{
    width: 200px;
    height: 25px;
    font-size: 12pt;
    background-color: rgb(56, 56, 56, .7);
    color: #FFFFFF;
    text-align: center;
}

.showcase {
    width: 100%;
    height: 100%;
    align-self: center;
    box-shadow: 0 4px 8px rgb(43, 43, 43);
    display: flex;
}
.showcase_container{
    height: 63vh;
    width: 100%;
    display: flex;
    justify-content: flex-end;
    position: relative;
}


#color {
    width: 20px;
    height: 20px;
}
#color div{
    width: 13px;
    height: 13px;
    margin-left: auto;
    margin-right: auto;
}
#color input{
    width: 100px;
    height: 10px;
}

#icon:hover{
    cursor: pointer;
}
#icon{
    text-align: center;
    width: 20px;
    height: 20px;
}
#icon div:after{
    display: inline-block;
    content: "\00d7";
    font-size: 16pt;
    color: rgb(161, 0, 0);
}
#goto div:after {
    display: inline-block;
    content: "\2197";
    font-size: 16pt;
    color: rgb(0, 0, 161);
    text-align: center;
}
#goto{
    text-align: center;
    width: 20px;
    height: 20px;
}

.color_picker {
    color: red;
    min-width: min-content;
    min-height: min-content;
}

.click-overlay{
    position: absolute;
    width: 100%;
    height: 100%;
    align-self: center;
    z-index: 1;
}

        </style>
</head>

<!-- end::Head -->

<!-- begin::Body -->
<body class="<?echo $g_body_class?>">

	<?require("./includes/views/header.php")?>

	<div class="kt-grid kt-grid--hor kt-grid--root">
		<div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--ver kt-page">
			<div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-wrapper" id="kt_wrapper">

				<!-- begin:: Header -->

				<?require("./includes/views/topmenu.php")?>
				<!-- end:: Header -->

				<!-- begin:: Aside -->
				<?require("./includes/views/leftmenu.php")?>

				<!-- end:: Aside -->
				<div class="kt-body kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-grid--stretch" id="kt_body">
					<div class="kt-content  kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor" id="kt_content">

						<!-- end:: Subheader -->

						<!-- begin:: Content -->
						<div class="kt-container  kt-grid__item kt-grid__item--fluid">
						    
						     <div class="kt-portlet ">
									<div class="kt-portlet__body">
										<div class="kt-widget kt-widget--user-profile-3">
											<div class="kt-widget__top">
												
												<div class="kt-widget__pic kt-widget__pic--danger kt-font-danger kt-font-boldest kt-font-light">
													<?echo strtoupper(substr($getProject['title']." ".$getProject['last_name'], 0, 2));?>
												</div>
												<div class="kt-widget__content">
													<div class="kt-widget__head">
														<a href="#" class="kt-widget__username kt-hidden">
															<?echo $getProject['name']." ".$getProject['last_name'];?>
															<i class="flaticon2-correct"></i>
														</a>
														<a href="#" class="kt-widget__title"><? echo $getProject['title']." ".$getProject['last_name'];?></a>
														<div class="kt-widget__action">
														    <?if(checkGlobalPermission('enableMessages')){?>
															    <!--<a href="./messages.php?u=<?echo $getProject['userId'];?>" class="btn btn-sm btn-success btn-primary ">Message</a>-->
															<?}?>
															<a href="mail:<?echo $getProject['email']?>" class="btn btn-brand btn-sm btn-upper">E-mail</a>
														</div>
													</div>
													<div class="kt-widget__subhead ">
														<a href="#"><i class="flaticon2-new-email"></i><?echo $getProject['email']?></a>
														<a href="#"><i class="flaticon2-phone"></i><?echo $getProject['phone']?></a>
														<a href="#"><i class="flaticon2-placeholder"></i><?echo $getProject['address']?></a>
													</div>
													<div class="kt-widget__info">
													    <?echo $getProject['description'];?>
													
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
								
								
								<?if(checkGlobalPermission('enableProjectViewContentBoard')){?>
    							<div class="row">
    								<div class="col-lg-12">
    								    
    								    
    								    <div class="kt-portlet">
    										<div class="kt-portlet__head">
    											<div class="kt-portlet__head-label">
    												<h3 class="kt-portlet__head-title">
    													TextBoard
    												</h3>
    											</div>
    										</div>
    										<div class="kt-portlet__body">
    											    <form action="" method="post">
    											        <textarea name="long_description"><?echo $getProject['long_description']?></textarea>
    											        <button type="submit" class="btn btn-primary">Submit</button>
    											    </form>
    										
    											</div>
    										</div>
    										
    								    
    										<?if(checkGlobalPermission('enableProjectViewFiles')){?>
    										<div class="kt-portlet kt-portlet--mobile">
    									<div class="kt-portlet__head kt-portlet__head--lg">
    										<div class="kt-portlet__head-label">
    										    <? $primaryTableName = "project_files"?>
    											<span class="kt-portlet__head-icon">
    											</span>
    											<h3 class="kt-portlet__head-title">
    												<?echo ucfirst(str_replace("_", " ", $primaryTableName));?>
    											</h3>
    										</div>
    										<div class="kt-portlet__head-toolbar">
    											<div class="kt-portlet__head-wrapper">
    												<div class="kt-portlet__head-actions">
    												    
    												    <?//renderImportExportButtons();?>
    												    
    													<a href="#" class="btn btn-brand btn-elevate btn-icon-sm" data-toggle="modal" data-target="#create_record_modal">
    														<i class="la la-plus"></i>
    														New Record
    													</a>
    															
    												</div>
    											</div>
    										</div>
    									</div>
    									<div class="kt-portlet__body">
                                            <form action="" method="post">
                                                <?if(checkGlobalPermission('g_enableBulkDelete')){?>
                                                    <button type="button" class="btn btn-info btn-sm text-white " onclick="selectAll();">Select All</button>
                                                    <button type="submit"  class="btn btn-danger btn-sm text-white ">Delete Bulk</button>
                                                <?}?>
        										<!--begin: Datatable -->
        										<table class="table table-striped- table-bordered table-hover table-checkable add-search" id="kt_table_1">
        											<thead>
        												<tr>
        												    <?if(checkGlobalPermission('g_enableBulkDelete')){?><th>Select</th><?}?>
        													<?foreach($arrayFields_crud as  $col => $info){
        													    if(strpos($info[1], "hidden")==false){?>
        													        <th><?echo ucfirst(str_replace("_", " ", $col))?></th>
        													<?}}?>
        												
        													<th>User</th>
        												</tr>
        											</thead>
        											<tbody>
        											    <?$results = getAll($con, "select * from ".$g_projectSlug."_".$primaryTableName." where projectId='$projectId' order by timeAdded desc");
        											    foreach($results as $row){?>
            												<tr>
            												    <?if(checkGlobalPermission('g_enableBulkDelete')){?>
                												    <th><div class="form-check">
                                                                        <label class="form-check-label">
                                                                          <input class="form-check-input" type="checkbox" name="delete_bulk[]" value="<?echo $row['id']?>">
                                                                          <span class="form-check-sign">
                                                                            <span class="check"></span>
                                                                          </span>
                                                                        </label>
                                                                      </div>
                                                                     </th>
                                                                 <?}?>
            													<?foreach($arrayFields_crud as $col => $info){
            													    if(strpos($info[1], "hidden")==false){?>
            													    <td><?if($info[3]=="image"){?>
            													        <a href="./uploads/<?echo $row[$col]?>" target="_blank"><img src="./uploads/<?echo $row[$col]?>" class="img-thumbnail" style="height:90px;"  onerror="this.src='./assets/media/404.png';"></a>
            													    <?}else if($info[3]=="file"){?>
            													        <a href="./uploads/<?echo $row[$col]?>" target="_blank" class='badge btn-info btn-sm'>View File</a>
            													        <a href="./uploads/<?echo $row[$col]?>"  download class='badge btn-info btn-sm'>Download File</a>
            													    <?}else{echo ($row[$col]);}?></td>
            													<?}}?>
            													
            													<td>
            													    <?echo $customersArr[$row['userId']];?>
            													</td>
            													<!--<td>-->
            													<!--    <a href="#" class="btn btn-warning" data-toggle="modal" data-target="#create_record_modal" data-mydata='<?echo  (json_encode($row, true));?>' >Edit</a>-->
            													<!--    <a href="#" class="btn btn-danger" data-toggle="modal" data-target="#delete_record" data-url="?<?if(isset($_GET['id'])){echo "id=".$_GET['id']."&";}?>delete-record=<?echo $row['id']?>">Delete</a>-->
            													<!--</td>-->
            												</tr>
        												<?}?>
        												
        											</tbody>
        										</table>
                                            </form>
    										<!--end: Datatable -->
    									</div>
    								</div>
    								<?}?>
    								
    								<?if(checkGlobalPermission('enableProjectViewKanbanBoard'))	{?>
    								<div class="kt-portlet">
    									<div class="kt-portlet__head">
    										<div class="kt-portlet__head-label">
    											<h3 class="kt-portlet__head-title">
    												Project Kanban
    											</h3>
												<? 
												// var_dump($getProject);
												?>
    										</div>
    										
    										<div class="kt-portlet__head-toolbar">
    											<div class="kt-portlet__head-wrapper">
    												<div class="kt-portlet__head-actions">
    												    
    												    <button class='btn btn-primary' onclick="save_kanban()">Save</button>
    												</div>
    											</div>
    										</div>
    											
    										
    									</div>
    									<div class="kt-portlet__body">
    										<div id="kanban4_div">
    
    										</div>
    										<?if(true){?>
    										<div class="kanban-toolbar">
    											<div class="row">
    												<div class="col-lg-4">
    													<div class="kanban-toolbar__title">
    														Add New Board
    													</div>
    													<div class="form-group row">
    														<div class="col-12">
    																<input id="kanban-add-board" class="form-control" type="text" placeholder="Board Name" name="board_name" required><br>
    																<input type="hidden" name="createBoard" value="true">
    																<br>
    																<button type="submit" class="btn btn-success" id="addBoard" >Add board</button>
    														</div>
    													</div>
    												</div>
    												<div class="col-lg-4">
    													<div class="kanban-toolbar__title">
    														Add New Item
    													</div>
    													<div class="form-group">
    															<input id="kanban-add-task" class="form-control" type="text" placeholder="Task Name" name="item_name" required><br>
    															<input type="hidden" name="createBoardItem" value="true">
    															<br>
    															<button type="submit" class="btn btn-primary" id="addTask" >Add Task</button>
    													</div>
    												</div>
    												<div class="col-lg-4">
    													<div class="kanban-toolbar__title">
    														Clear Board
    													</div>
    													<div class="form-group">
    															<div class="col-12">
    																<select id="kanban-select-board" class="form-control" name="delete-record">
    																	<option value="">Select a Board</option>
    																	    <?foreach(json_decode($getProject['kanban_board_contents'], true) as $board){?>
    																	        <option value="<?echo $board['id']?>"><?echo $board['title']?></option>
    																	    <?}?>
    																	</select>
    																	<br>
    																	<button type="submit" class="btn btn-danger" id="removeBoard2">Remove Board</button>
    																</div>
    														</div>
    													</div>
    												</div>
    											</div>
    											<?}?>
    										</div>
    									</div>
    								<?}?>
    								
    								
    								<?if($getProject['clickup_embed_link']!=""){?>
        								<div class="kt-portlet">
        								
        									<div class="kt-portlet__body">
    									        <?if($getProject['clickup_embed_link']!=""){?>
                                                    <iframe src="<?echo $getProject['clickup_embed_link']?>" style="height: 400px;"></iframe>
                                                <?}?>
        									</div>
    
        								</div>
    								<?}?>
    								</div>
    							</div>
    							<?}?>
							<!-- end:: Content -->
						</div>
					</div>

                  
                    
					<!-- begin:: Footer -->
					
					<?require("./includes/views/footer.php")?>

					<!-- end:: Footer -->
				</div>
			</div>
		</div>
		
		<form action="" method="post" id="json_form" class="d-none">
		    <input hidden name="json_input">
		</form>


		<?require("./includes/views/footerjs.php")?>
	
<?if(checkGlobalPermission('enableProjectViewKanbanBoard')){?>	
<script type="text/javascript" src="https://projects.anomoz.com/ke/demo9/assets/plugins/custom/kanban/kanban.bundle.js" defer></script>
<script type="text/javascript">
			
        kanban4 = "";
		$(document).ready(function(e){
		
			myjson = <?echo $getProject['kanban_board_contents']?>;
			
			console.log("myjson", myjson);
			
			kanban4 = new jKanban({
						element : '#kanban4_div',
						gutter  : '0',
						click : function(el){
							console.log("clcked", el)
						},
						itemAddOptions: {
                            enabled: true,                                              // add a button to board for easy item creation
                            content: '+ add card',                                                // text or html content of the board button   
                            class: 'btn btn-primary btn-xs',         // default class of the button
                            footer: true                                                // position the button on footer
                        },   
						boards  :myjson
					});



				var addBoard = document.getElementById('addBoard');
					addBoard.addEventListener('click',function(){
					var boardTitle = $('#kanban-add-board').val();
					var boardId = '_' + $.trim(boardTitle);
					var boardColor = $('#kanban-add-board-color').val();
					var option = '<option value="'+boardId+'">'+boardTitle+'</option>';
					boardjson = {
							'id' : boardId,
							'title'  : boardTitle,
							'class': boardColor
						} 
					kanban4.addBoards(
						[boardjson]
					);	
					
					$('#kanban-select-task').append(option);
					$('#kanban-select-board').append(option);
				});

				var addTask = document.getElementById('addTask');
				addTask.addEventListener('click',function(){
					var target = "_board1";
					var title = $('#kanban-add-task').val();
					var taskColor = $('#kanban-add-task-color').val();
					kanban4.addElement(
						target,
						{
							'title': title,
							'class': taskColor
						}
					);
				});

				var removeBoard2 = document.getElementById('removeBoard2');
				removeBoard2.addEventListener('click',function(){
					var target = $('#kanban-select-board').val();
					kanban4.removeBoard(target);
					$('#kanban-select-task option[value="'+target+'"]').remove();
					$('#kanban-select-board option[value="'+target+'"]').remove();
				});
				
		})
		
		
		function getJson(){
		    totalJson = [];
		    boards  = kanban4.options.boards;
		    for (const board of boards) {
		        boardId = board['id']
		        
		        //get items
		        totalitems = [];
		        
		        try {
    		        items = $(kanban4.getBoardElements(boardId))
    		        for (const item of items) {
    		            tex = $(item).text()
    		            totalitems.push({
    		                "title": tex
    		            })
    		        }
		        }catch(err) {
		        }
		        
		        board["item"] = totalitems
		        console.log("board", board)
		        totalJson.push(board)
		    };
		    return totalJson;
		}
		
		function save_kanban(){
		    json = getJson() ;
		    console.log("json", json)
		    json = JSON.stringify(json)
		    $("input[name=json_input]").val( json )
		    $("#json_form").submit()
		    
		    
		}
	</script>
	<?}?>
	
	
	 <script src="./assets/article-editor.min.js"></script>

<!-- call -->
<script>
ArticleEditor('textarea',
{
    image: {
        upload: './image-upload.php'
    }
});
</script>
</body>
<!-- end::Body -->




    
    <div class="modal fade" id="create_record_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="modelTitle">Insert</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					</button>
				</div>
				<div class="modal-body">
					
					<form class="kt-form" action="" method="Post" enctype="multipart/form-data">
						<div class="kt-portlet__body">
						    
						    <?foreach($arrayFields_crud as $col => $info){?>
						    <div class="form-group">
						        <?if(strpos($info[1], "hidden")==false){?>
								    <label><?echo ucfirst(str_replace("_", " ", $col))?></label>
								    <?if($info[4]!=""){?>
								        <small><?echo $info[4]?></small>
								    <?}?>
								<?}?>
								<?if($info[0]=="input" && in_array($info[3], ["text", "email", "password", "number", "file", "date", "time", "color", "datetime"])){?>
								    <input type="<?echo $info[3]?>" name="<?echo $col?>" class="form-control" <?echo $info[1]?>  >
								<?}else if($info[0]=="select"){?>
								    <select name="<?echo $col?>" class="form-control" <?echo $info[1]?>  >
    								    <?foreach($info[2] as $i=> $option){?>
    								        <option value="<?echo $i?>"><?echo $option?></option>
    								    <?}?>
								    </select>
								<?}else if($info[0]=="input" && in_array($info[3], ["image"])){?>
								    <input type="file" name="<?echo $col?>" class="form-control" <?echo $info[1]?>  >
								<?}else if($info[0]=="textarea"){?>
								    <textarea type="text" name="<?echo $col?>" class="form-control" <?echo $info[1]?>  ></textarea>
								<?}else{?>
								    <code><?echo $col?> Couldn't render</code>
								<?}?>
							</div>
							<?}?>
						
							<input type="text" name="actionId" value="" hidden>
							
						</div>
						<div class="kt-portlet__foot">
							<div class="kt-form__actions">
								<input type="submit" name="create_package" value="Submit" class="btn btn-primary">
								<button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
							</div>
						</div>
					</form>
				</div>
			
			</div>
		</div>
	</div>
	
	
	
	<script>
	    $(document).ready(function(){

	    
          $("#create_record_modal").on('show.bs.modal', function (e) {
            //get data-id attribute of the clicked element
            var mydata = $(e.relatedTarget).data('mydata');
            console.log(mydata);
            //console.log("mydata", mydata)
            if(mydata!= null){
            	$("#modelTitle").html("Update");
            	<?foreach($arrayFields_crud as $col => $info){
            	    if((strpos($info[1], "hidden")==false) && !in_array($info[3], ["file", "image"])){?>
                        $("<?echo $info[0]?>[name='<?echo $col?>']").val(mydata['<?echo $col?>'])
                <?}}?>
               
                $("input[name='actionId']").val(mydata['id'])


            }else{
            	$("#modelTitle").html("Insert");
                $("input[name='actionId']").val("")
                <?foreach($arrayFields_crud as $col => $info){
                    if((strpos($info[1], "hidden")==false) && !in_array($info[3], ["file", "image"])){?>
                    $("<?echo $info[0]?>[name='<?echo $col?>']").val("")
                <?}}?>

                $("input[name='actionId']").val("")
                
            }

            
          });
	    })
	</script>
				
</html>