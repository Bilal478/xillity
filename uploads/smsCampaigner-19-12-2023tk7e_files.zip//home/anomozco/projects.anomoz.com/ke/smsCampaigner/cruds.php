<? require("./global.php");

?>
<!DOCTYPE html>


<html lang="en">

<!-- begin::Head -->

<head>
	<? require("./includes/views/head.php") ?>
</head>

<!-- end::Head -->

<!-- begin::Body -->

<body class="<? echo $g_body_class ?>" onload="">

	<? require("./includes/views/header.php") ?>

	<div class="kt-grid kt-grid--hor kt-grid--root">
		<div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--ver kt-page">
			<div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-wrapper" id="kt_wrapper">

				<!-- begin:: Header -->

				<? require("./includes/views/topmenu.php") ?>
				<!-- end:: Header -->

				<!-- begin:: Aside -->
				<? require("./includes/views/leftmenu.php") ?>

				<!-- end:: Aside -->
				<div class="kt-body kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-grid--stretch" id="kt_body">
					<div class="kt-content  kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor" id="kt_content">

						<!-- end:: Subheader -->

						<!-- begin:: Content -->
						<div class="kt-container  kt-grid__item kt-grid__item--fluid">


							<div class="row mb-5">
								<div class="col-md-12">
									<div class="hero-1-padding" style="border-radius:5px;padding:20px; height: 100%;background:#edf4fa;max-height: 392px;border: 1px <? echo $g_primaryColor ?> solid;border-bottom: 11px solid <? echo $g_primaryColor ?>;">
										<h2 class="h4"><strong>Customers</strong></h2>
										<input class="form-control w-100" placeholder="Search..." name="search_box">

									</div>
								</div>

							</div>

							<h1>Section 1</h1>
							<div class="row searchtable">
								<? $query = "select c.id, c.addedBy, c.name, c.email, c.phone, c.address from " . $g_projectSlug . "_users c 
    						        where c.role='customer' and c.addedBy like '%$session_userId_filter%' order by c.timeAdded desc limit 3";
								$results = getAll($con, $query);
								foreach ($results as $row) { ?>
									<div class="searchitem col-md-4">
										<!--begin:: Portlet-->
										<div class=" kt-portlet kt-portlet--height-fluid">
											<div class="kt-portlet__body kt-portlet__body--fit">

												<!--begin::Widget -->
												<div class="kt-widget kt-widget--project-1">
													<div class="kt-widget__head">
														<div class="kt-widget__label">
															<div class="kt-widget__media">
																<span class="kt-media kt-media--lg kt-media--circle">
																	<img src="./uploads/<? echo $row['profile_pic'] ?>" alt="Profile" class="mr-3 rounded-circle" style="width: 64px; height: 64px;object-fit: cover;" onerror="this.src='https://simg.nicepng.com/png/small/128-1280406_view-user-icon-png-user-circle-icon-png.png';">
																</span>
															</div>
															<div class="kt-widget__info kt-margin-t-5">
																<a href="#" class="kt-widget__title">
																	<? echo $row['email'] ?>
																</a>
																<span class="kt-widget__desc">
																	<? echo $row['name'] ?>
																</span>
															</div>
														</div>
													</div>
													<div class="kt-widget__body">
														<div class="kt-widget__stats">
															<div class="kt-widget__item">
																<span class="kt-widget__date">
																	Hourly Rate
																</span>
																<div class="kt-widget__label">
																	<span class="btn btn-label-brand btn-sm btn-bold btn-upper">$<? echo $row['hourly_rate'] ?> / hr</span>
																</div>
															</div>
															<div class="kt-widget__item">
																<span class="kt-widget__date">
																	Address
																</span>
																<div class="kt-widget__label">
																	<span class="btn btn-label-danger btn-sm btn-bold btn-upper"><? echo $row['address'] ?></span>
																</div>
															</div>
															<div class="kt-widget__item">
																<span class="kt-widget__date">
																	Address
																</span>
																<div class="kt-widget__label">
																	<span class="btn btn-label-warning btn-sm btn-bold btn-upper"><? echo $row['address'] ?></span>
																</div>
															</div>
														</div>
														<span class="kt-widget__text">
															I distinguish three main text objecttives.First, your objective could
															be merely to inform people.A second be to persuade people.
														</span>
													</div>
													<div class="kt-widget__footer">
														<div class="btn-group m-4">
															<a href="#" class="btn btn-primary">View Profile</a>
															<a href="#" class="btn btn-warning" data-toggle="modal" data-target="#create_record_modal" data-mydata='<? echo (json_encode($row, true)); ?>'>Edit</a>
															<a href="#" class="btn btn-danger" data-toggle="modal" data-target="#delete_record" data-url="?delete-record=<? echo $row['id'] ?>">Delete</a>

														</div>
													</div>
												</div>
											</div>
										</div>
										<!--end:: Portlet-->
									</div>
								<? } ?>
							</div>

							<h1>Section 2</h1>
							<div class="row searchtable">
								<? $query = "select c.id, c.addedBy, c.name, c.email, c.phone, c.address from " . $g_projectSlug . "_users c 
    						        where c.role='customer' and c.addedBy like '%$session_userId_filter%' order by c.timeAdded desc limit 3";
								$results = getAll($con, $query);
								foreach ($results as $row) { ?>
									<div class="searchitem col-md-12">
										<!--begin:: Portlet-->
										<div class=" kt-portlet kt-portlet--height-fluid">
											<div class="kt-portlet__body kt-portlet__body--fit">

												<!--begin::Widget -->
												<div class="kt-widget kt-widget--project-1">
													<div class="kt-widget__head pb-0">
														<div class="kt-widget__label">
															<div class="kt-widget__media">
																<span class="kt-media kt-media--lg kt-media--circle">
																	<img src="./uploads/<? echo $row['profile_pic'] ?>" alt="Profile" class="mr-3 rounded-circle" style="width: 64px; height: 64px;object-fit: cover;" onerror="this.src='https://simg.nicepng.com/png/small/128-1280406_view-user-icon-png-user-circle-icon-png.png';">
																</span>
															</div>
															<div class="kt-widget__info kt-margin-t-5">
																<a href="#" class="kt-widget__title">
																	<? echo $row['email'] ?>
																</a>
																<span class="kt-widget__desc">
																	<? echo $row['name'] ?>
																</span>
															</div>
														</div>
													</div>
													<div class="kt-widget__body pb-3">
														<div class="kt-widget__stats">
															<div class="kt-widget__item pt-1">
																<span class="kt-widget__date">
																	Hourly Rate
																</span>
																<div class="kt-widget__label">
																	<span class="btn btn-label-brand btn-sm btn-bold btn-upper">$<? echo $row['hourly_rate'] ?> / hr</span>
																</div>
															</div>
															<div class="kt-widget__item pt-1">
																<span class="kt-widget__date">
																	Address
																</span>
																<div class="kt-widget__label">
																	<span class="btn btn-label-danger btn-sm btn-bold btn-upper"><? echo $row['address'] ?></span>
																</div>
															</div>
															<div class="kt-widget__item pt-1">
																<span class="kt-widget__date">
																	Address
																</span>
																<div class="kt-widget__label">
																	<span class="btn btn-label-warning btn-sm btn-bold btn-upper"><? echo $row['address'] ?></span>
																</div>
															</div>
														</div>
														<span class="kt-widget__text mt-4">
															I distinguish three main text objecttives.First, your objective could
															be merely to inform people.A second be to persuade people.
														</span>
													</div>
													<div class="kt-widget__footer">
														<div class="btn-group m-4">
															<a href="#" class="btn btn-primary">View Profile</a>
															<a href="#" class="btn btn-warning" data-toggle="modal" data-target="#create_record_modal" data-mydata='<? echo (json_encode($row, true)); ?>'>Edit</a>
															<a href="#" class="btn btn-danger" data-toggle="modal" data-target="#delete_record" data-url="?delete-record=<? echo $row['id'] ?>">Delete</a>

														</div>
													</div>
												</div>
											</div>
										</div>
										<!--end:: Portlet-->
									</div>
								<? } ?>
							</div>

							<h1>Section 3</h1>
							<?php $query = "select * from kemiScooly_programs t order by t.timeAdded desc limit 3";
							$results = getAll($con, $query);
							?>

							<div class="row searchtable ">

								<? foreach ($results as $row) { ?>
									<div class="col-md-4 searchitem">
										<div class="kt-portlet kt-portlet--height-fluid" style="background-color:<? echo $color ?>;">

											<div class="kt-portlet__body my-4" style="padding: 33px">
												<!--begin::Widget -->
												<div class="kt-widget kt-widget--user-profile-2" style="top: 20px;position: relative;">
													<div class="kt-widget__head">
														<div class="kt-widget__media">
															<img onerror="this.src='https://www.pulsecarshalton.co.uk/wp-content/uploads/2016/08/jk-placeholder-image.jpg';" src="./uploads/<?php echo $row['course_image']; ?>" class="img-thumbnail" style="width:100px"><br>
														</div>
														<div class="kt-widget__info">
															<a href="#" class="kt-widget__titel kt-hidden-">
																<? echo $row['title'] ?>
															</a>
															<a href="#" class="kt-widget__username kt-hidden">
															</a>
															<span class="kt-widget__desc">
																<? echo $row['sub_title'] ?>
															</span>
														</div>
													</div>
													<div class="kt-widget__body">
														<div class="kt-widget__section">
														</div>
														<div class="kt-widget__item">
															<div class="kt-widget__contact">
																<span class="kt-widget__label">Location:</span>
																<a href="" class="kt-widget__data">
																	<? echo $row['address'] ?>
																</a>
															</div>

															<div class="kt-widget__contact">
																<span class="kt-widget__label">Gross tuition fee:</span>
																<a href="" class="kt-widget__data">
																	$<? echo $row['gross_tuition'] ?>
																</a>
															</div>
															<div class="kt-widget__contact">
																<span class="kt-widget__label">Application fee:</span>
																<a href="" class="kt-widget__data">
																	$<? echo $row['application_fee'] ?>
																</a>
															</div>
															<div class="kt-widget__contact">
																<span class="kt-widget__label">Commission:</span>
																<a href="" class="kt-widget__data">
																	<? echo $row['commission'] ?>
																</a>
															</div>
															<div class="kt-widget__contact">
																<span class="kt-widget__label">Duration:</span>
																<a href="" class="kt-widget__data"><? echo $row['program_length'] ?></a>
															</div>

														</div>
													</div>
													<div class="kt-widget__footera">
														<a href="./view_program.php?id=<? echo $row['id'] ?>" class="btn btn-sm  btn-primary text-white">View program</a>
														<? if ($session_role == "admin") { ?>
															<a href="#" class="btn btn-warning  btn-sm " data-toggle="modal" data-target="#create_record_modal" data-mydata='<?php echo  htmlspecialchars(json_encode($row, JSON_UNESCAPED_UNICODE)); ?>'>Edit</a>
															<a href="#" class="btn btn-danger btn-sm " data-toggle="modal" data-target="#delete_record" data-url="?<? echo generateUrlParams() ?>delete-record=<?php echo $row['id'] ?>">Delete</a>

														<? } ?>
													</div>
													<!--end::Widget -->
												</div>
											</div>
										</div>

									</div>
								<? } ?>

							</div>

							<h1>Section 4</h1>
							<div class="row searchtable">
								<? $query = "select c.id, c.addedBy, c.name, c.email, c.phone, c.address from " . $g_projectSlug . "_users c 
    						        where c.role='customer' and c.addedBy like '%$session_userId_filter%' order by c.timeAdded desc limit 3";
								$results = getAll($con, $query);
								foreach ($results as $row) { ?>
									<div class="searchitem col-md-4">
										<div class="kt-portlet kt-portlet--height-fluid kt-widget19">
											<div class="kt-portlet__body kt-portlet__body--fit kt-portlet__body--unfill">
												<div class="kt-widget19__pic kt-portlet-fit--top kt-portlet-fit--sides" style="min-height: 300px; background-image: url('https://projects.anomoz.com/ke/demo9/assets/media//products/product4.jpg')">
													<h3 class="kt-widget19__title kt-font-light">
														Introducing New Feature
													</h3>
													<div class="kt-widget19__shadow"></div>
													<div class="kt-widget19__labels">
														<a href="#" class="btn btn-primary btn-bold ">Recent</a>
													</div>
												</div>
											</div>
											<div class="kt-portlet__body">
												<div class="kt-widget19__wrapper">
													<div class="kt-widget19__content">
														<div class="kt-widget19__userpic">
															<img src="assets/media/users/user1.jpg" onerror="this.src='https://simg.nicepng.com/png/small/128-1280406_view-user-icon-png-user-circle-icon-png.png';" alt="">
														</div>
														<div class="kt-widget19__info">
															<a href="#" class="kt-widget19__username">
																Anna Krox
															</a>
															<span class="kt-widget19__time">
																UX/UI Designer, Google
															</span>
														</div>
														<div class="kt-widget19__stats">
															<span class="kt-widget19__number kt-font-brand">
																18
															</span>
															<a href="#" class="kt-widget19__comment">
																Comments
															</a>
														</div>
													</div>
													<div class="kt-widget19__text">
														Lorem Ipsum is simply dummy text of the printing and typesetting scrambled a type specimen book text of the dummy text of the printing printing and typesetting industry scrambled dummy text of the printing.
													</div>
												</div>
												<div class="kt-widget19__action">
													<a href="#" class="btn btn-sm btn-label-brand btn-bold">Read More...</a>
												</div>
											</div>
										</div>
									</div>
								<? } ?>
							</div>

							<h1>Section 5</h1>
							<div class="kt-portlet kt-portlet--height-fluid">
								<div class="kt-portlet__head">
									<div class="kt-portlet__head-label">
										<h3 class="kt-portlet__head-title">
											Best Sellers
										</h3>
									</div>

								</div>
								<div class="kt-portlet__body">
									<div class="tab-content">
										<div class="tab-pane active" id="kt_widget5_tab1_content" aria-expanded="true">
											<div class="kt-widget5 searchtable">
												<? $query = "select c.id, c.addedBy, c.name, c.email, c.phone, c.address from " . $g_projectSlug . "_users c 
                            						        where c.role='customer' and c.addedBy like '%$session_userId_filter%' order by c.timeAdded desc limit 3";
												$results = getAll($con, $query);
												foreach ($results as $row) { ?>
													<div class="kt-widget5__item searchitem">
														<div class="kt-widget5__content">
															<div class="kt-widget5__pic">
																<img class="kt-widget7__img" src="https://projects.anomoz.com/ke/demo9/assets/media/products/product27.jpg" alt="">
															</div>
															<div class="kt-widget5__section">
																<a href="#" class="kt-widget5__title">
																	Great Logo Designn
																</a>
																<p class="kt-widget5__desc">
																	Metronic admin themes.
																</p>
																<div class="kt-widget5__info">
																	<span>Author:</span>
																	<span class="kt-font-info">Keenthemes</span>
																	<span>Released:</span>
																	<span class="kt-font-info">23.08.17</span>
																</div>
															</div>
														</div>
														<div class="kt-widget5__content">
															<div class="kt-widget5__stats">
																<span class="kt-widget5__number">19,200</span>
																<span class="kt-widget5__sales">sales</span>
															</div>
															<div class="kt-widget5__stats">
																<span class="kt-widget5__number">1046</span>
																<span class="kt-widget5__votes">votes</span>
															</div>
														</div>
													</div>
												<? } ?>

											</div>
										</div>
									</div>
								</div>
							</div>

							<h1>Section 6</h1>
							<div class="kt-portlet kt-portlet--tabs kt-portlet--height-fluid">
								<div class="kt-portlet__head">
									<div class="kt-portlet__head-label">
										<h3 class="kt-portlet__head-title">
											New Users
										</h3>
									</div>
								</div>
								<div class="kt-portlet__body">
									<div>
										<div class="tab-pane" id="kt_widget4_tab1_content">
											<div class="kt-widget4">
												<? $query = "select c.id, c.addedBy, c.name, c.email, c.phone, c.address from " . $g_projectSlug . "_users c 
                    						        where c.role='customer' and c.addedBy like '%$session_userId_filter%' order by c.timeAdded desc limit 3";
												$results = getAll($con, $query);
												foreach ($results as $row) { ?>
													<div class="kt-widget4__item">
														<div class="kt-widget4__pic kt-widget4__pic--pic">
															<img src="https://projects.anomoz.com/ke/demo9/assets/media/users/100_1.jpg" alt="">
														</div>
														<div class="kt-widget4__info">
															<a href="#" class="kt-widget4__username">
																Nick Stone
															</a>
															<p class="kt-widget4__text">
																Visual Designer, Github Inc
															</p>
														</div>
														<a href="#" class="btn btn-sm btn-label-primary btn-bold">Follow</a>
													</div>
												<? } ?>
											</div>
										</div>
									</div>
								</div>
							</div>

							<h1>Section 7</h1>
							<div class="kt-portlet">
								<div class="kt-portlet__body  kt-portlet__body--fit">
									<div class="row row-no-padding row-col-separator-lg">
										<div class="col-md-3">
											<div class="kt-widget24">
												<div class="kt-widget24__details">
													<div class="kt-widget24__info">
														<h4 class="kt-widget24__title">
															Total Profit
														</h4>
														<span class="kt-widget24__desc">
															All Customs Value
														</span>
													</div>
													<span class="kt-widget24__stats kt-font-brand">
														$18M
													</span>
												</div>
												<div class="progress progress--sm">
													<div class="progress-bar kt-bg-brand" role="progressbar" style="width: 100%;" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
												</div>
											</div>
										</div>
										<div class="col-md-3">
											<div class="kt-widget24">
												<div class="kt-widget24__details">
													<div class="kt-widget24__info">
														<h4 class="kt-widget24__title">
															New Feedbacks
														</h4>
														<span class="kt-widget24__desc">
															Customer Review
														</span>
													</div>
													<span class="kt-widget24__stats kt-font-warning">
														1349
													</span>
												</div>
												<div class="progress progress--sm">
													<div class="progress-bar kt-bg-warning" role="progressbar" style="width: 100%;" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
												</div>
											</div>
										</div>
										<div class="col-md-3">
											<div class="kt-widget24">
												<div class="kt-widget24__details">
													<div class="kt-widget24__info">
														<h4 class="kt-widget24__title">
															New Orders
														</h4>
														<span class="kt-widget24__desc">
															Fresh Order Amount
														</span>
													</div>
													<span class="kt-widget24__stats kt-font-danger">
														567
													</span>
												</div>
												<div class="progress progress--sm">
													<div class="progress-bar kt-bg-danger" role="progressbar" style="width: 100%;" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
												</div>
											</div>
										</div>
										<div class="col-md-3">
											<div class="kt-widget24">
												<div class="kt-widget24__details">
													<div class="kt-widget24__info">
														<h4 class="kt-widget24__title">
															New Users
														</h4>
														<span class="kt-widget24__desc">
															Joined New User
														</span>
													</div>
													<span class="kt-widget24__stats kt-font-success">
														276
													</span>
												</div>
												<div class="progress progress--sm">
													<div class="progress-bar kt-bg-success" role="progressbar" style="width: 100%;" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>

						</div>



						<!-- end:: Content -->
					</div>
				</div>

				<!-- begin:: Footer -->

				<? require("./includes/views/footer.php") ?>

				<!-- end:: Footer -->
			</div>
		</div>
	</div>


	<? require("./includes/views/footerjs.php") ?>
	<script>
		$("input[name=search_box]").on("keyup", function() {
			var value = $(this).val().toLowerCase();
			$(".searchtable .searchitem").filter(function() {
				$(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
			});
		});
	</script>
</body>

<!-- end::Body -->

</html>