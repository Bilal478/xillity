<? require("./global.php");

//dont add for 
require_once('./vendor/autoload.php');

if(checkGlobalPermission('enablePaypal')){
    require_once('./paypalvendor/vendor/autoload.php');
}

$pId = $_GET['pId'];
$paymentDeets = getRow($con, "Select * from ".$g_projectSlug."_payments where id='$pId'");

//authorize net
define("API_LOGIN_ID", "4MvJh247Y");
define("TRANSACTION_KEY", "33bGJ874k76aYJbX");

$stripe = new \Stripe\StripeClient([
    "api_key" => $g_stripeCred['private_test_key'], 
    "stripe_version" => "2020-08-27"
    ]
);


// var_dump($_POST);
if(isset($_GET['pay_amount'])){
    $amount = mb_htmlentities($_GET['pay_amount']);
    $allow_direct_payment = mb_htmlentities($_GET['allow_direct_payment']);
    
    if (checkGlobalPermission('enableInvoices')) {
        $allow_direct_payment = mb_htmlentities($_GET['invoiceId']); 
    }
    
    
    $title = "Payment of USD $amount";
    $id = generateRandomString();
    $query = "insert into ".$g_projectSlug."_payments set id='$id', userId='$session_userId', title='$title', amount='$amount', status='Pending',
    method='', debitcredit='credit', devnote='$allow_direct_payment', timeAdded='$timeAdded' ";
    $stmt = $con->prepare($query);
    if(!$stmt){echo "err: <code>$query</code>";}
    if(!$stmt->execute()){echo "err: <code>$query</code>";}
    
    header("Location: ?pId=$id");
}

//paypal return url
if (!empty($_GET['status'])) {
    if($_GET['status'] == "success") {
        $token = $_GET['token'];
        $agreement = new \PayPal\Api\Agreement();
        
        try {
            // Execute agreement
            $agreement->execute($token, $apiContext);
            echo "here1";
            var_dump($agreement);
        } catch (PayPal\Exception\PayPalConnectionException $ex) {
            echo $ex->getCode();
            echo $ex->getData();
            die($ex);
        } catch (Exception $ex) {
            die($ex);
        }
    } else {
        echo "user canceled agreement";
    }
    exit;
}


if(isset($_GET['stripe_session_id'])){

    $var = $stripe->checkout->sessions->retrieve(
        $_GET['stripe_session_id'],
      []
    );
    $subscriptionId = $var['subscription'];
    
    $query = "update ".$g_projectSlug."_payments set payment_type='subscription', subscription_id='$subscriptionId' where id='$pId' ";
    $stmt = $con->prepare($query);
    if(!$stmt){echo "err: <code>$query</code>";}
    if(!$stmt->execute()){echo "err: <code>$query</code>";}
}

if(isset($_GET['cancel_stripe_subscription'])){
    
    $cancel_stripe_subscription = $_GET['cancel_stripe_subscription'];
    $stripe->subscriptions->cancel(
      $cancel_stripe_subscription,
      []
    );

    $query = "update ".$g_projectSlug."_payments set status='cancelled' where subscription_id='$cancel_stripe_subscription' ";
    $stmt = $con->prepare($query);
    if(!$stmt){echo "err: <code>$query</code>";}
    if(!$stmt->execute()){echo "err: <code>$query</code>";}
    
    header("Location: ?m=Subscription cancelled successfully");
    exit();
    
}
if(isset($_POST['pay_amount_checkout'])){
    
    
    $amount = mb_htmlentities($paymentDeets['amount']);
    $method = mb_htmlentities($_POST['method']);
    
    if($g_modules_global['enableCoupons']){
        $coupon_code = mb_htmlentities($_POST['coupon_code']);
        
        $discount = getRow($con, "select * from ".$g_projectSlug."_coupons where coupon_code='$coupon_code' and is_used='no'")['discount'];
        if($discount==""){$discount=0;}
        
        $time = time();
        getRow($con, "update ".$g_projectSlug."_coupons set is_used='yes' where coupon_code='$coupon_code', used_by='$session_userId', used_on='$time' ");

        $amount-=$discount;        
    }
    
    
    $query = "update ".$g_projectSlug."_payments set method='$method' where id='$pId'";
    $stmt = $con->prepare($query);
    if(!$stmt){echo "err: <code>$query</code>";}
    if(!$stmt->execute()){echo "err: <code>$query</code>";}
    
    $successUrl = $g_website."/payment.php?pId=$pId&enc=".md5($pId);
    $cancel_url = $g_website.'/home.php?m=Payment Failed';
    if($method=="stripe"){
        
        //subscription
        if(checkGlobalPermission('paymentType') == "subscription" && false){
            $checkout_session = $stripe->checkout->sessions->create([
                'line_items' => [[
                  'price' => 'price_1Gz0gSHQjkfG1DwO6Jmax6oW',
                  'quantity' => 1,
                ]],
                'mode' => 'subscription',
                'success_url' => $successUrl.'&stripe_session_id={CHECKOUT_SESSION_ID}',
                'cancel_url' => $cancel_url,
              ]);
            
            header("HTTP/1.1 303 See Other");
            header("Location: " . $checkout_session->url);
        }
  
        //product purchase
        if(checkGlobalPermission('paymentType') == "onetime" || true){
            echo "Redirecting onetime...";
            $customer = $stripe->customers->create([
                        'description' => $session_email,
                        // 'source'  => $token,
                    ]);
           
            $session = $stripe->checkout->sessions->create([
              'payment_method_types' => ['card'],
              'line_items' => [[
                'price_data' => [
                  'product' => $g_stripeCred['productCode'],
                  'unit_amount' => $amount*100,
                  'currency' => 'usd',
                ],
                'quantity' => 1,
              ]],
              'mode' => 'payment',
            //   'payment_intent_data' => [
            //         'on_behalf_of' => "acct_1OMnTfFNvQYUm5Ur",
            //     ],
              'success_url' => $successUrl,
              'cancel_url' => $cancel_url,
            ]);
        
        }
        //echo "Redirecting..."
        ?>
        <script src="https://js.stripe.com/v3/"></script>
                                            
        <script>
            var stripe = Stripe('<?echo $g_stripeCred['public_test_key']?>');
               stripe.redirectToCheckout({
                    sessionId: '<?echo $session['id']?>'
                  }).then(function (result) {

                  });
        </script>
        
        <?}
    else if($method=="paypal"){
        
        // test paypal account:
        // email: sb-px7777069750@personal.example.com
        // pass: 4O.f$Q<C
        
        if(checkGlobalPermission('paymentType') == "subscription"){
            
            $apiContext = new \PayPal\Rest\ApiContext(
              new \PayPal\Auth\OAuthTokenCredential(
                'AcZ8lMaFHmGVIW0shJnAlPa2WZM5u51JGKzujhtwh-c16EEWrfSjfXji0Qy9p71qorX6EV5XZxqTIunm', //CLIENT_ID
                'EIfCFpNzv6Im7hpKLBiCTeEktZAka77u3Fhvqw_LIaka9P8cvDyNFkdXMYZGoSGYQ-3d-tGWzf7BbIak' //CLIENT_SECRET
              )
            );
            
            if (true) {
                require_once "./vendor/paypalsubs/createPHPTutorialSubscriptionPlan.php";
            }
        }
        
        if(checkGlobalPermission('paymentType') == "onetime" && false){
            define('PAYPAL_BUSINESS_ID', 'sb-4343bz36884719@business.example.com'); 
            define('PAYPAL_SANDBOX', TRUE); //TRUE or FALSE 
            define('PAYPAL_CURRENCY', 'USD'); 
            define('PAYPAL_URL', (PAYPAL_SANDBOX == true)?"https://www.sandbox.paypal.com/cgi-bin/webscr":"https://www.paypal.com/cgi-bin/webscr");
    
            echo "Redirecting...";
            exit();
            ?>
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    
            <form action="<?php echo PAYPAL_URL; ?>" method="post" id="paypalForm">
                <input type="hidden" name="business" value="<?php echo PAYPAL_BUSINESS_ID; ?>">
                <!-- Important For PayPal Checkout -->
                <input hidden type="text" name="item_name" id="item" required value="Payment for Something">
                <input hidden type="text" required="" name="amount" id="amountTocharge" value="<?php echo $amount;?>">
                <input type="hidden" name="currency_code" value="<?php echo PAYPAL_CURRENCY; ?>">
                <input type="hidden" name="cmd" value="_xclick">
                <!--pass the product id in the return url just like we did with stripe checkout-->
                <input type="hidden" name="return" id="paypalSuccessUrl" value="<?php echo $successUrl;?>">
                <input type="hidden" name="cancel_return" id="paypalCancelUrl" value="<?php echo $cancel_url;?>">
                <br><br>
                <!-- Display the payment button. -->
                <!--<input type="submit" name="submit" border="0">-->
            </form>
            <script>
                $(document).ready(function(e){
                    $("#paypalForm").submit();
                });
            </script>
            <?php
        }
    }
    else if($method=="authorizenet"){
         
        require_once './includes/AuthorizeNetPayment.php';
        $authorizeNetPayment = new AuthorizeNetPayment();
        $_POST['amount'] = $amount;
        $response = $authorizeNetPayment->chargeCreditCard($_POST);
        
        if ($response != null)
        {
            $tresponse = $response->getTransactionResponse();
            if (($tresponse != null) && ($tresponse->getResponseCode()=="1"))
            {
                $authCode = $tresponse->getAuthCode();
                $paymentResponse = $tresponse->getMessages()[0]->getDescription();
                $reponseType = "success";
                $message = "This transaction has been approved. <br/> Charge Credit Card AUTH CODE : " . $tresponse->getAuthCode() .  " <br/>Charge Credit Card TRANS ID  : " . $tresponse->getTransId() . "\n";
            }
            else
            {
                $authCode = "";
                $paymentResponse = $tresponse->getErrors()[0]->getErrorText();
                $reponseType = "error";
                $message = "Charge Credit Card ERROR :  Invalid response\n";
            }
            
            $transactionId = $tresponse->getTransId();
            $responseCode = $tresponse->getResponseCode();
            $paymentStatus = $authorizeNetPayment->responseText[$tresponse->getResponseCode()];
          
            $param_type = 'sssdss';
            // $param_value_array = array(
                $transactionId;
                // $authCode,
                // $responseCode,
                $paymentStatus;
                $paymentResponse;
                $amount=$paymentDeets['amount'];
            // );
           
            if($paymentStatus=="Approved"){
                header("Location: $successUrl");
                exit();
            }
        }
        else
        {
            $reponseType = "error";
            $message= "Charge Credit Card Null response returned";
        }
        header("Location: ?pId=$pId&m=$message");
        
        
    }
    else if($method=="ewallet"){
        $query = "update " . $g_projectSlug . "_users set e_wallet_balance=e_wallet_balance-'$amount' where id='$session_userId' ";
        $stmt = $con->prepare($query);
        if (!$stmt) {
            echo "err: <code>$query</code>";
        }
        if (!$stmt->execute()) {
            echo "err: <code>$query</code>";
        }
        header("Location: $successUrl");
    }
        

    }

if(isset($_GET['enc'], $_GET['pId'])){
    $amount = mb_htmlentities($paymentDeets['amount']);
    $devnote = mb_htmlentities($paymentDeets['devnote']);
    
    if(md5($_GET['pId'])==$_GET['enc']){
        $query = "update ".$g_projectSlug."_payments set status='Paid' where id='$pId' ";
        $stmt = $con->prepare($query);
        if(!$stmt){echo "err: <code>$query</code>";}
        if(!$stmt->execute()){echo "err: <code>$query</code>";}
        
        
        $query = "update ".$g_projectSlug."_invoices set status='paid' where id='$devnote' ";
        $stmt = $con->prepare($query);
        if(!$stmt){echo "err: <code>$query</code>";}
        if(!$stmt->execute()){echo "err: <code>$query</code>";}
        
        
        if($paymentDeets['devnote']=="deposit_to_wallet"){
            
            $query = "update ".$g_projectSlug."_users set e_wallet_balance=e_wallet_balance+'$amount' where id='$session_userId' ";
            $stmt = $con->prepare($query);
            if(!$stmt){echo "err: <code>$query</code>";}
            if(!$stmt->execute()){echo "err: <code>$query</code>";}
        
        
        }
    
        header("Location: ./home.php?m=Payment was successfull");
    }
}

?>
<!DOCTYPE html>


<html lang="en">

	<!-- begin::Head -->
	<head><?require("./includes/views/head.php")?>
	<style>
	  
#frmPayment {
    max-width: 300px;
    padding: 25px;
    border: #D0D0D0 1px solid;
    border-radius: 4px;
}

.test-data {
    margin-top: 40px;
}

.tutorial-table {
    border: #D0D0D0 1px solid;
    font-size: 0.8em;
    color: #4e4e4e;
}

.tutorial-table th {
    background: #efefef;
    padding: 12px;
    border-bottom: #e0e0e0 1px solid;
    text-align: left;
}

.tutorial-table td {
    padding: 12px;
    border-bottom: #D0D0D0 1px solid;
}

#frmPayment .field-row {
    margin-bottom: 20px;
}

#frmPayment div label {
    margin: 5px 0px 0px 5px;
    color: #49615d;
    width: auto;
}

.demoInputBox {
    padding: 10px;
    border: #d0d0d0 1px solid;
    border-radius: 4px;
    background-color: #FFF;
    width: 100%;
    margin-top: 5px;
    box-sizing:border-box;
}

.demoSelectBox {
    padding: 10px;
    border: #d0d0d0 1px solid;
    border-radius: 4px;
    background-color: #FFF;
    margin-top: 5px;
}

select.demoSelectBox {
    height: 35px;
    margin-right: 10px;
}

.info {
    font-size: .8em;
    color: #FF6600;
    letter-spacing: 2px;
    padding-left: 5px;
}

.btnAction {
   	background-color: #ff7000;
    padding: 10px 40px;
    color: #FFF;
    border: #ef6901 1px solid;
    border-radius: 4px;
    cursor: pointer;
}

.column-right {
    margin-right: 6px;
}

.contact-row {
    display: inline-block;
}

.cvv-input {
    width: 60px;
}

#error-message {
    margin: 0px 0px 10px 0px;
    padding: 5px 25px;
    border-radius: 4px;
    line-height: 25px;
    font-size: 0.9em;
    color: #ca3e3e;
    border: #ca3e3e 1px solid;
    display: none;
    width: 300px;
}

#response-message {
    margin: 0px 0px 10px 0px;
    padding: 5px 25px;
    border-radius: 4px;
    line-height: 25px;
    font-size: 0.9em;
    width: 300px;
}

.success {
    color: #3da55d;
    border: #43b567 1px solid;
}

.error {
    color: #ca3e3e;
    border: #ca3e3e 1px solid;
}

.display-none {
    display:none;
}

#loader {
    display: none;
}

#loader img {
    width: 45px;
    vertical-align: middle;
}
	</style>

</head>

	<!-- end::Head -->

	<!-- begin::Body -->
	<body class="<?echo $g_body_class?>">

		<?require("./includes/views/header.php")?>
        
        	<div class="kt-grid kt-grid--hor kt-grid--root">
			<div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--ver kt-page">
				<div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-wrapper" id="kt_wrapper">

					<!-- begin:: Header -->
					
                    <?require("./includes/views/topmenu.php")?>
					<!-- end:: Header -->

					<!-- begin:: Aside -->
					<?require("./includes/views/leftmenu.php")?>

					<!-- end:: Aside -->
					<div class="kt-body kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-grid--stretch" id="kt_body">
						<div class="kt-content  kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor" id="kt_content">

							<!-- end:: Subheader -->

							<!-- begin:: Content -->
							<div class="kt-container  kt-grid__item kt-grid__item--fluid">
							    <div class="row">
							        <div class='col-md-4'></div>
							        <div class='col-md-4'>
							            
							            <?if(isset($_GET['m'])){?>
        							        <div class="alert alert-info"><?echo $_GET['m']?></div>
        							    <?}?>
        							    
        							    <?if(isset($_GET['pId'] )|| isset($_GET['allow_direct_payment']))
        							    {?>
							            <div class="kt-portlet kt-portlet--mobile">
        									<div class="kt-portlet__head kt-portlet__head--lg">
        										<div class="kt-portlet__head-label">
        											<span class="kt-portlet__head-icon">
        											</span>
        											<h3 class="kt-portlet__head-title">
        											    <?if(!isset($_GET['pId'])){?>
        										            Add Amount
        										      <?}else if(isset($_GET['pId'])){?>
        										            <?echo $paymentDeets['title']?>
        										      <?}?>
        											</h3>
        										</div>
        										<div class="kt-portlet__head-toolbar">
        											<div class="kt-portlet__head-wrapper">
        												<div class="kt-portlet__head-actions">
        												    
        												   
        															
        												</div>
        											</div>
        										</div>
        									</div>
        									<div class="kt-portlet__body">
        									    
        									    <?if(!isset($_GET['pId']) && isset($_GET['allow_direct_payment'])){?>
                                                    <form action="" method="get">
                									    <input type = "number" class = "form-control" name="pay_amount"  min="1" placeholder = "Enter Amount">
                									    <input type = "text" class = "form-control" name="allow_direct_payment" value="<?echo $_GET['allow_direct_payment']?>" hidden>
                                                        <button type = "submit" class = "btn-block btn btn-primary my-2">Submit</button>
                                                    </form>
                                                <?}else if(isset($_GET['pId'])){?>
                                                
                                                    <form action="" method="post">
                                                        <h5>Pay Now!</h5>
                                                        <input readonly type = "number" class = "form-control" name="pay_amount_checkout"  min="1" placeholder = "Enter Amount" value="<?echo $paymentDeets['amount']?>">
                                                        <?if($g_modules_global['enableCoupons']){?>
                                                            <input type = "text" class = "mt-2 form-control" name="coupon_code" placeholder = "Enter Coupon" >
                                                        
                                                        <?}?>
                                                        <hr>
                                                        <?if(checkGlobalPermission('enableStripe')){?>
                                                            <button name="method" value="stripe" type = "submit" class = "btn-block btn btn-primary my-2">Pay with Card</button>
                                                        <?}?>
                                                        <?if(checkGlobalPermission('enablePaypal')){?>
                                                            <button name="method" value="paypal" type = "submit" class = "btn-block btn btn-primary my-2">Pay with Paypal</button>
                                                        <?}?>
                                                        <?if(checkGlobalPermission('enableAuthorizeNet')){?>
                                                        
                                                            <div>
                                                            <div class="field-row">
                                                                <label>Card Number</label> <span
                                                                    id="card-number-info" class="info"></span><br> <input
                                                                    type="text" id="card-number" name="card-number"
                                                                    class="form-control">
                                                            </div>
                                                            <div class="field-row">
                                                                <div class="contact-row column-right">
                                                                    <label>Expiry Month / Year / CVV</label> <span
                                                                        id="userEmail-info" class="info"></span><br>
                                                                        
                                                                    <div class="row">
                                                                        <div class="col-md-4">
                                                                    
                                                                            <select name="month" id="month"
                                                                                class="form-control">
                                                                                <option value="09">09</option>
                                                                                <option value="10">10</option>
                                                                                <option value="11">11</option>
                                                                                <option value="12">12</option>
                                                                            </select>
                                                                        </div>
                                                                        <div class="col-md-4">
                                                                            <select name="year" id="year"
                                                                                class="form-control">
                                                                                <option value="2018">2018</option>
                                                                                <option value="2019">2019</option>
                                                                                <option value="2020">2020</option>
                                                                                <option value="2021">2021</option>
                                                                                <option value="2022">2022</option>
                                                                                <option value="2023">2023</option>
                                                                                <option value="2024">2024</option>
                                                                                <option value="2025">2025</option>
                                                                                <option value="2026">2026</option>
                                                                                <option value="2027">2027</option>
                                                                                <option value="2028">2028</option>
                                                                                <option value="2029">2029</option>
                                                                                <option value="2030">2030</option>
                                                                            </select>
                                                                        </div>
                                                                        <div class="col-md-4">
                                                                            <input type="password" name="cvv" class="form-control" placeholder="CVV">
                                                                        </div>
                                                                    </div>
                                                                     
                                                                   
                                                                </div>
                                                                 <div class="col ml-auto mt-2 ">
                                                                        
                                                                    </div>
                                                            </div>
                                                            <div>
                                                                <!--<input type="submit" name="pay_now" value="Submit"-->
                                                                <!--    id="submit-btn" class="btnAction">-->
                                            
                                                                <div id="loader">
                                                                    <img alt="loader" src="LoaderIcon.gif">
                                                                </div>
                                                            </div>
                                                            <!--<input type='hidden' name='amount' value='151.51'> -->
                                                        </div>
                                                        
            
                                                            <button  onSubmit="return cardValidation();" name="method" value="authorizenet" type = "submit" class = "btn-block btn btn-primary my-2">Pay with AuthorizeNet</button>
                                                            
                                                            
                                                            <?if($g_modules_global['enableAuthorizeNet']){?>
                                                            <table class="tutorial-table" cellspacing="0" cellpadding="0" width="100%">
                                                            <?php
                                                            $cards = [
                                                                ['number' => '4111111111111111', 'brand' => 'Visa'],
                                                                ['number' => '5424000000000015', 'brand' => 'Mastercard'],
                                                                ['number' => '370000000000002', 'brand' => 'American Express'],
                                                                ['number' => '6011000000000012', 'brand' => 'Discover'],
                                                                ['number' => '38000000000006', 'brand' => 'Diners Club/ Carte Blanche'],
                                                                ['number' => '3088000000000017', 'brand' => 'JCB'],
                                                            ];
                                                            
                                                            ?>
                                                            <table>
                                                                <tr>
                                                                    <th>CARD NUMBER</th>
                                                                    <th>BRAND</th>
                                                                </tr>
                                                                <?php foreach ($cards as $card) { ?>
                                                                    <tr>
                                                                        <td><?php echo $card['number']; ?></td>
                                                                        <td><?php echo $card['brand']; ?></td>
                                                                    </tr>
                                                                <?php } ?>
                                                            
                                                            </table>

            
                                                            <?}?>
                                                        <?}?>
                                                        
                                                        <?if(checkGlobalPermission('enableEwallet') && $paymentDeets['devnote']!="deposit_to_wallet"){?>
                                                            <button <?if($session_data['e_wallet_balance']<$paymentDeets['amount']){echo "disabled";}?>  name="method" value="ewallet"  type = "submit" class = "btn-block btn btn-primary my-2">Pay with Wallet</button>
                                                            <small>Current Balance: <?echo $session_data['e_wallet_balance']?></small>
                                                            <?if(checkGlobalPermission('enableDepositeEwallet')){?>
                                                            <Br>
                                                                <a class="badge badge-info" href="?allow_direct_payment=deposit_to_wallet">Deposit to E-Wallet</a>
                                                            <?}?>
                                                        <?}?>
                                                        
                                                    </form>
                                                    
                                                     <img style="margin:5px auto;display:flex;" class="w-100" src="https://projects.anomoz.com/commonAssets/undraw_pay_online_re_aqe6.svg">


                                                    
                                                <?}?>
        									</div>
        								</div>
        								
        								<img style="margin:5px auto;display:flex;height: 30px;" src="https://projects.anomoz.com/commonAssets/payment-methods.png">
        								<?}?>
        								
        								
        								<?if(checkGlobalPermission('enableEwallet')){?>
                                            <small>Current Balance: <?echo $session_data['e_wallet_balance']?></small>
                                            <?if(checkGlobalPermission('enableDepositeEwallet')){?>
                                            <Br>
                                                <a class="badge badge-info mb-3" href="?allow_direct_payment=deposit_to_wallet">Deposit to E-Wallet</a>
                                            <?}?>
                                        <?}
                                        
                                        if($g_modules_global['enablePaymentHistory']){?>
        								<div class="kt-portlet kt-portlet--mobile">
        									<div class="kt-portlet__head kt-portlet__head--lg">
        										<div class="kt-portlet__head-label">
        											<span class="kt-portlet__head-icon">
        											</span>
        											<h3 class="kt-portlet__head-title">
        											    Payment History
        											</h3>
        										</div>
        										<div class="kt-portlet__head-toolbar">
        											<div class="kt-portlet__head-wrapper">
        												<div class="kt-portlet__head-actions">
        												 
        															
        												</div>
        											</div>
        										</div>
        									</div>
        									<div class="kt-portlet__body">
        									        
        									   <table class="table ">
        									       <tr>
        									           <th>Title</th>
        									           <th>Date / Time</th>
        									       </tr>
        									       <?foreach(getAll($con, "select * from ".$g_projectSlug."_payments where userId='$session_userId' and status='Paid'") as $row){?>
        									            <tr>
        									                <td>
        									                    <?echo $row['title']?>
        									                    <?if( checkGlobalPermission('paymentType') == "subscription" && $row['payment_type']=="subscription" && $row['status']=="Paid"){?>
        									                        <a href="?cancel_stripe_subscription=<?echo $row['subscription_id']?>" class="btn btn-danger btn-sm">Cancel Subscription</a>
        									                    <?}?>
        									                </td>
        									                <td><?echo date("d M Y h:i" , $row['timeAdded'])?></td>
        									            </tr>
        									       <?}?>
        									   </table>
        									</div>
        								</div>
        								<?}?>
        								
							        </div>
							        <div class='col-md-4'></div>
							    </div>
							    
							</div>

							
							

							<!-- end:: Content -->
						</div>
					</div>

					<!-- begin:: Footer -->
					
					<?require("./includes/views/footer.php")?>

					<!-- end:: Footer -->
				</div>
			</div>
		</div>
        
        
        <?require("./includes/views/footerjs.php")?>
		

	</body>

	<!-- end::Body -->
	
	
				
<script src="article-editor.min.js"></script>

<script>
function cardValidation () {
    var valid = true;
    var cardNumber = $('#card-number').val();
    var month = $('#month').val();
    var year = $('#year').val();

    $("#error-message").html("").hide();

    if (cardNumber.trim() == "") {
    	   valid = false;
    }

    if (month.trim() == "") {
    	    valid = false;
    }
    if (year.trim() == "") {
        valid = false;
    }

    if(valid == false) {
        $("#error-message").html("All Fields are required").show();
    }

    return valid;
}
</script>

</html>