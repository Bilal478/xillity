<? require("./global.php");

if(isset($_GET['connect'])){
    //dont add for 
    require_once('./vendor/autoload.php');
    $stripe = new \Stripe\StripeClient([
        "api_key" => $g_stripeCred['private_test_key'], 
        "stripe_version" => "2020-08-27"
        ]
    );
    
    // Replace 'YOUR_REDIRECT_URI' with your actual redirect URI after onboarding is complete
    $redirectUri = 'https://projects.anomoz.com/ke/smsCampaigner/test_stripe_connect.php';
    
    // The connected account ID
    $connectedAccountId = 'acct_1OMnTfFNvQYUm5Ur'; // Replace with your connected account ID
    
    // Create a redirect link for Express onboarding
    $loginLink = $stripe->accountLinks->create([
        'account' => $connectedAccountId,
        'refresh_url' => $redirectUri,
        'return_url' => $redirectUri,
        'type' => 'account_onboarding',
    ]);
    
    // Redirect the user to the Express onboarding link
    header("Location: " . $loginLink->url);
    exit;
}