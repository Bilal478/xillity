<?  require("./global.php");
$activeShift=getRow($con,"select * from ".$g_projectSlug."_work_shifts where userId='$session_id' && status='Active'");
if(isset($_GET['start_shift']))
{
    $id=generateRandomString();
    $start_time=time();
    $timeAdded=time();
    $userId=$session_id;
    
    $query="insert into ".$g_projectSlug."_work_shifts set id='$id',start_time='$start_time',status='Active',userId='$userId',timeAdded='$timeAdded'";
    $result=$con->query($query);
    
    $query="update ".$g_projectSlug."_users set work_shift_status='Active' where id='$session_id'";
    $result=$con->query($query);
    
    header("Location:?m=added");
}
if(isset($_GET['end_shift']))
{
    $shiftId=$activeShift['id'];
    
    $end_time=time();
    $query="update ".$g_projectSlug."_work_shifts set end_time='$end_time',status='Completed' where id='$shiftId'";
    $result=$con->query($query);
    
    $query="update ".$g_projectSlug."_users set work_shift_status='Inactive' where id='$session_id'";
    $result=$con->query($query);
    
    header("Location:?m=stopped");
}
/*if(isset($_GET['delete-record']))
{
    $id=$_GET['delete-record'];   
    $shiftDeets=getRow($con,"select * from ".$g_projectSlug."_work_shifts where id='$id'");
    if($shiftDeets['status']=="Active")
    {
        $query="update ".$g_projectSlug."_users set work_shift_status='Inactive' where id='$session_id'";
        $result=$con->query($query);
    }
    $query="delete from ".$g_projectSlug."_work_shifts where id='$id'";
    $result=$con->query($query);
    
    header("Location:?m=deleted");
    
}*/

if(isset($_GET['start_lunch']))
{
    $query="update ".$g_projectSlug."_users set lunch_status='Active' where id='$session_id'";
    $result=$con->query($query);
    
    $shiftId=$activeShift['id'];
    
    $random=generateRandomString();
    $start_time=time();
    $query="insert into ".$g_projectSlug."_shift_details set id='$random',shift_id='$shiftId',type='Lunch',start_time='$start_time',status='Active',userId='$session_id'";
    $result=$con->query($query);

    header("Location:?m=lunch_started");
}
if(isset($_GET['end_lunch']))
{
    $query="update ".$g_projectSlug."_users set lunch_status='Inactive' where id='$session_id'";
    $result=$con->query($query);
    
    $shiftId=$activeShift['id'];
    
    $random=generateRandomString();
    $end_time=time();
    $query="update ".$g_projectSlug."_shift_details set end_time='$end_time',status='Completed' where type='Lunch' && shift_id='$shiftId'";
    $result=$con->query($query);

    header("Location:?m=lunch_ended");
}
if(isset($_GET['start_break']))
{
    $query="update ".$g_projectSlug."_users set break_status='Active' where id='$session_id'";
    $result=$con->query($query);
    
    $shiftId=$activeShift['id'];
    
    $random=generateRandomString();
    $start_time=time();
    $query="insert into ".$g_projectSlug."_shift_details set id='$random',shift_id='$shiftId',type='Break',start_time='$start_time',status='Active',userId='$session_id'";
    $result=$con->query($query);

    header("Location:?m=break_started");
}
if(isset($_GET['end_break']))
{
    $query="update ".$g_projectSlug."_users set break_status='Inactive' where id='$session_id'";
    $result=$con->query($query);
    
    $shiftId=$activeShift['id'];
    
    $random=generateRandomString();
    $end_time=time();
    $query="update ".$g_projectSlug."_shift_details set end_time='$end_time',status='Completed' where type='Break' && shift_id='$shiftId'";
    $result=$con->query($query);

    header("Location:?m=break_ended");
}


if(isset($_GET['shift_id'])){$shift_id=$_GET['shift_id'];}
    
$query="select * from ".$g_projectSlug."_work_shifts where id='$shift_id'";
$shiftDeets=getRow($con,$query);

?>
<!DOCTYPE html>


<html lang="en">

	<!-- begin::Head -->
	<head><?require("./includes/views/head.php")?>
</head>

	<!-- end::Head -->

	<!-- begin::Body -->
	<body class="<?echo $g_body_class?>">

		<?require("./includes/views/header.php")?>
        
        	<div class="kt-grid kt-grid--hor kt-grid--root">
			<div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--ver kt-page">
				<div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-wrapper" id="kt_wrapper">

					<!-- begin:: Header -->
					
                    <?require("./includes/views/topmenu.php")?>
					<!-- end:: Header -->

					<!-- begin:: Aside -->
					<?require("./includes/views/leftmenu.php")?>

					<!-- end:: Aside -->
					<div class="kt-body kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-grid--stretch" id="kt_body">
						<div class="kt-content  kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor" id="kt_content">

							<!-- end:: Subheader -->

							<!-- begin:: Content -->
							<div class="kt-container  kt-grid__item kt-grid__item--fluid">
							    
							    <?if(isset($_GET['m'])){?>
							        <!--<div class="alert alert-info"><?echo $_GET['m']?></div>-->
							    <?}?>
							    
							    
							    <?if($_GET['m']=="added" ||  $_GET['m']=="stopped" || $_GET['m']=="deleted" || $_GET['m']=="lunch_started" || $_GET['m']=="lunch_ended" || $_GET['m']=="break_started" || $_GET['m']=="break_ended"){?> 
                                <div class="alert alert-dismissible bg-<?if($_GET['m']=="deleted"){echo "danger";}else{echo "success";}?> d-flex flex-column flex-sm-row w-100 p-5 mb-10">
                                 
                                    <!--begin::Wrapper-->
                                    <div class="d-flex flex-column text-light pe-0 pe-sm-10">
                                        
                                        <?if ($_GET['m']=="added"){?>
                                            <h4 class="mb-2 light" style="color: white;margin-top: 5px;">Your Work Shift Has Started Successfully</h4>
                                        <?}else if ($_GET['m']=="stopped"){?>
                                            <h4 class="mb-2 light" style="color: white;margin-top: 5px;">Your Work Shift Has Completed Successfully</h4>
                                        <?}else if ($_GET['m']=="deleted"){?>
                                            <h4 class="mb-2 light" style="color: white;margin-top: 5px;">Work Shift Has Been Deleted Successfully</h4>
                                        <?}else if ($_GET['m']=="lunch_started"){?>
                                            <h4 class="mb-2 light" style="color: white;margin-top: 5px;">Your Lunch Has Been Started Successfully</h4>
                                        <?}else if ($_GET['m']=="lunch_ended"){?>
                                            <h4 class="mb-2 light" style="color: white;margin-top: 5px;">Your Lunch Has Been Ended Successfully</h4>
                                        <?}else if ($_GET['m']=="break_started"){?>
                                            <h4 class="mb-2 light" style="color: white;margin-top: 5px;">Your Break Has Been Started Successfully</h4>
                                        <?}else if ($_GET['m']=="break_ended"){?>
                                            <h4 class="mb-2 light" style="color: white;margin-top: 5px;">Your Break Has Been Ended Successfully</h4>
                                        <?}?>
                                    </div>
                                    <!--end::Wrapper-->
                                
                                    <!--begin::Close-->
                                    <button type="button" class="position-absolute position-sm-relative m-2 m-sm-0 top-0 end-0 btn btn-icon ms-sm-auto" data-bs-dismiss="alert">
                                        <span class="svg-icon svg-icon-2x svg-icon-light">
											<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
												<rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor"></rect>
												<rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor"></rect>
											</svg>
										</span>
                                    </button>
                                    <!--end::Close-->
                                </div>
                                <?}?>
                                

								<div class="kt-portlet kt-portlet--mobile">
								    <div class="kt-portlet__head kt-portlet__head--lg">
										<div class="kt-portlet__head-label">
											<span class="kt-portlet__head-icon">
											</span>
											<h3 class="kt-portlet__head-title">
											    <?if(!isset($_GET['shift_id'])){?>
											        Shift Time Tracker
											    <?}else{?>
											        Viewing Details
											    <?}?>
												
											</h3>
										</div>
										<div class="kt-portlet__head-toolbar">
											<div class="kt-portlet__head-wrapper">
												<div class="kt-portlet__head-actions">
												    <?if(!isset($_GET['shift_id'])){?>
    												    <?if($session_data['work_shift_status']=="Inactive"){?>
                									        <a style="margin-right: 10px;" class="btn btn-primary text-white btn-sm" href="?start_shift=1">Start Work Shift</a>
                									    <?}else{?>
                									        <?if($session_data['lunch_status']=="Inactive" && $session_data['break_status']=="Inactive"){?>
                									        <a style="margin-right: 10px;" class="btn btn-danger btn-sm" href="?end_shift=1">End Work Shift</a>
                									        <?}?>
                									    <?}?>
                									    
                									    
                									    <?if($session_data['work_shift_status']=="Active"){?>
                									        <?if($session_data['lunch_status']=="Inactive"){?>
                									            <!--<a style="margin-right: 10px;" class="btn btn-warning btn-sm" href="?start_lunch=1">Start Lunch</a>-->
                									        <?}else{?>
                									            <!--<a style="margin-right: 10px;" class="btn btn-danger btn-sm" href="?end_lunch=1">End Lunch</a>-->
                									        <?}?>
                									        <?if($session_data['break_status']=="Inactive"){?>
                									            <a style="margin-right: 10px;" class="btn btn-warning btn-sm" href="?start_break=1">Start Break</a>
                									        <?}else{?>
                									            <a style="margin-right: 10px;" class="btn btn-danger btn-sm" href="?end_break=1">End Break</a>
                									        <?}?>
                									    <?}?>
            									    <?}?>
            									    <?if(isset($_GET['shift_id'])){?>
            									        <a class="btn btn-primary btn-sm text-white">Shift Date : <?echo date("d M Y",$shiftDeets['start_time']);?></a>
            									    <?}?>
															
												</div>
											</div>
										</div>
									</div>
    								
    								<div class="kt-portlet__body pt-0">
    								    <?if(!isset($_GET['shift_id'])){?>
    									    <table class="table align-middle table-row-dashed fs-6 gy-5 table-bordered" id="kt_ecommerce_category_table">
    									    <thead>
    									        <tr>
    										        <th>Employee</th>
    										        <th>Start Time</th>
    										        <th>End Time</th>
    										        <th>Time Lapsed</th>
    										        <th>Status</th>
    										        <th>Date</th>
    										        <th>Actions</th>
    									        </tr>
    									    </thead>
    									    <tbody>
    									        <?
    									        $query="select * from ".$g_projectSlug."_work_shifts where userId like '%$session_userId_filter%' order by timeAdded desc";
    									        $responses=getAll($con,$query);
    									        foreach($responses as $row){?>
    									        <tr>
    									            <td><?echo $g_allUsersInfo[$row['userId']]['name']?></td>
    									            <td><?echo date("h: i : a",$row['start_time'])?></td>
    									            <td><?if($row['status']=="Completed"){echo date("h: i : a",$row['end_time']);}?></td>
    									            <td>
    									                <?if($row['status']=="Completed"){
        									                $start_time=$row['start_time'];
        									                $end_time=$row['end_time'];
        									                $timeLapsed=$end_time-$start_time;
        									                $minutes=round($timeLapsed/60);
        									                $hours=round($timeLapsed/3600);
        									                if($minutes<60)
        									                    $timeLapsed=$minutes. " Mins";
        									                else  
        									                    $timeLapsed=$hours. " Hrs";
        									                echo $timeLapsed;
    									                }?>
    									            </td>
    									            <td>
    									                <?if($row['status']=="Completed"){?>
    									                    <a class="badge badge-success btn-sm text-white ">Shift Completed</a>
    									                <?}else{?>
    									                    <a class="badge badge-warning btn-sm">Active Shift</a>
    									                <?}?>
    									            </td>
    									            <td><?echo date("d M Y",$row['start_time']);?></td>
    									            <td>
    									                <a class="btn btn-primary btn-sm" href="?shift_id=<?echo $row['id']?>">View Shift Details</a>
    									                <?if($row['status']=="Active"){?>
    									                    <?if($session_data['lunch_status']=="Inactive" && $session_data['break_status']=="Inactive"){?>
    									                        <a class="btn btn-warning btn-sm" href="?end_shift=1">End Work Shift</a>
    									                    <?}?>
    									                <?}?>
    									                <!--<a class="btn btn-danger btn-sm" href="#" data-bs-toggle="modal" data-bs-target="#delete_record"  data-url="?delete-record=<?echo $row['id']?>">Delete</a>-->
        											</td>
    									        </tr>
    									        <?}?>
    									    </tbody>
    									</table>
    									<?}if(isset($_GET['shift_id'])){?>
    									<table class="table align-middle table-row-dashed fs-6 gy-5 table-bordered" id="kt_ecommerce_category_table">
    									    <thead>
    									        <tr>
    									            
    										        <th>Employee</th>
    										        <th>Start Time</th>
    										        <th>End Time</th>
    										        <th>Time Lapsed</th>
    										        <th>Type</th>
    										        <th>Status</th>
    									        </tr>
    									    </thead>
    									    <tbody>
    									        <?
    									        $query="select * from ".$g_projectSlug."_shift_details where shift_id='$shift_id' order by start_time desc";
    									        $details=getAll($con,$query);
    									        foreach($details as $row){?>
    									        <tr>
    									            <td><?echo $g_allUsersInfo[$row['userId']]['name']?></td>
    									            <td><?echo date("h: i : a",$row['start_time'])?></td>
    									            <td><?if($row['status']=="Completed"){echo date("h: i : a",$row['end_time']);}?></td>
    									            <td>
    									                <?if($row['status']=="Completed"){
    									                $start_time=$row['start_time'];
    									                $end_time=$row['end_time'];
    									                $timeLapsed=$end_time-$start_time;
    									                $minutes=round($timeLapsed/60);
    									                $hours=round($timeLapsed/3600);
    									                if($minutes<60)
    									                    $timeLapsed=$minutes. " Mins";
    									                else  
    									                    $timeLapsed=$hours. " Hrs";
    									                echo $timeLapsed;
    									                }?>
    									            </td>
    									            <td><?echo $row['type']?></td>
    									            <td>
    									                <?if($row['status']=="Completed"){?>
    									                    <a class="badge badge-success btn-sm text-white"><?echo $row['type']?> Completed</a>
    									                <?}else{?>
    									                    <a class="badge badge-warning btn-sm text-white">Active <?echo $row['type']?></a>
    									                <?}?>
    									            </td>
    									        </tr>
    									        <?}?>
    									    </tbody>
    									</table>
    									<?}?>
    								</div>
    							</div>
							
							
							</div>

							
							

							<!-- end:: Content -->
						</div>
					</div>

					<!-- begin:: Footer -->
					
					<?require("./includes/views/footer.php")?>

					<!-- end:: Footer -->
				</div>
			</div>
		</div>
        
        
        <?require("./includes/views/footerjs.php")?>
		

	</body>

	
</html>