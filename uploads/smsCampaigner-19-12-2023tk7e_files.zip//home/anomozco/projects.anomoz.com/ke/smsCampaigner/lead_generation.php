<?require("./global.php");

?>
<!DOCTYPE html>


<html lang="en">

	<!-- begin::Head -->
	<head><?require("./includes/views/head.php")?>

	</head>

	<!-- end::Head -->

	<!-- begin::Body -->
	<body class="<?echo $g_body_class?>" onload="">

		<?require("./includes/views/header.php")?>
        
        	<div class="kt-grid kt-grid--hor kt-grid--root">
			<div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--ver kt-page">
				<div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-wrapper" id="kt_wrapper">

					<!-- begin:: Header -->
					
                    <?require("./includes/views/topmenu.php")?>
					<!-- end:: Header -->

					<!-- begin:: Aside -->
					<?require("./includes/views/leftmenu.php")?>

					<!-- end:: Aside -->
					<div class="kt-body kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-grid--stretch" id="kt_body">
						<div class="kt-content  kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor" id="kt_content">

							<!-- end:: Subheader -->
                            
							<!-- begin:: Content -->
							<div class="kt-container  kt-grid__item kt-grid__item--fluid">
							    
							    <?if(isset($_GET['m'])){?>
							        <div class="alert alert-info"><?echo $_GET['m']?></div>
							    <?}?>
						        
						        <div class="kt-portlet kt-portlet--mobile">
									<div class="kt-portlet__head kt-portlet__head--lg">
										<div class="kt-portlet__head-label">
											<span class="kt-portlet__head-icon">
											</span>
											<h3 class="kt-portlet__head-title">
												Landing Page
											</h3>
										</div>
									</div>
									<div class="kt-portlet__body">
                                        <h4>Landing Page: <a href="https://projects.anomoz.com/wp-site/pageWebsite/" target="_blank">https://projects.anomoz.com/wp-site/pageWebsite/</a></h4>
									    
									    <div class="alert alert-primary mt-2 h4">Credentials:</div>
									    <br>
    									    
    									    <p class="h6">https://projects.anomoz.com/wp-site/pageWebsite/wp-admin<br>
                                            username: admin<br>
                                            password: pass
                                            
                                            </p>
                                            
									
									</div>
								</div>
								
						        <div class="kt-portlet kt-portlet--mobile">
									<div class="kt-portlet__head kt-portlet__head--lg">
										<div class="kt-portlet__head-label">
											<span class="kt-portlet__head-icon">
											</span>
											<h3 class="kt-portlet__head-title">
												Form Widget to embed
											</h3>
										</div>
									</div>
									<div class="kt-portlet__body">
                                        <h4 class="h5">Embed this widget in your landing page to catch leads in your crm</h4>
									    
									    <div class="alert alert-primary mt-2 h4">
    										<code>
                                            <?php
                                            echo htmlentities('<iframe style="width:100%;height:100%;min-height:800px;border:none;" src="'.$g_website.'/embed_lead_form.php"></iframe>');
                                            ?>
                                            </code>
                                            </div>
									  
									
									</div>
								</div>
								
						        
						        
						        
								
							</div>

							

							<!-- end:: Content -->
						</div>
					</div>

					<!-- begin:: Footer -->
					
					<?require("./includes/views/footer.php")?>

					<!-- end:: Footer -->
				</div>
			</div>
		</div>
        
        
        <?require("./includes/views/footerjs.php")?>
		

	</body>

	<!-- end::Body -->

</html>