<? require("./global.php");

require("./includes/models/messages.php");

?>
<!DOCTYPE html>


<html lang="en">

<!-- begin::Head -->

<head><? require("./includes/views/head.php") ?>
<style>
    @media (max-width: 1024px){
        .kt-app__aside {
            position: unset !important;
            /* float: left; */
            width: 100% !important;
        }
    }
</style>
<script>
    function getUser(receiverId) {
        // Get the PHP value and append it to the URL
        var newURL = window.location.origin + window.location.pathname + '?u=' + receiverId;
        console.log(newURL, receiverId);
        // Update the URL using HTML5 History API
        window.history.pushState({path: newURL}, '', newURL);
    }
</script>
</head>

<!-- end::Head -->

<!-- begin::Body -->

<body class="<? echo $g_body_class ?>">

    <? require("./includes/views/header.php") ?>

    <div class="kt-grid kt-grid--hor kt-grid--root">
        <div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--ver kt-page">
            <div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-wrapper" id="kt_wrapper">

                <!-- begin:: Header -->

                <? require("./includes/views/topmenu.php") ?>
                <!-- end:: Header -->

                <!-- begin:: Aside -->
                <? require("./includes/views/leftmenu.php") ?>

                <!-- end:: Aside -->
                <div class="kt-body kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-grid--stretch" id="kt_body">
                    <div class="kt-content  kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor" id="kt_content">

                        <!-- end:: Subheader -->

                        <!-- begin:: Content -->
                        <div class="kt-container  kt-grid__item kt-grid__item--fluid">

                            <!--Begin::App-->
                            <div class="kt-grid kt-grid--desktop kt-grid--ver kt-grid--ver-desktop kt-app">

                                <!--Begin:: App Aside Mobile Toggle-->
                                <button class="kt-app__aside-close" id="kt_chat_aside_close">
                                    <i class="la la-close"></i>
                                </button>

                                <!--Begin:: App Aside-->
                                <div class="kt-grid__item kt-app__toggle kt-app__aside kt-app__aside--lg kt-app__aside--fit" id="kt_chat_aside">

                                    <!--begin::Portlet-->
                                    <div class="kt-portlet kt-portlet--last h-100">
                                        <div class="kt-portlet__body">

                                            <div class="kt-widget kt-widget--users kt-mt-20">
                                                <div class="kt-scroll kt-scroll--pull ps ps--active-y" style="height: 477px; overflow-y: auto !important;">
                                                      <input type="text" id="searchFilter" onkeyup="myFunctionSearchFilter()" class="form-control" placeholder="Search user" title="Type in a name">

                                                        <div class="kt-widget__items">
                                                           <?php
                                                              /*
                                                                      $recievers = array();
                                                                      $array_userId_shown = array();
                                                                      $recievers_sql = "select  m.timeAdded, u.name, u.id as senderId, m.id, m.message, m.toUser,m.fromUser
                                                                      from ".$g_projectSlug."_messages m inner join ".$g_projectSlug."_users u on m.toUser=u.id where fromUser 
                                                                      in ('$session_userId') group by toUser order by m.timeAdded asc";
                                                                      $recievers = getAll($con,$recievers_sql);
                                                              
                                                                      $recievers_sql = "select  m.timeAdded, u.name, u.id as senderId, m.id, m.message, m.toUser,m.fromUser from 
                                                                      ".$g_projectSlug."_messages m inner join ".$g_projectSlug."_users u on m.fromUser=u.id where 
                                                                      toUser in('$session_userId') group by fromUser order by m.timeAdded desc ";
                                                                      $recievers_temp = getAll($con,$recievers_sql);
                                                                      
                                                                      if(isset($_GET['u'])){
                                                                          $recievers_temp = array_merge($recievers_temp, array($recievers_temp_1));
                                                                          
                                                                      }
                                                                      
                                                                      $recievers = array_merge($recievers, $recievers_temp);
                                                                      */
                                                                $query = "select * from " . $g_projectSlug . "_users where id!='$session_userId' and ( role='employee' or role='customer' or role='admin') ";
                                                                if($session_role!='admin'){
                                                                    $query = "select * from " . $g_projectSlug . "_users where id!='$session_userId' and ( role='admin') ";
                                                                }
                                                              $recievers = getAll($con, $query);
                                                              foreach ($recievers as $k => $reciever) {
                                                              
                                                                  if (true) {
                                                                      $count_new_messages = getRow($con, "select *, count(*) from " . $g_projectSlug . "_messages where fromUser='" . $reciever['id'] . "' and toUser='$session_userId' and status='new' limit 1");
                                                                      array_push($array_userId_shown, $reciever['id']);
                                                                          ?>
                                                                       <div class="kt-widget__item targetFilter  <?php echo (isset($recieverId) && ($reciever['id'] == $recieverId)) ? "bg-light-info" : ""; ?> ">
                                                                          <span class="kt-media kt-media--circle">
                                                                             <img src="./uploads/<?echo $reciever['profile_pic']?>" alt="image" onerror="this.src='https://simg.nicepng.com/png/small/128-1280406_view-user-icon-png-user-circle-icon-png.png';">
                                                                             </span>
                                                                          <div class="kt-widget__info">
                                                                             <div class="kt-widget__section">
                                                                                <a href="?u=<? echo $reciever['id'] ?>" class="kt-widget__username" ><? echo $reciever['first_name'] ?> <? echo $reciever['name'] ?></a>
                                                                                
                                                                             </div>
                                                                             <span class="kt-widget__desc">
                                                                             <? echo $reciever['email'] ?>
                                                                             <? if ($reciever['id'] != $count_new_messages['toUser'] && $count_new_messages['count(*)'] > 0) { ?>
                                                                                 <span class="kt-badge kt-badge--success kt-badge--dot"></span>
                                                                                 <span class="badge badge-primary"><? echo ($count_new_messages['count(*)'] > 0) ? $count_new_messages['count(*)'] : '' ?></span>
                                                                             <? } ?>
                                                                             </span>
                                                                          </div>
                                                                          <div class="kt-widget__action">
                                                                          </div>
                                                                       </div>
                                                                       <? }
                                                                } ?>
                                                        </div>
    
                                                        
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!--end::Portlet-->
                                </div>

                                
                                <div class="kt-grid__item kt-grid__item--fluid kt-app__content" id="kt_chat_content">
                                    <div class="kt-chat h-100">
                                        <div class="kt-portlet kt-portlet--head-lg kt-portlet--last">
                                            <div class="kt-portlet__head">
                                                <div class="kt-chat__head ">
                                                    <div class="kt-chat__left">
                                                    </div>
                                                    <div class="kt-chat__center">
                                                        <div class="kt-chat__label">
                                                            <?if(!isset($_GET['u'])){?>
                                                                <h5 class="text-center h4">Click a user to start sending messages</h5>
                                                            <?}?>
                                                            <a href="#" class="kt-chat__title"><? echo $recievers_temp_1['name'] ?></a>
                                                            <span class="kt-chat__status">
                                                            </span>
                                                        </div>
                                                    </div>
                                                    <div class="kt-chat__right">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="kt-portlet__body">
                                                <div class="kt-scroll kt-scroll--pull ps ps--active-y" data-mobile-height="300" style="<?if(isset($_GET['u'])){?>height: 303px;overflow-y: auto !important;<?}?>">
                                                    
                                                    <?if(!isset($_GET['u'])){?>
                                                        <img class="w-100 h-100" style="object-fit: contain;" src="https://assets.uigarage.net/content/uploads/2019/07/humaaans-6.jpg">
                                                    <?}?>
                                                    <div class="kt-chat__messages" id="my_messages">
                                                        
                                                    </div>
                                                    <div class="ps__rail-x" style="left: 0px; bottom: 0px;">
                                                        <div class="ps__thumb-x" tabindex="0" style="left: 0px; width: 0px;"></div>
                                                    </div>
                                                    <div class="ps__rail-y" style="top: 0px; height: 303px; right: -2px;">
                                                        <div class="ps__thumb-y" tabindex="0" style="top: 0px; height: 93px;"></div>
                                                    </div>
                                                </div>
                                            </div>
                                            <?if(isset($_GET['u'])){?>
                                            <div class="kt-portlet__foot">
                                                <div class="kt-chat__input">
                                                    <div class="kt-chat__editor">
                                                        <form action="#" method="post" enctype="multipart/form-data" id="msgSendForm">

                                                            <input type="text" name="receiverId" value="<?php echo $message_to_userId ?>" hidden />
                                                            <input type="text" name="receiverEmail" value="<?php echo $receiverEmail ?>" hidden />

                                                            <input type="hidden" name="to_user" value="<?php echo $recieverId; ?>">
                                                            <input type="hidden" name="from_user" value="<?php echo $session_userId; ?>">
                                                            <input type="hidden" name="NEW_MESSAGE" value="true">

                                                            <p class="mb-0 el-hide d-none" id="fileStatus">1 File selected.</p>
                                                            <div class="input-group">
                                                                <? if (checkGlobalPermission('enableMessages_fileSending')) { ?>
                                                                    <div class="input-group-prepend">

                                                                        <label for="fileInp" class="btn btn-outline-secondary mb-0" type="button" id="uploadFile" title="Upload File">
                                                                            <i class="fa fa-paperclip"></i>
                                                                            <input type="file" name="fileToUpload" id="fileInp" class="el-hide">
                                                                        </label>
                                                                    </div>
                                                                <? } ?>

                                                                <input type="text" class="form-control" name="new_message" placeholder="Type here..." id="msg" required>
                                                                <div class="input-group-append">
                                                                    <button class="btn btn-primary" type="submit" id="button-addon2">Send</button>
                                                                </div>
                                                            </div>
                                                        </form>

                                                        <div class="modal fade" id="request_modal">
                                                            <div class="modal-dialog modal-dialog-centered">
                                                                <div class="modal-content">
                                                                    <!-- Modal Header -->
                                                                    <div class="modal-header">
                                                                        <h4 class="modal-title">Create A Request</h4>
                                                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                                    </div>
                                                                    <!-- Modal body -->
                                                                    <div class="modal-body">
                                                                        <form action="#" id="RequestForm" autocomplete="off">
                                                                            <div class="form-group">
                                                                                <input type="text" name="receiverId" value="<? echo $message_to_userId ?>" hidden />
                                                                                <input type="text" class="form-control" placeholder="Enter title here" name="title" id="title" required>
                                                                                <input type="hidden" name="to_user" value="<?php echo $recieverId; ?>">
                                                                                <input type="hidden" name="from_user" value="<?php echo $session_userId; ?>">
                                                                                <input type="hidden" name="NEW_REQUEST" value="true">
                                                                            </div>
                                                                            <div class="form-group">
                                                                                <input type="number" class="form-control" placeholder="Enter amount here" name="finalPrice" id="amount" required>
                                                                            </div>
                                                                            <div class="form-group">
                                                                                <textarea class="form-control" name="description" placeholder="Enter Desctiption of your request here..."></textarea>
                                                                            </div>
                                                                            <!--<button type="submit" class="btn btn-primary">Send Request</button>-->
                                                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                                        </form>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>

                                                    </div>

                                                </div>
                                            </div>
                                            <?}?>
                                        </div>
                                    </div>
                                </div>

                                <!--End:: App Content-->
                            </div>

                            <!--End::App-->
                        </div>


                        <!-- end:: Content -->
                    </div>
                </div>

                <!-- begin:: Footer -->

                <? require("./includes/views/footer.php") ?>

                <!-- end:: Footer -->
            </div>
        </div>
    </div>


    <? require("./includes/views/footerjs.php") ?>


</body>

<!-- end::Body -->

<script>
    $(document).ready(function() {
        $("#msg").focus();
    })
</script>

<script>
    function getLiveUpdates() {
        setInterval(function() {
            getMessageFromServer();
        }, 5000);
        getMessageFromServer();
    }

    var pData_message;

    function getMessageFromServer() {
        var InitiateGetTransactions = function(textIdInp, callback) // How can I use this callback?
        {
            var request = new XMLHttpRequest();
            request.onreadystatechange = function() {
                if (request.readyState == 4 && request.status == 200) {
                    callback(request.responseText); // Another callback here
                }
                if (request.readyState == 4 && request.status == 0) {
                    //console.log("no response for ") // Another callback here
                }
            };
            var apii = "<?php echo './includes/fetch_private_chat_messages.php?from=' . $message_to_userId . '&to=' . $session_userId; ?>";
            //console.log("apii", apii)
            request.open("POST", apii);
            request.send();
        }

        var _this = this;
        var frameTransactions = function mycallback(data) {
            var dataParsed
            //console.log("data2", data)

            dataParsed = JSON.parse(data);
            if (dataParsed.message == "none") {
                //console.log("no transactions")
            } else {
                var sampleTrans = dataParsed
                ////console.log(sampleTrans)
                if (JSON.stringify(pData_message) != JSON.stringify(sampleTrans)) {
                    //add to local storage
                    pData_message = sampleTrans
                    <? if (isset($_GET['u'])) { ?>
                        setupMessageTable(sampleTrans)
                    <? } ?>
                    //console.log(" storage updated", sampleTrans)
                }

            }

        }
        InitiateGetTransactions(1, frameTransactions); //passing mycallback as a method 
    }

    function setupMessageTable(pData_message) {

        pData_message = pData_message.messages;
        //var a=$("#new_comment").val();
        $("#my_messages").empty()
        if (true) {
            for (var i = 0; i < pData_message.length; i++) {
                var messageId = pData_message[i].id;
                var timeAdded = pData_message[i].timeAdded;
                var message = pData_message[i].message;
                var senderId = pData_message[i].senderId;
                var messageId = pData_message[i].messageId;
                var name = pData_message[i].name;
                var rating = pData_message[i].rating;

                var isEscrow = pData_message[i].isEscrow;
                var orderId = pData_message[i].orderId;
                var title = pData_message[i].title;
                var description = pData_message[i].description;
                var finalPrice = pData_message[i].finalPrice;
                var paymentMethod = pData_message[i].paymentMethod;
                var offerStatus = pData_message[i].offerStatus;

                var actionPanel = "";
                var senderEmail = "<? echo $session_email ?>"
                var pic = ""


                if (senderId == "<? echo $session_userId ?>") {
                    pic = "<? echo $session_pic ?>"
                    messageclass = "";
                } else {
                    pic = "<? echo $message_to_pic ?>";
                    messageclass = " kt-chat__message--right";
                }

                if (message.includes("aud_")) {
                    message = `<a target="_blank" href="./uploads/` + message + `">View file</a><br>`
                }

                txt1 = `	<div class="kt-chat__message  ` + messageclass + `">
        					<div class="kt-chat__user">
        						<a href="#" class="kt-chat__username">` + name + `</a>
        						<span class="kt-chat__datetime">` + timeAdded + `</span>
        					</div>
        					<div class="kt-chat__text kt-bg-light-success">
        						` + message + `
        					</div>
        				</div>
        				`;

                $("#my_messages").append(txt1); // Append new elements


            }
        }

        var height = 0;
        $('.chatUL li').each(function(i, value) {
            height += parseInt($(this).height());
        });
        height += '';
        $('#chatBox').animate({
            scrollTop: height
        });

        //$("#my_messages").append("<div id='lastMessage1'><div>");     // Append new elements
        //window.location="#lastMessage"
        $("#comment").focus();
    }

    $('#my_messages').scrollTop($('#my_messages')[0].scrollHeight);

    getMessageFromServer();

    $("#comment").focus();

    function sendMessage() {
        $.ajax({
            url: "./messages.php",
            type: 'POST',
            data: new FormData($("#msgSendForm")[0]),
            dataType: 'json',
            processData: false,
            contentType: false,
            beforeSend: function() {
                $("#msgSendForm").find('[type=submit]').addClass('disabled');
            },
            success: function(data) {
                $("input#msg").val('');
                $("input#fileInp").val('');
                // $(".chatUL").append(buildMsg(data,$("#msgSendForm").find('[name=from_user]').val()));
            },
            error: function(error) {
                console.log(error);
            },
            complete: function(data) {
                $("#msgSendForm").find('[type=submit]').removeClass('disabled');
                $("#fileStatus").addClass("el-hide");
                // scrollDown functionality
                var height = 0;
                $('.chatUL li').each(function(i, value) {
                    height += parseInt($(this).height());
                });
                height += '';
                $('#chatBox').animate({
                    scrollTop: height
                });
                // end scrollDown functionality 
            }
        });
    }


    $(document).ready(function() {


        var sender_id = $("#sender_id").attr('data-id');
        var reciever_id = $("#reciever_id").attr('data-id');

        //getMessage of receiver
        // if(reciever_id != undefined){ getMessages(sender_id,reciever_id);}

        // send message or create request with message
        $("#msgSendForm").on('submit', function(e) {
            e.preventDefault();
            sendMessage();
            getMessageFromServer();
            $("input#msg").val('');
        });
       
        //autoload message

        $(document).on('click', ".checkout-button", function(e) {
            console.log(stripe, e);
            stripe.redirectToCheckout({
                sessionId: '<? echo  $session['id'] ?>'
            }).then(function(result) {});
        });
    });


    getLiveUpdates()
    
    function myFunctionSearchFilter() {
        var input = document.getElementById("searchFilter");
        var filter = input.value.toLowerCase();
        var nodes = document.getElementsByClassName('targetFilter');

        for (i = 0; i < nodes.length; i++) {
            if (nodes[i].innerText.toLowerCase().includes(filter)) {
                nodes[i].style.display = "flex";
            } else {
                nodes[i].style.display = "none";
            }
        }
    }
    
</script>


</html>