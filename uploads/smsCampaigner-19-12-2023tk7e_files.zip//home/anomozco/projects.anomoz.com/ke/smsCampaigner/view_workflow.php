<?  require("./global.php");

$wId = $_GET['id'];

//for insert & update
if(isset($_POST['create_package'])){
	
	if (!$con->prepare("DELETE FROM ".$g_projectSlug."_workflow_details WHERE wId='$wId'")->execute()) { echo "err"; }
	
	foreach($_POST['task'] as $i => $v){
		$timeAdded = time();
		$id = generateRandomString();
		$task = htmlspecialchars($v, ENT_QUOTES, 'UTF-8');
		$wait = mb_htmlentities(($_POST['wait'][$i]));
		$title =  mb_htmlentities(($_POST['title'][$i]));
		$message =  mb_htmlentities(($_POST['message'][$i]));
		$query = "insert into ".$g_projectSlug."_workflow_details set id='$id',wId='$wId',task='$task',wait='$wait',title='$title',message='$message',
		flow='$i',timeAdded='$timeAdded', userId='$session_userId' ";	
		$stmt = $con->prepare($query);
		if(!$stmt){echo "err: <code>$query</code>";}
		if(!$stmt->execute()){echo "err: <code>$query</code>";}		
	}
	 
    header("Location: ?m=Data was saved successfully!&id=".$wId);
      
}
 

$workflowInfo = getAll($con,"SELECT * from ".$g_projectSlug."_workflow_details  where wId='$wId' order by flow ASC");

 
?>
<!DOCTYPE html>


<html lang="en">

	<!-- begin::Head -->
	<head>
		<?require("./includes/views/head.php")?>
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

	<!-- end::Head -->

	<!-- begin::Body -->
	<body class="<?echo $g_body_class?>">

		<?require("./includes/views/header.php")?>
        
        	<div class="kt-grid kt-grid--hor kt-grid--root">
			<div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--ver kt-page">
				<div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-wrapper" id="kt_wrapper">

					<!-- begin:: Header -->
					
                    <?require("./includes/views/topmenu.php")?>
					<!-- end:: Header -->

					<!-- begin:: Aside -->
					<?require("./includes/views/leftmenu.php")?>

					<!-- end:: Aside -->
					<div class="kt-body kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-grid--stretch" id="kt_body">
						<div class="kt-content  kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor" id="kt_content">

							<!-- end:: Subheader -->

							<!-- begin:: Content -->
							<div class="kt-container  kt-grid__item kt-grid__item--fluid">
                            <?if(isset($_GET['m'])){?>
							        <div class="alert alert-info"><?echo $_GET['m']?></div>
							    <?}?>
                                <div class="row">
                                <div class="col-md-5">


                                <div class="kt-portlet kt-portlet--mobile">
									<div class="kt-portlet__head kt-portlet__head--lg">
										<div class="kt-portlet__head-label">
											<span class="kt-portlet__head-icon">
											</span>
											<h3 class="kt-portlet__head-title">
												<?echo ucfirst("Contacts");?>
											</h3>
										</div>
										<div class="kt-portlet__head-toolbar">
											<div class="kt-portlet__head-wrapper">
												<div class="kt-portlet__head-actions">
												    
												    
												    
													<!-- <a href="#" class="btn btn-brand btn-elevate btn-icon-sm" data-toggle="modal" data-target="#create_record_modal">
														<i class="la la-plus"></i>
														New Record
													</a> -->
															
												</div>
											</div>
										</div>
									</div>
									<div class="kt-portlet__body">
                                        <form action="" method="post">
                                         
                                                <table class="table table-striped- table-bordered table-hover table-checkable add-search" >
                                                    <thead>
                                                        <tr>
                                                            <th>Name</th>
                                                            <th>Email</th>
                                                            <th>Phone</th>
                                                           
                                                            <th>View</th>
                                                          
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                    <?php 
                                                    $workflow=$_GET['id'];
                                                    
                                                     $query = "select * from ".$g_projectSlug."_users t where workflow='$workflow'  order by t.timeAdded desc";
                                                    $results = getAll($con, $query);
                                                   
                                                        foreach($results as $row){?>
                                                            <tr>
                                                                <td><?php echo $row['name']?></td>
                                                                <td><?php echo $row['email']?></td>
                                                                <td><?php echo $row['phone']?></td>
                                                              
                                                                <td><?if(checkGlobalPermission('enableCustomerProfile')){?>
        													        <a href="./view_user.php?id=<?echo $row['id']?>" class="btn btn-primary" >View</a>
        													    <?}?></td>
                                                                
                                                               
                                                                
                                                            </tr>
                                                        <?php }?>
                                                    </tbody>
                                                </table>

    										
                                        </form>
										<!--end: Datatable -->
									</div>
								</div>

                                <div class="kt-portlet kt-portlet--mobile">
									<div class="kt-portlet__head kt-portlet__head--lg">
										<div class="kt-portlet__head-label">
											<span class="kt-portlet__head-icon">
											</span>
											<h3 class="kt-portlet__head-title">
												<?echo ucfirst("Workflow History");?>
											</h3>
										</div>
										<div class="kt-portlet__head-toolbar">
											<div class="kt-portlet__head-wrapper">
												<div class="kt-portlet__head-actions">
												    
												    
												    
													<!-- <a href="#" class="btn btn-brand btn-elevate btn-icon-sm" data-toggle="modal" data-target="#create_record_modal">
														<i class="la la-plus"></i>
														New Record
													</a> -->
															
												</div>
											</div>
										</div>
									</div>
									<div class="kt-portlet__body">
                                        <form action="" method="post">
                                         
                                                <table class="table table-striped- table-bordered table-hover table-checkable add-search" >
                                                    <thead>
                                                        <tr>
                                                            <th>Contact</th>
                                                            <th>Task</th>
                                                            <th>Wait</th>
                                                            <th>Flow</th>  
                                                            <th>Title</th>
                                                            <th>Message</th>
                                                          
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                    <?php 
                                                    $workflow=$_GET['id'];
                                                    
                                                     $query = "select * from ".$g_projectSlug."_workflow_history t where wId='$workflow'  order by t.timeAdded desc";
                                                    $results = getAll($con, $query);
                                                   
                                                        foreach($results as $row){?>
                                                            <tr>
                                                                <td><?php echo $row['cid']?></td>
                                                                <td><?php echo $row['task']?></td>
                                                                <td><?php echo $row['wait']?></td>
                                                                <td><?php echo $row['flow']?></td>
                                                                <td><?php echo $row['title']?></td>
                                                              <td><?php echo $row['message']?></td>
                                                                
                                                                
                                                               
                                                                
                                                            </tr>
                                                        <?php }?>
                                                    </tbody>
                                                </table>

    										
                                        </form>
										<!--end: Datatable -->
									</div>
								</div>



                                      </div>
                                    <div class="col-md-7">

									<div class="kt-portlet kt-portlet--mobile">
									<div class="kt-portlet__head kt-portlet__head--lg">
										<div class="kt-portlet__head-label">
											<span class="kt-portlet__head-icon">
											</span>
											<h3 class="kt-portlet__head-title">
												<?echo ucfirst("Workflow Title");?>
											</h3>
										</div>
										<div class="kt-portlet__head-toolbar">
											<div class="kt-portlet__head-wrapper">
												<div class="kt-portlet__head-actions">
												    
												    
												    
													<!-- <a href="#" class="btn btn-brand btn-elevate btn-icon-sm" data-toggle="modal" data-target="#create_record_modal">
														<i class="la la-plus"></i>
														New Record
													</a> -->
															
												</div>
											</div>
										</div>
									</div>
									
								</div>


                                   
                                            <form action="" method="POST">
									<div class="card border border-primary bg-white w-100 mx-auto">
										 <div class="card-body">
											<div class="container">
												<div class="text-center">
													<button id="workflow-trigger" type="button" class="btn btn-outline-primary border border-primary workflow-button">Workflow Trigger</button>
												</div>
											</div>

											<!-- Task and Duration Section -->
											<div id="task-duration-section" class="text-center">
												<!-- Initially, this section is empty. Buttons and lines will be added dynamically. -->
											</div>
										</div>
									</div>
									<!-- Save data in Database Btn -->
									<div class="row w-50 mx-auto my-2"  id="create_package" style="display:none;">
										<button type="text" name="create_package" class="btn btn-primary btn-block">Save</button>
									</div>
								</form>
                                    </div>
                                    
                                </div>

							    
							  
								

 

							</div>


							<!-- end:: Content -->
						</div>
					</div>

					<!-- begin:: Footer -->
					
					<?require("./includes/views/footer.php")?>

					<!-- end:: Footer -->
				</div>
			</div>
		</div>

        <?require("./includes/views/footerjs.php")?>

	</body>

	<!-- end::Body -->
	
   <!-- Modal for Task and Wait -->
    <div class="modal fade" id="taskDurationModal" tabindex="-1" role="dialog" aria-labelledby="taskDurationModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="taskDurationModalLabel">Task and Wait</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
					<div class="form-group">
						<select id="taskTypeSelect" class="form-control fa">
							<option class="fa">&#xf2b7; Email</option>
							<option class="fa">	&#xf27a; SMS</option>
						
						</select>
					</div>
                    <div class="form-group">
						<input type="number" id="durationInput" min="1" class="form-control" placeholder="Wait (in days)">
					</div>
                    <div class="form-group">
						<input type="text" id="titleInput"   class="form-control" placeholder="Title">
					</div>
                    <div class="form-group">
						<textarea  id="messageInput"   class="form-control" placeholder="Message"></textarea>
					</div>
                </div>
                <div class="modal-footer">
                    <button id="addTaskDuration" class="btn btn-success" data-dismiss="modal">Add</button>
                </div>
            </div>
        </div>
    </div>	 
  <style>
        .workflow-button {
            margin: 10px;
        }
		.fa {
			font-family: Arial, FontAwesome !important;
		}

        .workflow-line-vertical {
            width: 2px;
            height: 50px;
            background-color: #007bff;
            margin: 0 auto;
        }
    </style>

    <script>
        $(document).ready(function () {
            $("#workflow-trigger").click(function () {
                // Add a vertical line and "+" button
                var line = '<div class="workflow-line-vertical"></div>';
                var plusButton = '<button type="button" class="btn btn-sm btn-primary workflow-button  add-button">+</button>';
                $("#task-duration-section").append(line, plusButton);
				$("#workflow-trigger").prop("disabled", true);
            });

            $("body").on("click", ".add-button", function () {

                $("#taskDurationModal").modal("show");

                var addButton = $(this);

                
                $("#addTaskDuration").off("click").on("click", function () {
					
                    var taskType = $("#taskTypeSelect").val();
                    var duration = $("#durationInput").val();
                    var title = $("#titleInput").val();
                    var message = $("#messageInput").val();
					
					if(!duration){duration= 1;}
                    var taskSection = '<div class="text-center"><div class="workflow-line-vertical"></div><input type="hidden" value="' + title + '" name="title[]"><input type="hidden" value="' + duration + '" name="wait[]"><input type="hidden" value="' + message + '" name="message[]"><input type="hidden" value="' + taskType + '" name="task[]"><div class="fa btn btn-outline-primary workflow-button"> Task: ' + taskType + '</div></div>';
                    var durationSection = '<div class="text-center"><div class="workflow-line-vertical"></div><input type="hidden" value="' + duration + ' " name="wait[]"> <div class="btn btn-outline-warning workflows-button">Wait: ' + duration + ' days</div></div>';
                    var morePlusButton = '<div class="text-center"><div class="workflow-line-vertical"></div><button type="button" class="btn btn-success workflow-button add-button">+</button></div>';

                    addButton.after(taskSection, durationSection, morePlusButton);
					
                    $("#taskTypeSelect")[0].selectedIndex = 0;
                    $("#durationInput").val("");
                    $("#taskDurationModal").modal("hide");
				    showSaveBtn();
                });
            });
			
		<? if($workflowInfo){ ?>	
			$("#workflow-trigger").click();
			<?foreach($workflowInfo as $flow){?>
				var addButton = $(".add-button:last");
				var taskType = '<?echo $flow["task"]?>';
                var duration = '<?echo $flow["wait"]?>';
                var title = '<?echo $flow["title"]?>';
                var message = '<?echo $flow["message"]?>';
				if(!duration){duration= 0;}
                var taskSection = '<div class="text-center"><div class="workflow-line-vertical"></div><input type="hidden" value="' + title + '" name="title[]"><input type="hidden" value="' + duration + '" name="wait[]"><input type="hidden" value="' + message + '" name="message[]"><input type="hidden" value="' + taskType + '" name="task[]"><div class="fa btn btn-outline-primary workflow-button"> Task: ' + taskType + '</div></div>';
                var durationSection = '<div class="text-center"><div class="workflow-line-vertical"></div><input type="hidden" value="' + duration + ' " name="wait[]"> <div class="btn btn-outline-warning workflows-button">Wait: ' + duration + ' days</div></div>';
                var morePlusButton = '<div class="text-center"><div class="workflow-line-vertical"></div><button type="button" class="btn btn-success workflow-button add-button">+</button></div>';
                addButton.after(taskSection, durationSection, morePlusButton);
				showSaveBtn();
			
			<?}?>
			
		<?}?>
		function showSaveBtn(){
			var addButtonCount = $(".add-button").length;
			console.log('savebtn',addButtonCount);
			if(addButtonCount > 1){
				$("#create_package").show();
			} else{
				$("#create_package").hide();
			}
		}
		
		$("#taskTypeSelect").change(function() {
			// Get the selected value
			var selectedValue = $(this).val();

			if (selectedValue.includes("Email")) {
				$("#titleInput").show();
				$("#messageInput").show();
				
			} else if (selectedValue.includes("SMS")) {
				$("#titleInput").hide();
				$("#messageInput").show();
				
			} else {
				$("#titleInput").hide();
				$("#messageInput").hide();
			}
			console.log("Selected option: " + selectedValue);
			
		}); 
		
        });

		$("body").on("click", ".workflow-button", function () {
    // Check if the clicked button has the class "workflow-button"
    if ($(this).hasClass("workflow-button")) {
        // Retrieve values associated with the specific task section
        var taskType = $(this).siblings("input[name='task[]']").val();
        var duration = $(this).siblings("input[name='wait[]']").val();
        var title = $(this).siblings("input[name='title[]']").val();
        var message = $(this).siblings("input[name='message[]']").val();

        // Populate modal inputs with the retrieved values
        $("#taskTypeSelect").val(taskType);
        $("#durationInput").val(duration);
        $("#titleInput").val(title);
        $("#messageInput").val(message);

        // Show the modal
        $("#taskDurationModal").modal("show");
    }
});

// Remove the existing click event handler for #addTaskDuration
// and handle it separately outside the click event above.
$("#addTaskDuration").off("click").on("click", function () {
    // ... (existing code for adding task and duration sections)
    showSaveBtn();
});

		
    </script>
							
				 			
		
								
</html>

 