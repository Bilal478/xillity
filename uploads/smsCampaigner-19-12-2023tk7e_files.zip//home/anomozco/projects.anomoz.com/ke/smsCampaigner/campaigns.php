<? require("./global.php");

// ,"call"
$checkBoxInput=array("sms","email");

if(isset($_POST['title'])){

    $method=array();
    $extraQuery=" ";
    foreach($checkBoxInput as $i=>$value)
    {
        $value=$value."Send";
        if(isset($_POST[$value]))
            $method[$i]="Yes";
        else
            $method[$i]="No";
        
        $extraQuery=$extraQuery.", ".$value."='".$method[$i]."'"; //need to be inserted at the end   
    }
    $id = generateRandomString();
    $title = mb_htmlentities(($_POST['title']));
    $desc = mb_htmlentities(($_POST['description']));
    $is_weekly = mb_htmlentities(($_POST['is_weekly']));
    $campDate = mb_htmlentities(($_POST['camp_date']));
    $campTime = mb_htmlentities(($_POST['camp_time']));
    $day = mb_htmlentities(($_POST['camp_day']));
    $status = "PENDING";
    $userId = $session_userId;
    $time = time();
    $actionId = mb_htmlentities(($_POST['actionId']));
    
    if($actionId==""){
        $actionId = $id;
        $stmt = $con->prepare("insert into ".$g_projectSlug."_campaigns set title='$title', description='$desc',
        is_weekly='$is_weekly', camp_date='$campDate', camp_time='$campTime', camp_day='$day',
        status='$status', user_id='$userId', created_at='$time', camp_id='$id' $extraQuery");
        if(!$stmt->execute()){echo $con->error;}
    }else{
        //update
        $stmt = $con->prepare("update ".$g_projectSlug."_campaigns set title='$title', description='$desc', is_weekly='$is_weekly', camp_date='$campDate', camp_time='$campTime', camp_day='$day', status='$status', user_id='$userId' $extraQuery where camp_id='$actionId'; ");//change here
        if(!$stmt->execute())
        {
            $con->error;
        }
    }
    
    ?><script>location="?"</script><?
}

if(isset($_GET['delete-record'])){
    $id = mb_htmlentities($_GET['delete-record']);
        $stmt = $con->prepare("delete from ".$g_projectSlug."_campaigns where camp_id=?");
        $stmt->bind_param("s", $id);
        if(!$stmt->execute()){echo "err";}
}

$getCampaigns = getAll($con,"SELECT * FROM ".$g_projectSlug."_campaigns");
//  where user_id='$session_userId'
?>
<!DOCTYPE html>


<html lang="en">

    <!-- begin::Head -->
    <head><?require("./includes/views/head.php")?>
    <style type="text/css">
        .dataTables_filter{
            text-align: right !important;
        }
        .dataTables_paginate{
            float: right !important;
        }
    </style>
</head>

    <!-- end::Head -->

    <!-- begin::Body -->
    <body class="<?echo $g_body_class?>">

        <?require("./includes/views/header.php")?>
        
            <div class="kt-grid kt-grid--hor kt-grid--root">
            <div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--ver kt-page">
                <div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-wrapper" id="kt_wrapper">

                    <!-- begin:: Header -->
                    
                    <?require("./includes/views/topmenu.php")?>
                    <!-- end:: Header -->

                    <!-- begin:: Aside -->
                    <?require("./includes/views/leftmenu.php")?>

                    <!-- end:: Aside -->
                    <div class="kt-body kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-grid--stretch" id="kt_body">
                        <div class="kt-content  kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor" id="kt_content">

                            <!-- end:: Subheader -->

                            <!-- begin:: Content -->
                            <div class="kt-container  kt-grid__item kt-grid__item--fluid">
                            
                                <div class="kt-portlet kt-portlet--mobile">
                                    <div class="kt-portlet__head kt-portlet__head--lg">
                                        <div class="kt-portlet__head-label">
                                            <span class="kt-portlet__head-icon">
                                            </span>
                                            <h3 class="kt-portlet__head-title">
                                                Campaigns
                                            </h3>
                                        </div>
                                        <div class="kt-portlet__head-toolbar">
                                            <div class="kt-portlet__head-wrapper">
                                                <div class="kt-portlet__head-actions">
                                                    
                                                    <?if($session_role=="admin"){?>
                                                    <a href="#" class="btn btn-brand btn-elevate btn-icon-sm" data-toggle="modal" data-target="#create_record_modal">
                                                        <i class="la la-plus"></i>
                                                        Add Campaign
                                                    </a>
                                                    <?}?>
                                                            
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="kt-portlet__body">

                                        <!--begin: Datatable -->
                                        <table class="table table-striped- table-bordered table-hover table-checkable add-search" id="kt_table_1">
                                            <thead>
                                                <tr>
                                                    <th>ID</th>
                                                    <th>Title</th>
                                                    <th>Description</th>
                                                    <!--<th>Weekly</th>-->
                                                    <!--<th>Campaign Date</th>-->
                                                    <!--<th>Campaign Time</th>-->
                                                    <!--<th>Day</th>-->
                                                    <th>Created At</th>
                                                    <th>Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?
                                                foreach($getCampaigns as $row)
                                                    { 
                                                        if(true){
                                                ?>
                                                <tr>
                                                    <td><?echo $row['camp_id']?></td>
                                                    <td><?echo $row['title']?></td>
                                                    <td><?echo $row['description']?></td>
                                                    <!--<td><?echo $row['is_weekly']?></td>-->
                                                    <!--<td><?echo $row['camp_date']?></td>-->
                                                    <!--<td><?echo $row['camp_time']?></td>-->
                                                    <!--<td><?echo $row['camp_day']?></td>-->
                                                   
                                                    <td><?echo date("d-M,Y H:i A",$row['created_at'])?></td>

                                                    <td class="btn-group">
                                                        <!--<a href="./campaignView.php?_camp=<?echo $row['camp_id']?>" class="btn btn-primary" >Add Users</a>-->
                                                        <a href="./campaignView.php?_camp=<?echo $row['camp_id'];?>"  class="btn btn-info">View</a>
                                                        <?if($session_role=="admin"){?>
                                                            <a href="#" class="btn btn-warning" data-toggle="modal" data-target="#create_record_modal" data-mydata='<?echo  (json_encode($row, true));?>' >Edit</a>
                                                            
                                                            <a href="#" class="btn btn-danger" data-toggle="modal" data-target="#delete_record" data-url="?delete-record=<?echo $row['camp_id']?>">Delete</a>
                                                        <?}?>
                                                    </td>
                                                </tr>
                                                <?}}?>
                                                
                                            </tbody>
                                        </table>

                                        <!--end: Datatable -->
                                    </div>
                                </div>
                            </div>

                            
                            

                            <!-- end:: Content -->
                        </div>
                    </div>

                    <!-- begin:: Footer -->
                    
                    <?require("./includes/views/footer.php")?>

                    <!-- end:: Footer -->
                </div>
            </div>
        </div>
        
        
        <?require("./includes/views/footerjs.php")?>
        

    </body>

    <!-- end::Body -->
    
    <div class="modal fade" id="create_record_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modelTitle">Add Category</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    </button>
                </div>
                <div class="modal-body">
                    
                    <form class="kt-form" action="" method="Post" enctype="multipart/form-data">
                        <div class="kt-portlet__body">
                            <div class="form-group">
                                <label>Title (Will be used when sending email)</label><span class="text-danger">*</span>
                                <input type="text" name="title" class="form-control" required>
                            </div>
                            
                            <div class="form-group">
                                <label>Description</label><small class="text-secondary">(Will be used when sending email)</small>
                                <textarea class="form-control" name="description"></textarea>
                            </div>
                            
                            
                            <div class="row">
                                <?foreach($checkBoxInput as $value){?>
                                <div class="col-md-6">
                                    <div class="form-check">
                                      <input class="form-check-input" type="checkbox" value="" name="<?echo $value?>Send">
                                      <label class="form-check-label" >
                                        Notification Via <?echo ucfirst($value);?>
                                      </label>
                                    </div>
                                </div>
                                <?}?>
                                <br>
                            </div>
                            <br><br>
                            <?if(false){?>
                                <div class="form-group">
                                    <label>Reccour Weekly</label><span class="text-danger">*</span>
                                    <select class="form-control" name="is_weekly" required>
                                        <option disabled value>--SELECT--</option>
                                        <option value="YES" selected>YES</option>
                                        <option value="NO">NO</option>
                                    </select>
                                </div>
                            
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Date</label>
                                            <input type="date" name="camp_date" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Time</label><span class="text-danger">*</span>
                                            <input type="time" name="camp_time" class="form-control" required>
                                        </div>
                                    </div>
                                </div>
    
                                <div class="form-group">
                                    <label>Day</label>
                                    <select class="form-control" name="camp_day">
                                        <option disabled value>--SELECT--</option>
                                        <option value="Monday" selected>Monday</option>
                                        <option value="Tuesday">Tuesday</option>
                                        <option value="Wednesday">Wednesday</option>
                                        <option value="Thursday">Thursday</option>
                                        <option value="Friday">Friday</option>
                                        <option value="Saturday">Saturday</option>
                                        <option value="Sunday">Sunday</option>
                                    </select>
                                </div>
                            <?}?>

                            <input type="text" name="actionId" value="" hidden>
                            
                        </div>
                        <div class="kt-portlet__foot">
                            <div class="kt-form__actions">
                                <input type="submit" name="create_package" value="Submit" class="btn btn-primary">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                            </div>
                        </div>
                    </form>
                </div>
            
            </div>
        </div>
    </div>
    
    
    <script>
        
        $(document).ready(function(){
        
        $("#create_record_modal").on('show.bs.modal', function (e) {
            //get data-id attribute of the clicked element
            var mydata = $(e.relatedTarget).data('mydata');
            console.log(mydata);
            if(mydata!= null){
                $("#modelTitle").html("Update");
                $("input[name='title']").val(mydata['title'])
                $("textarea[name='description']").val(mydata['description'])
                $("select[name='is_weekly']").val(mydata['is_weekly'])
                $("input[name='camp_date']").val(mydata['camp_date'])
                $("input[name='camp_time']").val(mydata['camp_time'])
                $("select[name='camp_day']").val(mydata['camp_day'])
                $("input[name='actionId']").val(mydata['camp_id'])
                
                
                var email=mydata['emailSend'];
                var sms=mydata['smsSend'];
                var call=mydata['callSend'];
                if(email=="Yes")
                    $("input[name='emailSend']").prop('checked', true);
                    
                if(sms=="Yes")
                    $("input[name='smsSend']").prop('checked', true);
                    
                if(call=="Yes")
                    $("input[name='callSend']").prop('checked', true);
                    
            }else{
                $("#modelTitle").html("Insert");
                $("input[name='title']").val("")
                $("textarea[name='description']").val("")
                $("select[name='is_weekly']").val("")
                $("input[name='camp_date']").val("")
                $("input[name='camp_time']").val("")
                $("select[name='camp_day']").val("")
                $("input[name='actionId']").val("")
            }
          });
        })
    </script>                           
</html>