<?php

require("./global.php");

// email_status, sms_status
// ALTER TABLE _calendar_reminders ADD email_status VARCHAR (256) DEFAULT '' ;

$query = "SELECT * FROM ".$g_projectSlug."_calendar_reminders WHERE (sms_status='pending' OR email_status='pending') AND TIMESTAMPDIFF(SECOND, NOW(), apptDate) <= 6 * 3600";

$results = getAll($con, $query);

foreach ($results as $row) {
    echo "query run<br>";
    $apptID = $row['id'];
    $customer_id = $row['customer_id'];
    
    $phonenumber = $g_allUsersInfo[$customer_id]['phone'];
    
    $apptTime = date("h:i A", strtotime($row['apptTime']));
    $message = "Reminder: Your have an Appointment today. at, " . $apptTime;

    if ($row["sms_status"] == "pending") {
        $m = sendansms($phonenumber, $message);
        error_log("Sending SMS to $phonenumber");
        echo ("Sending SMS to $phonenumber");

        $query = "update ".$g_projectSlug."_calendar_reminders set sms_status='Sent' where id='$apptID'";
        $stmt = $con->prepare($query);
        if (!$stmt) {
            echo "err: <code>$query</code>";
        }
        if (!$stmt->execute()) {
            echo "err: <code>$query</code>";
        }
    }

    if ($row["email_status"] == "pending") {
        $m = sendEmailNotification_mailjet("You have an Appointment", $message, $g_allUsersInfo[$customer_id]['email']);

        $query = "update ".$g_projectSlug."_calendar_reminders set email_status='Sent' where id='$apptID'";
        $stmt = $con->prepare($query);
        if (!$stmt) {
            echo "err: <code>$query</code>";
        }
        if (!$stmt->execute()) {
            echo "err: <code>$query</code>";
        }
    }

    var_dump($m);

    error_log("Ran cronjob", date("d M Y h:i:s"));
}
?>
<hr>