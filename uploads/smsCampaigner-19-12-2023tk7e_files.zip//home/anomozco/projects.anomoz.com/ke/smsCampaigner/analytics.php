<?php require("./global.php");

$start = $_GET['start'];
$end = $_GET['end'];

$starttimestamp = 0;
$endtimestamp = 99999999999;
	
if (isset($_GET['start']) && $_GET['start']!=''){
    $starttimestamp = strtotime($_GET['start']);
}if (isset($_GET['end']) && $_GET['end']!=''){
    $endtimestamp = strtotime($end);
}


	
$condition = " AND timeAdded BETWEEN ".$starttimestamp." AND ".$endtimestamp;

$mydata = [
	// [ title, query, suffix example USD ]
	["Total Users","SELECT count('*') AS cnt FROM " . $g_projectSlug . "_users WHERE id=id ".$condition."  ", ""],
	["Total Train Drivers","SELECT count('*') AS cnt FROM " . $g_projectSlug . "_users WHERE sub_role='Train Driver '".$condition."", ""],
	["Total Train Technicians","SELECT count('*') AS cnt FROM " . $g_projectSlug . "_users WHERE sub_role='Train Technician '".$condition."", ""],
	["Total Supervisors","SELECT count('*') AS cnt FROM " . $g_projectSlug . "_users WHERE sub_role='supervisor '".$condition."", ""],
	["Total Ticket Form","SELECT count('*') AS cnt FROM " . $g_projectSlug . "_ticket_form WHERE id=id ".$condition."", ""],
	["Total activities","SELECT count('*') AS cnt FROM " . $g_projectSlug . "_activities WHERE id=id  ".$condition."", ""],
	["Total Batches Activities","SELECT count('*') AS cnt FROM " . $g_projectSlug . "_batches_activities WHERE id=id  ".$condition."", ""],


];
$arrayLength = count($mydata);
?>
<!DOCTYPE html>
<html lang="en">

<!-- begin::Head -->

<head>
    <? require("./includes/views/head.php") ?>

</head>

<!-- end::Head -->

<!-- begin::Body -->

<body class="<? echo $g_body_class ?>" onload="">
    <? require("./includes/views/header.php") ?>
    <div class="kt-grid kt-grid--hor kt-grid--root">
        <div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--ver kt-page">
            <div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-wrapper" id="kt_wrapper">

                <!-- begin:: Header -->

                <? require("./includes/views/topmenu.php") ?>
                <!-- end:: Header -->

                <!-- begin:: Aside -->
                <? require("./includes/views/leftmenu.php") ?>

                <!-- end:: Aside -->
                <div class="kt-body kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-grid--stretch" style="margin-top:-20px;"
                    id="kt_body">
                    <div class="kt-content  kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor" id="kt_content">
                        

                        <div class="kt-container  kt-grid__item kt-grid__item--fluid">
    
                            <? if (isset($_GET['m'])) { ?>
                            <div class="alert alert-info">
                                <? echo $_GET['m'] ?>
                            </div>
                            <? } ?>
    
                            <div class="container1 shadow mt-3"
                                style="height:200px;background-image: url('https://projects.anomoz.com/commonAssets/shapes-light.png');background-position: center;background-size: cover;border-radius: 14px;   ;">
                                <h4 style="margin-left:10px; padding-top:20px;" class="">Analytics</h4>
                                <div class="head p-3" style="float:right">
                                </div>
                                <form action="" method="get">
                                    <div class="row">
                                        <div class="form-group col-2">
                                            <label for="from_date" class="">From Date</label>
                                            <input type="date" name="start"
                                                value="<?php echo isset($_GET['start']) ?  $_GET['start'] : '';  ?>"
                                                class="form-control" id="date">
                                        </div>
                                        <div class="form-group col-2">
                                            <label for="to_date" class="">To Date</label>
                                            <input type="date" class="form-control" id="to_date" name="end"
                                                value="<?php echo isset($_GET['end']) ? $_GET['end'] : '' ?>">
                                        </div>
    
                                        <div class="button col-2 mt-4">
                                            <button type="submit" name="submit" class="btn btn-primary">Filter</button>
                                        </div>
    
                                    </div>
                                </form>
    
    
                            </div>
    
                            <div class="container kt-widget17__stats" style="margin-top:-50px;">
                                <div class="row kt-widget17__items">
                                    <?php for ($i=0; $i <$arrayLength; $i++) { ?>
                                    <div class="col-lg-3 col-md-4 col-sm-6">
                                        <div class="card kt-widget17__item shadow">
                                            <div class="card-body">
                                                <h5 class="card-title kt-widget17__subtitle"><?php echo $mydata[$i]['0'];?>
                                                </h5>
                                                <p class="card-text kt-widget17__desc">
                                                    <?php
                                                if (true) {
                                                    // echo $mydata[$i][1];
                                                    $value = getRow($con,$mydata[$i][1]);
                                                    if($value['cnt']==""){$value['cnt'] = 0;}
                                                    echo $mydata[$i][2]." ".number_format(round($value['cnt'], 2));
                                                         
                                                }
                                                ?>
                                                </p>
                                            </div>
                                        </div>
                                        <div style="height:10px;"></div>
                                    </div>
                                    <?php }?>
    
                                </div>
    
    
                                <div class="row">
    
    
                                    <div class="col-lg-6">
                                        <div class="kt-portlet kt-portlet--mobile">
                                            <div class="kt-portlet__head kt-portlet__head--lg">
                                                <div class="kt-portlet__head-label">
                                                    <h3 class="kt-portlet__head-title">Users Trend</h3>
                                                </div>
                                            </div>
                                            <div class="kt-portlet__body"><canvas id="graph_users"></canvas></div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="kt-portlet kt-portlet--mobile">
                                            <div class="kt-portlet__head kt-portlet__head--lg">
                                                <div class="kt-portlet__head-label">
                                                    <h3 class="kt-portlet__head-title">Users Groups</h3>
                                                </div>
                                            </div>
                                            <div class="kt-portlet__body"><canvas id="group_users"></canvas></div>
                                        </div>
                                    </div>
    
                                    <div class="col-lg-6">
                                        <div class="kt-portlet kt-portlet--height-fluid">
                                            <div class="kt-portlet__body  kt-portlet__body--fit">
                                                <div class="row row-no-padding row-col-separator-lg">
                                                    <?
                									    $mydata = [
                                                    		// [ title, query, suffix ]
                                                    		["Total Users","SELECT count('*') AS cnt FROM " . $g_projectSlug . "_users WHERE id=id ".$condition."  ", ""],
                                                    		["Total Train Drivers","SELECT count('*') AS cnt FROM " . $g_projectSlug . "_users WHERE sub_role='Train Driver '".$condition."", ""],
                                                    		["Total Users","SELECT count('*') AS cnt FROM " . $g_projectSlug . "_users WHERE id=id ".$condition."  ", ""],
                                                    		["Total Train Drivers","SELECT count('*') AS cnt FROM " . $g_projectSlug . "_users WHERE sub_role='Train Driver '".$condition."", ""],
                                                		];
                									    $themes = ["brand","warning","danger","success"];
                									    foreach($mydata as $i=>$query){?>
                                                    <div class="col-md-6">
                                                        <div class="kt-widget24">
                                                            <div class="kt-widget24__details">
                                                                <div class="kt-widget24__info">
                                                                    <h4 class="kt-widget24__title">
                                                                        <?php echo $mydata[$i]['0'];?>
                                                                    </h4>
                                                                    <span class="kt-widget24__desc">
                                                                        <?php echo $mydata[$i]['0'];?>
                                                                    </span>
                                                                </div>
                                                                <span
                                                                    class="kt-widget24__stats kt-font-<?echo $themes[$i]?>">
                                                                    <?$value = getRow($con,$mydata[$i][1]);
                                                                        if($value['cnt']==""){$value['cnt'] = 0;}
                                                                        echo $mydata[$i][2]." ".number_format(round($value['cnt'], 2));?>
                                                                </span>
                                                            </div>
                                                            <div class="progress progress--sm">
                                                                <div class="progress-bar kt-bg-<?echo $themes[$i]?>"
                                                                    role="progressbar" style="width: 100%;"
                                                                    aria-valuenow="50" aria-valuemin="0"
                                                                    aria-valuemax="100"></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <?}?>
    
                                                </div>
                                            </div>
                                        </div>
    
                                    </div>
                                    <div class="col-lg-6">
                                            <div class="kt-portlet kt-portlet--mobile">
                                            <div class="kt-portlet__head kt-portlet__head--lg">
                                                <div class="kt-portlet__head-label">
                                                    <span class="kt-portlet__head-icon">
                                                    </span>
                                                    <h3 class="kt-portlet__head-title">Latest Users</h3>
                                                </div>
                                                <div class="kt-portlet__head-toolbar">
                                                </div>
                                            </div>
                                            <div class="kt-portlet__body">
                                                <form action="" method="post">
            
                                                    <table class="table table-striped- table-bordered table-hover table-checkable ">
                                                        <thead>
                                                            <tr>
                                                                <th>Name</th>
                                                                <th>Email</th>
                                                                <th>Phone</th>
                                                                <th>Address</th>
                                                                <th>Date</th>
                                                               
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?
                                                            $query = "select * from " . $g_projectSlug . "_users t order by t.timeAdded desc limit 5";
                                                            $results = getAll($con, $query);
                                                            foreach ($results as $row) { ?>
                                                                <tr>
                                                                    <td><? echo $row['name'] ?></td>
                                                                    <td><? echo $row['email'] ?></td>
                                                                    <td><? echo $row['phone'] ?></td>
                                                                    <td><? echo $row['address'] ?></td>
                                                                    <td><? echo date("D, d M", $row['timeAdded']) ?></td>
                                                                    
                                                                </tr>
                                                            <? } ?>
                                                        </tbody>
                                                    </table>
            
            
                                                </form>
                                            </div>
                                        </div>

                                    </div>
    
                                </div>
    
                            </div>
                            
                        </div>

                    </div>
                </div>

                <!-- begin:: Footer -->

                <? require("./includes/views/footer.php") ?>

                <!-- end:: Footer -->
            </div>
        </div>
    </div>


    <? require("./includes/views/footerjs.php") ?>
    
    <script>
        // Function to generate random colors
        function generateRandomColors(count) {
            var colors = [];
            for (var i = 0; i < count; i++) {
                colors.push(getRandomColor());
            }
            return colors;
        }

        // Function to get a random color
        function getRandomColor() {
            var letters = '0123456789ABCDEF';
            var color = '#';
            for (var i = 0; i < 6; i++) {
                color += letters[Math.floor(Math.random() * 16)];
            }
            return color;
        }
    </script>


    <!--graph 1-->
    <script>
    <?
    $users_graph_array = [];
    $year = date("Y");
    $query = " SELECT (DATE_FORMAT(FROM_UNIXTIME(timeAdded), '%m')) month, count(id) cnt from ".$g_projectSlug.
    "_users where (DATE_FORMAT(FROM_UNIXTIME(timeAdded), '%Y')) = '" . $year . "'
    $condition GROUP by(DATE_FORMAT(FROM_UNIXTIME(timeAdded), '%m'));";
    $results = getAll($con, $query);
    for ($j = 1; $j <= 12; $j++) {
        $sales = 0;
        foreach($results as $row) {
            if ($j == $row['month']) {
                $sales = round($row['cnt'], 2);
            }
        }
        $users_graph_array[] = $sales;
    } ?>
    var xValues = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    var backgroundColors = generateRandomColors(xValues.length);
    new Chart("graph_users", {
        type: "bar",
        data: {
            labels: xValues,
            datasets: [{
                fill: false,
                backgroundColor: backgroundColors,
                borderColor: backgroundColors,
                data: <? echo json_encode($users_graph_array, true); ?> ,
                label : 'Value'
            }]
        }
    });
    </script>
    
    
    <!--graph 2-->
    <script>
        
        <?
        $data = [];
        $query = "SELECT role, count(role) cnt from ".$g_projectSlug."_users WHERE 1=1 $condition group by role";
        $results = getAll($con, $query);
        foreach($results as $row){$data[$row['role']] = $row['cnt'];}?>
        var data = <?echo json_encode($data, true)?>;
    
        var labels = Object.keys(data);
        var values = Object.values(data);
        var backgroundColors = generateRandomColors(values.length);
        var chartData = {
            labels: labels,
            datasets: [{
                data: values,
                backgroundColor: backgroundColors,
                hoverBackgroundColor: backgroundColors,
            }]
        };
        
        var ctx = document.getElementById('group_users').getContext('2d');
        var myDoughnutChart = new Chart(ctx, {
            type: 'doughnut',
            data: chartData,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                cutoutPercentage: 60, // Adjust as needed
            }
        });
        
        
            
    </script>
</body>


</html>