<?

include_once("./global.php");

 
 
$a = sendTemplateEmail("Ahsan tests11","hello 123", "snahmed1998@gmail.com");
var_dump($a);
?>
<hr>

