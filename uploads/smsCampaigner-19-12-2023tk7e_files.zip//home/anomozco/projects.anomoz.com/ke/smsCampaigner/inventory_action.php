<?  require("./global.php");
$primaryTableName = "inventory_history";
  
$action = $_GET['action'];
$materialCost = [
	"Inventory",
];
if (isset($_POST['addSubmit'])) {
    $productname = empty($_POST['pname']) ? array() : $_POST['pname'];
    $qty = empty($_POST['qty']) ? array() : $_POST['qty'];
     $countproduct = count($productname);
      for ($i=0; $i < $countproduct ; $i++) { 
    
        $timeAdded = time();
        $id = generateRandomString();
    
      
        $qry = "SELECT title FROM ".$g_projectSlug."_products WHERE id = '$productname[$i]' ";
        $productid = getRow($con,$qry);
        
        $query = "insert into ".$g_projectSlug."_".$primaryTableName." set id='$id' ,product_id = '$productname[$i]' ,quantity = '$qty[$i]' , timeAdded='$timeAdded', 
        userId='$session_userId', action='$action' ";
        $stmt = $con->prepare($query);
        if(!$stmt){echo "err: <code>$query</code>";}
        if(!$stmt->execute()){echo "err: <code>$query</code>";}
     
        if($action=="add"){
            $query2 = "UPDATE  ".$g_projectSlug."_products set qty = qty + $qty[$i]  WHERE id = '$productname[$i]'";
        }else{
            $query2 = "UPDATE  ".$g_projectSlug."_products set qty = qty - $qty[$i]  WHERE id = '$productname[$i]'";
        }
        $stmt2 = $con->prepare($query2);
        if(!$stmt2){echo "err: <code>$query</code>";}
        if(!$stmt2->execute()){echo "err: <code>$query</code>";}
     }
     
     header("Location: ./products.php?m=Inventory Updated");
}
?>
<!DOCTYPE html>
<html lang="en">
	<!-- begin::Head -->
	<head><?require("./includes/views/head.php")?>
</head>
	<!-- end::Head -->
	<!-- begin::Body -->
	<body class="<?echo $g_body_class?>">
		<?require("./includes/views/header.php")?>
        
        	<div class="kt-grid kt-grid--hor kt-grid--root">
			<div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--ver kt-page">
				<div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-wrapper" id="kt_wrapper">
					<!-- begin:: Header -->
					
                    <?require("./includes/views/topmenu.php")?>
					<!-- end:: Header -->
					<!-- begin:: Aside -->
					<?require("./includes/views/leftmenu.php")?>
					<!-- end:: Aside -->
					<div class="kt-body kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-grid--stretch" id="kt_body">
						<div class="kt-content  kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor" id="kt_content">
							<!-- end:: Subheader -->
							<!-- begin:: Content -->
								<!-- begin:: Content -->
							<div class="kt-container  kt-grid__item kt-grid__item--fluid">
                                <!-- begin:: profile -->
                                    <div class="row">
									<div class="col-xl-12">
										<!--begin:: Widgets/Applications/User/Profile3-->
										<div class="kt-portlet kt-portlet--height-fluid">
											<div class="kt-portlet__body text-center">
												<div class="kt-widget kt-widget--user-profile-3">
													<div class="kt-widget__top">
														<div class="kt-widget__content">
															<div class="kt-widget__head">
																<a href="#" class="kt-widget__username m-auto">
																Edit Item Quantities
																	<!-- <i class="flaticon2-correct"></i> -->
																</a>
															</div>
															<div class="kt-widget__info">
																<div class="kt-widget__desc">
																	
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
										<!--end:: Widgets/Applications/User/Profile3-->
									</div>
								</div>
                                <!-- end:: profile -->
				
                               
								<div class="kt-portlet kt-portlet--mobile">
									<div class="kt-portlet__head kt-portlet__head--lg">
										<div class="px-5 w-100">
											<div class="row pt-4">
												
												<div class="col-md-3">
													<h5 class="kt-portlet__head-title">Product Name</h5>
												</div>
												<div class="col-md-3">
													<h5 class="kt-portlet__head-title">Quantity</h5>
												</div>
												
											</div>
										</div>
									</div>
								</div>
								<form action="" method="post" role="form" class="" id="addMaterialForm">
								<?php foreach($materialCost as $mc){ 
									$getMCRecord = getAll($con,"SELECT * FROM ".$g_projectSlug."_products  ");
									?>
									<div class="kt-portlet kt-portlet--mobile formRepeater-<?echo $mc;?>" id="formRepeater-<?echo $mc;?>">
										<div class="kt-portlet__head kt-portlet__head--lg">
											<div class="kt-portlet__head-label">
											
												<h3 class="kt-portlet__head-title">
													Inventory  -  <?echo $action?>
												</h3>
											</div>
											<div class="kt-portlet__head-toolbar">
												<div class="kt-portlet__head-wrapper">
													<div class="kt-portlet__head-actions">
                                                            <!--<a href="#" class="btn btn-primary" data-toggle="modal" data-target="#bulk_import_modal" >Import File</a>-->
    
                                                            <button type="button" class="addRequirement btn btn-primary" onclick="addOneRow('formRepeaterBox-<?echo $mc;?>','add')"><i class="la la-plus"></i>ADD ITEM</button>
            
													</div>
												</div>
											</div>
										</div>
										<div class="kt-portlet__body" >
											
											<div id="formRepeaterBox-<?echo $mc;?>" data-mat-type="<?php echo $mc;?>">
												<? 
												if(count($getMCRecord)==0){$getMCRecord = array(1);}
											
												?>
												<div class="repeaterItem-<?echo $mcRecordID;?>" id="<?echo $mcRecordID;?>">
													
													<div class="row">
														
														<div class="col-md-3 form-group">
                                                        
                                                        <select class="form-control" name="pname[]" >
                                                        	<option value="">Select Product</option>
                                                        	<?php 
                                                             $getproduct = getAll($con,"SELECT * FROM ".$g_projectSlug."_products ");
                                                                 foreach($getproduct as $p){ ?>
                                                                    <option value="<?php echo $p['id'] ?>"><?php echo  $p['title'] ?></option>
                                                                <?php
                                                                }
                                                        ?>
                                                        </select>
														
														</div>
														<div class="col-md-2 form-group">
															<input type="text" class="form-control" name="qty[]" placeholder="" value="<?echo $record['qty'];?>" required>
														</div>
															<div class="col-md-2 form-group">
															<input type="hidden"   class="form-control" name="add[]" placeholder=" " value="add">
															</div>
														
														<div class="col-md-1 form-group">
															<button type="button" class="btn btn-danger removeTableRow " onclick="hide('<?echo $mcRecordID?>')">Remove</button>
														</div>
													</div>
												</div>
												
											</div>
														
										</div>
        								<div class="kt-portlet kt-portlet--mobile">
        									<div class="kt-portlet__body m-auto">
        										
        										<button  name="addSubmit" value="addSubmit" type="submit" class="btn btn-success">Submit </button> 
        									</div>
        								</div>
									</div>
								<?php }?>
								</form>
                            
							</div>
							<!-- end:: Content -->
							
							
							<!-- end:: Content -->
						</div>
					</div>
					<!-- begin:: Footer -->
					
					<?require("./includes/views/footer.php")?>
					<!-- end:: Footer -->
				</div>
			</div>
		</div>
        
        
        <?require("./includes/views/footerjs.php")?>
		
	</body>
    <?if(checkGlobalPermission('enableImport')){?>
    <div class="modal fade" id="bulk_import_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    		<div class="modal-dialog" role="document">
    			<div class="modal-content">
    				<div class="modal-header">
    					<h5 class="modal-title" id="modelTitle">Bulk Import</h5>
    					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
    					</button>
    				</div>
    				<div class="modal-body">
    					
    					<form class="kt-form" action="" method="Post" enctype="multipart/form-data">
    						<div class="kt-portlet__body">
    						    <div>
                                    <div class="upload_file_box">
                                       
                                        <div class="form-group">
                                            <label>Bulk Upload Excel File</label>
                                            <div class="custom-file">
                                                <input type="file" class="custom-file-input" id="excel_file" name="import_excel_file" accept=".csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel">
                                                <label class="custom-file-label" for="excel_file">Choose file</label>
                                            </div>
                                            <a href="./uploads/sample_import_file.xlsx" download=""><small class="text-primary">Sample File</small></a>
                                        </div>
                                    </div>
                                   
                                    <div class="form-group">
                                        <input type="submit" name="submit" id="submit_form" class="btn btn-block btn-primary" value="SUBMIT">
                                     
                                    </div>
                                </div>
                                  
    						</div>
    					</form>
    				</div>
    			
    			</div>
    		</div>
    	</div>
    <?}?>
	<script>
	  function makeid(length) {
        	var result           = '';
        	var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        	var charactersLength = characters.length;
        	for ( var i = 0; i < length; i++ ) {
        		result += characters.charAt(Math.floor(Math.random() * 
        			charactersLength));
        	}
        	return result;
        }
function addOneRow(div_name,action){
	var mat_type = $("#"+div_name).attr("data-mat-type");
    
	var count = $(div_name).children('div.repeaterItem').length + 1;
	var random=makeid(10).toUpperCase();
    
    string = `
		<div class="repeaterItem-`+mat_type+`" id="`+random+`">
		<div>
		</div>
		<div class="row">
		
		<div class="col-md-3 form-group">
          <select class="form-control" name="pname[]" >
            	<option value="">Select Product</option>
            	<?php 
            $getproduct = getAll($con,"SELECT * FROM ".$g_projectSlug."_products ");
         foreach($getproduct as $p){ ?>
    
                <option value="<?php echo $p['id'] ?>"><?php echo  $p['title'] ?></option>
            
            <?php
            }
            ?>
            </select>
		</div>
	
		<div class="col-md-2 form-group">
		<input type="text" class="form-control" name="qty[]" placeholder=" " required>
		</div>
	<div class="col-md-2 form-group">
		<input type="hidden" class="form-control" name="add[]" placeholder=" " value="`+action+`" >
		</div>
		<div class="col-md-1 form-group">
		<button type="button" class="btn btn-danger removeTableRow " onclick="hide('`+random+`')">Remove</button>
		</div>
		</div>
		</div>
		`;
	$("#"+div_name).append(string);   
	
}
function hide(id){
    $("#"+id).hide();
    $("#"+id +" input").attr("disabled", "disabled")
}
	</script>
				
		
								
</html>