<?php
include('./global.php');

$prompt = 'Hi!';

if (isset($_GET['prompt'])) {
    $prompt = $_GET['prompt'];
} 

echo askChatGPT($prompt); //function is defined in global.php


?>
