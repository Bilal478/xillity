<? require("./global.php");
$primaryTableName = "attendance";
//test1


if (isset($_POST['create_package'])) {
    $timeAdded = time();
    $attendance = 'p';
    $actionId = mb_htmlentities(($_POST['actionId']));
    if ($actionId == "") {
        $id = generateRandomString();
        $actionId = $id;
        $query = "insert into " . $g_projectSlug . "_attendance set id='$id' , timeAdded='$timeAdded', attendance='$attendance'  , userId='$session_userId' ";
    } else {
        $query = "update " . $g_projectSlug . "_attendance set id='$actionId'  where id='$actionId'";
    }
    $stmt = $con->prepare($query);
    if (!$stmt) {
        echo "err: <code>$query</code>";
    }
    if (!$stmt->execute()) {
        echo "err: <code>$query</code>";
    }
    
    
    $rStr = "";
    if (isset($_GET['id'])) {
        $rStr .=  "&id=" . $_GET['id'];
    }
    header("Location: ?m=Data was saved successfully!" . $rStr);
}


$getCustomersFromDB = getAll($con,"SELECT * FROM ".$g_projectSlug."_users");
$g_allUsersInfo = [];
foreach($getCustomersFromDB as $k => $v){
	$g_allUsersInfo[$v['id']] = $v; 
}


?>
<!DOCTYPE html>


<html lang="en">

<!-- begin::Head -->

<head><? require("./includes/views/head.php") ?>

    <script>
        function disableButton() {
            var button = document.getElementById('myButton');
            button.disabled = true;
        }
    </script>
</head>

<!-- end::Head -->

<!-- begin::Body -->

<body class="<? echo $g_body_class ?>">

    <? require("./includes/views/header.php") ?>

    <div class="kt-grid kt-grid--hor kt-grid--root">
        <div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--ver kt-page">
            <div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-wrapper" id="kt_wrapper">

                <!-- begin:: Header -->

                <? require("./includes/views/topmenu.php") ?>
                <!-- end:: Header -->

                <!-- begin:: Aside -->
                <? require("./includes/views/leftmenu.php") ?>

                <!-- end:: Aside -->
                <div class="kt-body kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-grid--stretch" id="kt_body">
                    <div class="kt-content  kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor" id="kt_content">

                        <!-- end:: Subheader -->

                        <!-- begin:: Content -->
                        <div class="kt-container  kt-grid__item kt-grid__item--fluid">

                            <? if (isset($_GET['m'])) { ?>
                                <div class="alert alert-info"><? echo $_GET['m'] ?></div>
                            <? } ?>

                            <div class="kt-portlet kt-portlet--mobile">
                                <div class="kt-portlet__head kt-portlet__head--lg">
                                    <div class="kt-portlet__head-label">
                                        <span class="kt-portlet__head-icon">
                                        </span>
                                        <h3 class="kt-portlet__head-title">
                                            <? echo ucfirst(str_replace("_", " ", $primaryTableName)); ?>
                                        </h3>
                                    </div>
                                    <div class="kt-portlet__head-toolbar">
                                        <div class="kt-portlet__head-wrapper">
                                            <div class="kt-portlet__head-actions">

                                                <? renderImportExportButtons($primaryTableName); ?>

                                                
                                                <?
                                                
                                                $date = date("Y-m-d"); 
                                                $query = "SELECT * FROM ".$g_projectSlug."_attendance WHERE userId = '$session_userId' AND DATE(FROM_UNIXTIME(timeAdded)) = '$date' ORDER BY timeAdded DESC";
                                                $results = getAll($con, $query);
                                                if(count($results)==0){?>
                                             
                                                <a href="#" class="btn btn-brand btn-elevate btn-icon-sm" data-toggle="modal" data-target="#create_record_modal">
                                                        MARK ME PRESENT FOR TODAY
                                                </a>
                                                <?}else{?><a href="#" class="btn btn-brand btn-elevate btn-icon-sm disabled" >
                                                        PRESENT MARKED
                                                </a>
                                                <?}?>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="kt-portlet__body">
                                    <form action="" method="post">
                                        <? if (checkGlobalPermission('g_enableBulkDelete')) { ?>
                                            <button type="button" class="btn btn-info btn-sm text-white " onclick="selectAll();">Select All</button>
                                            <button type="submit" class="btn btn-danger btn-sm text-white ">Delete Bulk</button>
                                        <? } ?>


                                        <table class="table table-striped- table-bordered table-hover table-checkable add-search">
                                            <thead>
                                                <tr>
                                                    <th>Employees</th>

                                                    <?php
                                                    // Set the timezone
                                                    date_default_timezone_set('UTC');

                                                    // Get the current month and year
                                                    $currentMonth = date('m');
                                                    $currentYear = date('Y');

                                                    // Get the number of days in the current month
                                                    $numDays = cal_days_in_month(CAL_GREGORIAN, $currentMonth, $currentYear);

                                                    // Open the table
                                                    // echo '<table>';

                                                    // Loop through each day of the current month and display the date in a table cell
                                                    for ($day = 1; $day <= $numDays; $day++) {
                                                        // If this is the first day of a row, open a new row
                                                        if (($day - 1) % 30 == 0) {
                                                            // echo '<tr>';
                                                        }

                                                        // Output the date in a table cell
                                                        $date = sprintf('%02d-%02d-%d', $currentYear, $currentMonth, $day);
                                                        echo '<th>' . $date . '</th>';

                                                        // If this is the last day of a row, close the row
                                                        if ($day % 30 == 0) {
                                                            // echo '</tr>';
                                                        }
                                                    }

                                                    // Close the table
                                                    // echo '</table>';
                                                    ?>



                                                    </th>



                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                // Loop through each user and retrieve their attendance data for each day of the current month".$g_projectSlug."_attendance
                                                $query = "SELECT * FROM ".$g_projectSlug."_users where id LIKE '%$session_userId_filter%' and role='employee'";
                                                $users = getAll($con, $query);
                                                foreach ($users as $user) {
                                                    echo '<tr>';
                                                    echo '<td>' . $g_allUsersInfo[$user['id']]['name'] . '</td>';
                                                    
                                                    for ($day = 1; $day <= $numDays; $day++) {
                                                        $attendance_found = "none";
                                                        // Output the date in a table cell
                                                        $date = sprintf('%02d-%02d-%d', $currentYear, $currentMonth, $day);
                                                        $query = "SELECT * FROM ".$g_projectSlug."_attendance WHERE userId = '{$user['id']}' AND DATE(FROM_UNIXTIME(timeAdded)) = '$date' ORDER BY timeAdded DESC";
                                                        $results = getAll($con, $query);
                                                        echo '<td>';
                                                        foreach ($results as $row) {
                                                            $attendance_found = $row['attendance'];
                                                        }
                                                        if(count($results)==0){
                                                            $attendance_found = '';
                                                        }
                                                        
                                                        if($attendance_found==''){
                                                            ?><div class="badge badge-warning">Absent</div> <?
                                                        }else if($attendance_found=="p"){
                                                            ?><div class="badge badge-primary">Present</div> <?
                                                        }else{
                                                            
                                                        }
                                                        
                                                            
                                                        echo '</td>';
                                                    }
                                                    echo '</tr>';
                                                }
                                                ?>
                                            </tbody>
                                        </table>


                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <? require("./includes/views/footer.php") ?>
            </div>
        </div>
    </div>
    <? require("./includes/views/footerjs.php") ?>
</body>

<!-- end::Body -->

<div class="modal fade" id="create_record_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modelTitle">Insert</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                </button>
            </div>
            <div class="modal-body">

                <form class="kt-form" action="" method="Post" enctype="multipart/form-data">
                    <div class="kt-portlet__body">

                        If you are present, then click submit button.

                    </div>
                    <div class="kt-portlet__foot">
                        <div class="kt-form__actions">
                            <input type="submit" name="create_package" value="I'm Present." class="btn btn-primary">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<!-- MODAL EDIT SCRIPT CODE-->



</html>