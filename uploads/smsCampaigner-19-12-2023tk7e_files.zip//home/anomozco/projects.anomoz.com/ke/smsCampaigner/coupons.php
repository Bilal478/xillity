 <?  require("./global.php");
$primaryTableName = "coupons";

    array(
        // field_name [type, isrequired, array_select, inner_type] <= "template"
        "coupon_code" => ["input", "", "", "text"],
	 "description" => ["input", "", "", "text"],
 	"is_used" => ["input", "", "", "text"],
 	"used_by" => ["input", "", "", "text"],
 	"used_on" => ["input", "", "", "text"],
	 "discount" => ["input", "", "", "text"],
     
        // "document" => ["input", "", "", "file"],
    );

;
    


if(isset($_POST['create_package'])){
    $timeAdded = time();
    $actionId = mb_htmlentities(($_POST['actionId']));
    $coupon_code = mb_htmlentities($_POST['coupon_code']);    
    $description = mb_htmlentities($_POST['description']);    
    $is_used = mb_htmlentities($_POST['is_used']);    
    $used_by = mb_htmlentities($_POST['used_by']);    
    $used_on = mb_htmlentities($_POST['used_on']);    
    $discount = mb_htmlentities($_POST['discount']);    
    if($actionId==""){
        $id = generateRandomString();
        $actionId = $id;
        $query = "insert into ginoSubscriptionManager_coupons set id='$id' , coupon_code='$coupon_code', description='$description', is_used='no', used_by='', used_on='', discount='$discount', timeAdded='$timeAdded', userId='$session_userId' ";
    }else{
        $query = "update ginoSubscriptionManager_coupons set id='$actionId' , coupon_code='$coupon_code', description='$description', discount='$discount' where id='$actionId'";
    }
    $stmt = $con->prepare($query);
    if(!$stmt){echo "err: <code>$query</code>";}
    if(!$stmt->execute()){echo "err: <code>$query</code>";}

    $rStr = "";
    if(isset($_GET['id'])){$rStr .=  "&id=".$_GET['id'];}
    header("Location: ?m=Data was saved successfully!".$rStr);
}
    
if(isset($_GET['delete-record'])){
    $id = mb_htmlentities($_GET['delete-record']);
    if($id!="admin"){
        $stmt = $con->prepare("delete from ginoSubscriptionManager_coupons where id=?");
        $stmt->bind_param("s", $id);
        if(!$stmt->execute()){echo "err";}
    }
}


?>
<!DOCTYPE html>


<html lang="en">

    <!-- begin::Head -->
    <head><?require("./includes/views/head.php")?>
</head>

    <!-- end::Head -->

    <!-- begin::Body -->
    <body class="<?echo $g_body_class?>">

        <?require("./includes/views/header.php")?>
        
            <div class="kt-grid kt-grid--hor kt-grid--root">
            <div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--ver kt-page">
                <div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-wrapper" id="kt_wrapper">

                    <!-- begin:: Header -->
                    
                    <?require("./includes/views/topmenu.php")?>
                    <!-- end:: Header -->

                    <!-- begin:: Aside -->
                    <?require("./includes/views/leftmenu.php")?>

                    <!-- end:: Aside -->
                    <div class="kt-body kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-grid--stretch" id="kt_body">
                        <div class="kt-content  kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor" id="kt_content">

                            <!-- end:: Subheader -->

                            <!-- begin:: Content -->
                            <div class="kt-container  kt-grid__item kt-grid__item--fluid">
                                
                                <?if(isset($_GET['m'])){?>
                                    <div class="alert alert-info"><?echo $_GET['m']?></div>
                                <?}?>

                                <div class="kt-portlet kt-portlet--mobile">
                                    <div class="kt-portlet__head kt-portlet__head--lg">
                                        <div class="kt-portlet__head-label">
                                            <span class="kt-portlet__head-icon">
                                            </span>
                                            <h3 class="kt-portlet__head-title">
                                                <?echo ucfirst(str_replace("_", " ", $primaryTableName));?>
                                            </h3>
                                        </div>
                                        <div class="kt-portlet__head-toolbar">
                                            <div class="kt-portlet__head-wrapper">
                                                <div class="kt-portlet__head-actions">
                                                    
                                                    <?renderImportExportButtons($primaryTableName);?>
                                                    
                                                    <a href="#" class="btn btn-brand btn-elevate btn-icon-sm" data-toggle="modal" data-target="#create_record_modal">
                                                        <i class="la la-plus"></i>
                                                        New Record
                                                    </a>
                                                            
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="kt-portlet__body">
                                        <form action="" method="post">
                                            <?if(checkGlobalPermission('g_enableBulkDelete')){?>
                                                <button type="button" class="btn btn-info btn-sm text-white " onclick="selectAll();">Select All</button>
                                                <button type="submit"  class="btn btn-danger btn-sm text-white ">Delete Bulk</button>
                                            <?}?>

                                            <!-- TABLE HTML CODE-->
                                            
<table class="table table-striped- table-bordered table-hover table-checkable add-search" >
    <thead>
        <tr>
            <th>Coupon code</th>
            <th>Description</th>
            <!--<th>Is used</th>-->
            <!--<th>Used by</th>-->
            <!--<th>Used on</th>-->
            <th>Discount</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
    <? $query = "select * from ginoSubscriptionManager_coupons t where t.userId like '%$session_userId_filter%' order by t.timeAdded desc";
    $results = getAll($con, $query);
        foreach($results as $row){?>
            <tr>
                <td><?echo $row['coupon_code']?></td>
                <td><?echo $row['description']?></td>
                <!--<td><?echo $row['is_used']?></td>-->
                <!--<td><?echo $row['used_by']?></td>-->
                <!--<td><?echo $row['used_on']?></td>-->
                <td><?echo $row['discount']?></td>
                <td >
                        <div class="btn-group">
                            <a href="#" class="btn btn-warning" data-toggle="modal" data-target="#create_record_modal" data-mydata='<?echo  htmlspecialchars(json_encode($row, JSON_UNESCAPED_SINGLEQUOTES | JSON_UNESCAPED_UNICODE));?>' >Edit</a>
                            <a href="#" class="btn btn-danger" data-toggle="modal" data-target="#delete_record" data-url="?<?if(isset($_GET['id'])){echo "id=".$_GET['id']."&";}?>delete-record=<?echo $row['id']?>">Delete</a>
                        </div>
                </td>
            </tr>
        <?}?>
    </tbody>
</table>

                                            
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?require("./includes/views/footer.php")?>
                </div>
            </div>
        </div>
        <?require("./includes/views/footerjs.php")?>
    </body>

    <!-- end::Body -->
    
    <div class="modal fade" id="create_record_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modelTitle">Insert</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    </button>
                </div>
                <div class="modal-body">
                    
                    <form class="kt-form" action="" method="Post" enctype="multipart/form-data">
                        <div class="kt-portlet__body">
                            
                            <!-- MODAL FIELD CODE-->
                            <!-- modal -->

<div>
<div class="form-group">
    <label>Coupon code</label>
    <input type="text" name="coupon_code" class="form-control"   >
</div>
	
<div class="form-group">
    <label>Description</label>
    <input type="text" name="description" class="form-control"   >
</div>

<div class="form-group">
    <label>Discount</label>
    <input type="text" name="discount" class="form-control"   >
</div>
	
<input type="text" name="actionId" value="" hidden>

</div>
                            
                        </div>
                        <div class="kt-portlet__foot">
                            <div class="kt-form__actions">
                                <input type="submit" name="create_package" value="Submit" class="btn btn-primary">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    
    <!-- MODAL EDIT SCRIPT CODE-->
    <script>$(document).ready(function(){
	      

          $("#create_record_modal").on('show.bs.modal', function (e) {
            var mydata = $(e.relatedTarget).data('mydata');
            console.log("mydata->",mydata);
            $("input[type='checkbox']").prop('checked', false);
            if(mydata!= null){
            	$("#modelTitle").html("Update");            	
                $("input[name='coupon_code']").val(mydata['coupon_code'])                
                $("input[name='description']").val(mydata['description'])                
                $("input[name='is_used']").val(mydata['is_used'])                
                $("input[name='used_by']").val(mydata['used_by'])                
                $("input[name='used_on']").val(mydata['used_on'])                
                $("input[name='discount']").val(mydata['discount'])                                
                $("input[name='actionId']").val(mydata['id'])
            }else{
                $("#modelTitle").html("Insert");
                $("input[name='coupon_code']").val("")
                $("input[name='description']").val("")
                $("input[name='is_used']").val("")
                $("input[name='used_by']").val("")
                $("input[name='used_on']").val("")
                $("input[name='discount']").val("")
            
                $("input[name='actionId']").val("")
            }
        });
    })
</script>
                
        
                                
</html> 