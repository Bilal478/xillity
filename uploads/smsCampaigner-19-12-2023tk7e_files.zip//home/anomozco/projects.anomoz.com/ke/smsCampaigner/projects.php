<?  require("./global.php");
$primaryTableName = "projects";

if(!checkGlobalPermission('enableProjectsManagement')){header("Location: ./home.php?m=Oops! Error occured");}


$getcustomersFromDB = getAll($con,"SELECT * FROM `".$g_projectSlug."_users` WHERE `role`='customer'");
$customersArr = [];
foreach($getcustomersFromDB as $k => $v){
	$customersArr[$v['id']] = ucfirst($v['name']); 
}

$arrayFields_crud = array(
    // field_name [type, isrequired, array_select, inner_type] <= "template"
    "cover_photo" => ["input", " ", "", "image"],
    "title" => ["input", "required ", "", "text"],
    "start_date" => ["input", " ", "", "date"],
    "due_date" => ["input", " ", "", "date"],
    "tagline" => ["input", " ", "", "text"],
    "description" => ["textarea", "required", "", "text"],
    "customerId" => ["select", "required", $customersArr, "text"],
    "status" => ["select", "required", ["In-Progress"=>"In-Progress", "Completed"=>"Completed"], "text"],
);


//for generating table generation queries
if(false){
    $t = "DROP TABLE IF EXISTS ".$g_projectSlug."_".$primaryTableName." ; CREATE TABLE ".$g_projectSlug."_".$primaryTableName."(<br>id VARCHAR(200) PRIMARY KEY,<br>";
    foreach($arrayFields_crud as  $col => $info){
        $t.= "$col VARCHAR(256) DEFAULT '' ,<Br>";
    }
    $t.= "timeAdded VARCHAR(256) NULL,<br>userId VARCHAR(256) NULL);";
    echo "<code>$t</code>";
}

//for insert & update
if(isset($_POST['create_package'])){
    $timeAdded = time();
    $actionId = mb_htmlentities(($_POST['actionId']));
    $files_array = [];
	$queryExtra = '';
	foreach($arrayFields_crud as  $col => $info){
	    //for text
	    if(!in_array($info[3], ["image", "file"])){
    	    $val = mb_htmlentities($_POST[$col]);
    	    if($val!='' && $val!=NULL){
    	        $queryExtra.= ", $col='".$val."' ";
    	    }
	    }else{
	        //for images
	        if(isset($_FILES[$col])){
                $files_array[$col] = storeFile($_FILES[$col]); 
            }
	    }
	}
	
	

    $timeAdded = time();
    $id = generateRandomString();
    if($actionId==""){
        $actionId = $id;
        $query = "insert into ".$g_projectSlug."_".$primaryTableName." set id='$id' $queryExtra, timeAdded='$timeAdded', userId='$session_userId' ";
        $stmt = $con->prepare($query);
        if(!$stmt){echo "err: <code>$query</code>";}
        if(!$stmt->execute()){echo "err: <code>$query</code>";}
        
        
        /*send notification - @notf*/
        $new_message = 'A project has been added to your account';
        
    
    
    }else{
        //update
        $query = "update ".$g_projectSlug."_".$primaryTableName." set id='$actionId' $queryExtra where id='$actionId'";
        $stmt = $con->prepare($query);
        if(!$stmt){echo "err: <code>$query</code>";}
        if(!$stmt->execute()){echo "err: <code>$query</code>";}
        
        $new_message = 'A project has been updated on your account';
    }
    
    $notificationData = [
        'id' => generateRandomString(),
        'title' => $new_message,
        'desc' => $new_message,
        'redirectUrl' => $g_website.'/project_view.php?_projectId='.$projectId,
        'toUser' => $_POST['customerId'],
        'email' => $g_allUsersInfo[$_POST['customerId']]['email'],
    ];
    setNotification($con,$notificationData); // globalFunction 
    /*end of send notification - @notf*/
        
    //update files
    foreach($files_array as $col => $file){
        if($file!=""){
            $stmt = $con->prepare("update ".$g_projectSlug."_".$primaryTableName." set $col='$file' where id='$actionId'");
            if(!$stmt){echo "err: <code>$query</code>";}
            if(!$stmt->execute()){echo "err: <code>$query</code>";}
        }
    }

    if($g_redirectHomeOnSave){
        header("Location: ./home.php?m=Data was saved successfully!");
    }else{
        $rStr = "";
        if(isset($_GET['id'])){$rStr =  "&id=".$_GET['id'];}
        header("Location: ?m=Data was saved successfully!".$rStr);
    }
    
}

if(isset($_GET['delete-record'])){
    $id = mb_htmlentities($_GET['delete-record']);
    if($id!="admin"){
        $stmt = $con->prepare("delete from ".$g_projectSlug."_".$primaryTableName." where id=?");
        $stmt->bind_param("s", $id);
        if(!$stmt->execute()){echo "err";}
    }
}

if(checkGlobalPermission('g_enableBulkDelete')){
    if(isset($_POST['delete_bulk'])){
        $del  = "('".implode("', '", $_POST['delete_bulk'])."')";
        $sql="delete from ".$g_projectSlug."_".$primaryTableName." where id in $del";
        if(!mysqli_query($con,$sql))
        {
            echo"can not";
        }
    }

}


?>
<!DOCTYPE html>


<html lang="en">

	<!-- begin::Head -->
	<head><?require("./includes/views/head.php")?>
	<Style>
	    .kt-widget19 .kt-widget19__wrapper .kt-widget19__text {
            text-align: inherit;
	    }
	</Style>
</head>

	<!-- end::Head -->

	<!-- begin::Body -->
	<body class="<?echo $g_body_class?>">

		<?require("./includes/views/header.php")?>
        
        	<div class="kt-grid kt-grid--hor kt-grid--root">
			<div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--ver kt-page">
				<div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-wrapper" id="kt_wrapper">

					<!-- begin:: Header -->
					
                    <?require("./includes/views/topmenu.php")?>
					<!-- end:: Header -->

					<!-- begin:: Aside -->
					<?require("./includes/views/leftmenu.php")?>

					<!-- end:: Aside -->
					<div class="kt-body kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-grid--stretch" id="kt_body">
						<div class="kt-content  kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor" id="kt_content">

							<!-- end:: Subheader -->
    
    
							<!-- begin:: Content -->
							<div class="kt-container  kt-grid__item kt-grid__item--fluid">
							    
							    
							    <div class="kt-subheader   kt-grid__item" id="kt_subheader">
								<div class="kt-container ">
									<div class="kt-subheader__main">
										<h3 class="kt-subheader__title">
											Projects
										</h3>
									</div>
									<div class="kt-subheader__toolbar">
										<a href="./project_view.php?_projectId=<?echo $row['id']?>" class="">
										</a>
										<a data-toggle="modal" data-target="#create_record_modal" class="btn btn-label-brand btn-bold">
											Add Project </a>
											
										
									
									</div>
								</div>
							</div>
							
							    <?if(isset($_GET['m'])){?>
							        <div class="alert alert-info"><?echo $_GET['m']?></div>
							    <?}?>
                                
								<div>
									
									<div class="">
                                        <form action="" method="post">
                                            <?if(checkGlobalPermission('g_enableBulkDelete')){?>
                                                <button type="button" class="btn btn-info btn-sm text-white " onclick="selectAll();">Select All</button>
                                                <button type="submit"  class="btn btn-danger btn-sm text-white ">Delete Bulk</button>
                                            <?}?>
    										
    										<div class="row">
    										     <?
    											    
    											    $results = getAll($con, "select * from ".$g_projectSlug."_".$primaryTableName." where customerId like '%$session_userId_filter%' order by timeAdded desc");
    											    foreach($results as $row){
    											    $row['kanban_board_contents'] = "";
    											    ?>
        												
        												<div class="col-xl-4">
                        
                        										<!--begin:: Portlet-->
                        										<div class="kt-portlet kt-portlet--height-fluid">
                        											<div class="kt-portlet__body kt-portlet__body--fit">
                        
                        												<!--begin::Widget -->
                        												<div class="kt-widget kt-widget--project-1">
                        													<div class="kt-widget__head d-flex">
                        														<div class="kt-widget__label">
                        															<div class="kt-widget__media kt-widget__media--m">
                        																<span class="kt-media kt-media--md kt-media--circle kt-hidden-">
                        																	<img onerror="this.src='https://simg.nicepng.com/png/small/128-1280406_view-user-icon-png-user-circle-icon-png.png';" src="./uploads/<? echo ($row['cover_photo']) ?>" alt="image">
                        																</span>
                        																
                        															</div>
                        															<div class="kt-widget__info kt-padding-0 kt-margin-l-15">
                        																<a href="./project_view.php?_projectId=<?echo $row['id']?>" class="kt-widget__title">
                        																	<? echo ucfirst($row['title']) ?>
                        																</a>
                        																<span class="kt-widget__desc">
                        																	<? echo ($row['tagline']) ?>
                        																</span>
                        															</div>
                        														</div>
                        														<div class="kt-widget__toolbar">
                        														
                        														</div>
                        													</div>
                        													<div class="kt-widget__body">
                        														<span class="kt-widget__text kt-margin-t-0 kt-padding-t-5">
                        															<? echo ($row['description']) ?>
                        														</span>
                        														<div class="kt-widget__stats kt-margin-t-20">
                        														    <?if(($row['start_date'])!=""){?>
                        															<div class="kt-widget__item d-flex align-items-center kt-margin-r-30">
                        																<span class="kt-widget__date kt-padding-0 kt-margin-r-10">
                        																	Start
                        																</span>
                        																<div class="kt-widget__label">
                        																	<span class="btn btn-label-brand btn-sm btn-bold btn-upper"><? echo ($row['start_date']) ?></span>
                        																</div>
                        															</div>
                        															<?}?>
                        															<?if(($row['due_date'])!=""){?>
                        															<div class="kt-widget__item d-flex align-items-center kt-padding-l-0">
                        																<span class="kt-widget__date kt-padding-0 kt-margin-r-10 ">
                        																	Due
                        																</span>
                        																<div class="kt-widget__label">
                        																	<span class="btn btn-label-danger btn-sm btn-bold btn-upper"><? echo ($row['due_date']) ?></span>
                        																</div>
                        															</div>
                        															<?}?>
                        															
                        															<div class="btn-group">
                            										        			<a href="./project_view.php?_projectId=<?echo $row['id']?>" class="btn-sm btn btn-primary" >View</a>
                            										        			<a href="#" class="btn btn-warning btn-sm" data-toggle="modal" data-target="#create_record_modal" data-mydata='<?echo  (json_encode($row, true));?>' >Edit</a>
            													                        <a href="#" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#delete_record" data-url="?delete-record=<?echo $row['id']?>">Delete</a>
        													                        </div>
        													    
                        														</div>
                        													
                        													</div>
                        												
                        												</div>
                        
                        												<!--end::Widget -->
                        											</div>
                        										</div>
                        
                        										<!--end:: Portlet-->
                        									</div>
                        									
									
    												<?}?>
    												
    										</div>
                                        </form>
										<!--end: Datatable -->
									</div>
								</div>

							  
							</div>

							
							

							<!-- end:: Content -->
						</div>
					</div>

					<!-- begin:: Footer -->
					
					<?require("./includes/views/footer.php")?>

					<!-- end:: Footer -->
				</div>
			</div>
		</div>
        
        
        <?require("./includes/views/footerjs.php")?>
		

	</body>

	<!-- end::Body -->
	
	<div class="modal fade" id="create_record_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="modelTitle">Insert</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					</button>
				</div>
				<div class="modal-body">
					
					<form class="kt-form" action="" method="Post" enctype="multipart/form-data">
						<div class="kt-portlet__body">
						    
						    <?foreach($arrayFields_crud as $col => $info){?>
						    <div class="form-group">
						        <?if(strpos($info[1], "hidden")==false){?>
								    <label><?echo ucfirst(str_replace("_", " ", $col))?></label>
								    <?if($info[4]!=""){?>
								        <small><?echo $info[4]?></small>
								    <?}?>
								<?}?>
								<?if($info[0]=="input" && in_array($info[3], ["text", "email", "password", "number", "file", "date", "time", "color", "datetime"])){?>
								    <input type="<?echo $info[3]?>" name="<?echo $col?>" class="form-control" <?echo $info[1]?>  >
								<?}else if($info[0]=="select"){?>
								    <select name="<?echo $col?>" class="form-control" <?echo $info[1]?>  >
    								    <?foreach($info[2] as $i=> $option){?>
    								        <option value="<?echo $i?>"><?echo $option?></option>
    								    <?}?>
								    </select>
								<?}else if($info[0]=="input" && in_array($info[3], ["image"])){?>
								    <input type="file" name="<?echo $col?>" class="form-control" <?echo $info[1]?>  >
								<?}else if($info[0]=="textarea"){?>
								    <textarea type="text" name="<?echo $col?>" class="form-control" <?echo $info[1]?>  ></textarea>
								<?}else{?>
								    <code><?echo $col?> Couldn't render</code>
								<?}?>
							</div>
							<?}?>
						
							<input type="text" name="actionId" value="" hidden>
							
						</div>
						<div class="kt-portlet__foot">
							<div class="kt-form__actions">
								<input type="submit" name="create_package" value="Submit" class="btn btn-primary">
								<button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
							</div>
						</div>
					</form>
				</div>
			
			</div>
		</div>
	</div>
	
	
	<script>
	    $(document).ready(function(){
	    	

          $("#create_record_modal").on('show.bs.modal', function (e) {
            //get data-id attribute of the clicked element
            var mydata = $(e.relatedTarget).data('mydata');
            console.log(mydata);
            //console.log("mydata", mydata)
            if(mydata!= null){
            	$("#modelTitle").html("Update");
            	<?foreach($arrayFields_crud as $col => $info){
            	    if((strpos($info[1], "hidden")==false) && !in_array($info[3], ["file", "image"])){?>
                        $("<?echo $info[0]?>[name='<?echo $col?>']").val(mydata['<?echo $col?>'])
                <?}}?>
               
                $("input[name='actionId']").val(mydata['id'])


            }else{
            	$("#modelTitle").html("Insert");
                $("input[name='actionId']").val("")
                <?foreach($arrayFields_crud as $col => $info){
                    if((strpos($info[1], "hidden")==false) && !in_array($info[3], ["file", "image"])){?>
                    $("<?echo $info[0]?>[name='<?echo $col?>']").val("")
                <?}}?>

                $("input[name='actionId']").val("")
                
            }

            
          });
	    })
	</script>
				
		
								
</html>