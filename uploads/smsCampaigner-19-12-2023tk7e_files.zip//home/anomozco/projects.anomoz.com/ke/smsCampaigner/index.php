<?require("./global.php");

if(isset($_GET['logout'])){
    
    $_SESSION['email'] = "";
    $_SESSION['password'] = "";
    session_destroy();
    $logged=0;
    ?><script>window.location = "?";</script><?
}

header("Location: ./login.php");