<?require("./global.php");
?>
//to use
/*
<a class="btn btn-primary ml-2" target="_blank" href="./print.php?print_page=<?echo urlencode('https://projects.anomoz.com/ke/darlelJobber/quotes.php')?>">Print</a>
*/
<?
printPage(urldecode($_GET['print_page']));
?>