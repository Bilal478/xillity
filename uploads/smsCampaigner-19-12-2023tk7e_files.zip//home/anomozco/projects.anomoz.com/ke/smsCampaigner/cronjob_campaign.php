<?require("./global.php");


// 2021-11-19
// 00:31
// Friday
// YES
// $s_date = "2021-11-19";
// echo date("h:i");

//complex 1 email percampaign
$m = "";

// getAll($con,"DELETE from ".$g_projectSlug."_history;");

$getCampaignEmaisl=getAll($con,"SELECT u.name user_name, c.user_id user_id_creator, c.emailSend, c.callSend, c.smsSend, u.email, c.callSend, ce.title, ce.description, ce.days, u.id userId, ce.id campaignEmailId, c.camp_id campaignId, ce.order_number from ".$g_projectSlug."_campaignEmails ce
inner join ".$g_projectSlug."_campaign_users cu on ce.campaignId=cu.campaignId inner join ".$g_projectSlug."_users u on u.id=cu.userId 
inner join  ".$g_projectSlug."_campaigns c on c.camp_id=ce.campaignId");
foreach($getCampaignEmaisl as $row)
{ 
    //check last sent
    $campTitle = $row['title'];
    $user_name = $row['user_name'];
    $activateSending = true;
    $campaignEmailId = $row['campaignEmailId'];
    $campaignId = $row['campaignId'];
    $order_number = $row['order_number'];
    
    $smsSend = $row['smsSend'];
    $emailSend = $row['emailSend'];

    
    $userId = $row['userId'];
    $query = "select * from ".$g_projectSlug."_history where campaign_id='$campaignId' and lead_id='$userId' order by order_number desc limit 1";
    // echo $query."<br>";
    $histories=getAll($con,$query);
    foreach($histories as $history_row)
    {
        $lastSent = $history_row['created_at'];
        $order_number_history = $history_row['order_number'];
        
        if($history_row['order_number']>=$row['order_number']){
            $activateSending = false;
            echo "h1";
        }else{
            if(($row['order_number']-$history_row['order_number']) ==1 ){
                $activateSending = false;
                echo "h2";
                
                //check if time
                if( ($lastSent+($row['days']*86400)) < time()){
                    $activateSending = true;
                    echo "h3";
                }else{
                    $activateSending = false;
                    echo "h4";
                }
                
            }else{
                $activateSending = false;
                echo "h5";
            }
        }
     
        
    }
    
    // echo"--".($activateSending)."-ord: $order_number userId $userId campaignId $campaignId";
    // echo "<br>";
    if(true){
        if($activateSending){
            echo "activateSending";
            if($row['emailSend']=="Yes"  )
            {
                try{
                    //START::SEND EMAIL
                    $email = $row['email'];
                    sendEmailNotification_simple($row['title'],$row['description'],$row['email']);
                    
                    $campaign_id=$campId;
                    $lead_id=$row['mainUserId'];//leadid is userId
                    $created_at=time();
                    //END::SEND EMAIL
                    $m .= "Email sent to $email<br>";
                }catch(Exception $e){
                    var_dump($e);
                   $m .= "Email failed to send to $email<br>";
                }
            }
            
            if($row['smsSend']=="Yes" )
            {
                 $m .= "SMS sent to $email<br>";
                $data['id']=generateRandomString();
                $data['toUser']=$row['user_id_creator'];
                $data['title']="Send SMS To $user_name (Reminder)";
                $data['desc']="The time to send SMS to the users added to the Campaign ($campTitle) has been reached. Kindly send them the SMS. <br> Thank You ";
                $data['redirectUrl']="$g_website/campaignView.php?_camp=$campId";
                setNotification($con,$data);    
            }
            if($row['callSend']=="Yes" )
            {
                 $m .= "CALL sent to $email<br>";
                $data['id']=generateRandomString();
                $data['toUser']=$row['user_id_creator'];
                $data['title']="Call To $user_name (Reminder)";
                $data['desc']="The time to Call the users added to the Campaign ($campTitle) has been reached. Kindly call them . <br> Thank You ";
                $data['redirectUrl']="$g_website/campaignView.php?_camp=$campId";
                setNotification($con,$data);
            }
            
            $history_id=generateRandomString();
            $created_at = time();
            $query="insert into ".$g_projectSlug."_history set history_id='$history_id',campaign_id='$campaignId',lead_id='$userId',created_at='$created_at', campaignEmailId='$campaignEmailId', order_number='$order_number'";
            $result=$con->query($query);
            if(!$result)
                echo $con->error;
            // else
                // echo "inserted<br>";
        }
    }
    
}

var_dump($m) ;











echo $m;
echo "Cronjob Successful.";
exit();
?>