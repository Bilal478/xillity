<?require("./global.php");
   
   
if(isset($_POST['create_server'])){
    $email = mb_htmlentities(($_POST['email']));
   //  $password = mb_htmlentities(md5(md5(sha1( $_POST['password'])).'Anomoz')); 
    $password = mb_htmlentities(($_POST['password']));
    $port_no = mb_htmlentities(($_POST['port_no']));
    $ip_address = mb_htmlentities(($_POST['ip_address']));
	// $ip_address = $_SERVER['REMOTE_ADDR'];
    $actionId = mb_htmlentities(($_POST['actionId']));
    $id = generateRandomString();
    if($actionId==""){
        $stmt = $con->prepare("insert into ".$g_projectSlug."_email_servers (id, email, password, port_no, ip_address, userId) values (?,?,?,?,?,?)");
        $stmt->bind_param("ssssss", $id, $email, $password,$port_no,$ip_address, $session_userId);
        if(!$stmt->execute()){echo "err";}
    }else{
        $query="update ".$g_projectSlug."_email_servers set email='$email', password = '$password', port_no='$port_no', ip_address = '$ip_address' where id='$actionId'";
        $result=$con->query($query);
    }
    ?><script>location="email_servers.php"</script><?
}

if(isset($_GET['delete-record'])){
    $id = mb_htmlentities($_GET['delete-record']);
    $stmt = $con->prepare("delete from ".$g_projectSlug."_email_servers where id=?");
    $stmt->bind_param("s", $id);
    if(!$stmt->execute()){echo "err";}
}


// require("./getEmails.php");
   
   ?>
<!DOCTYPE html>
<html lang="en">
   <!-- begin::Head -->
   <head>
      <?require("./includes/views/head.php")?>
   </head>
   <!-- end::Head -->
   <body class="<?echo $g_body_class?>" onload="">
      <?require("./includes/views/header.php")?>
      <div class="kt-grid kt-grid--hor kt-grid--root">
         <div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--ver kt-page">
            <div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-wrapper" id="kt_wrapper">
               <!-- begin:: Header -->
               <?require("./includes/views/topmenu.php")?>
               <!-- end:: Header -->
               <!-- begin:: Aside -->
               <?require("./includes/views/leftmenu.php")?>
               <!-- end:: Aside -->
               <div class="kt-body kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-grid--stretch" id="kt_body">
                  <div class="kt-content  kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor" id="kt_content">
                     <div class="kt-container  kt-grid__item kt-grid__item--fluid">
                        <div class="kt-portlet kt-portlet--mobile">
                           <div class="kt-portlet__head kt-portlet__head--lg">
                              <div class="kt-portlet__head-label">
                                 <span class="kt-portlet__head-icon">
                                 </span>
                                 <h3 class="kt-portlet__head-title">
                                    Email Servers
                                 </h3>
                              </div>
                              <div class="kt-portlet__head-toolbar">
                                 <div class="kt-portlet__head-wrapper">
                                    <div class="kt-portlet__head-actions">
                                       <a href="#" class="btn btn-primary btn-elevate btn-icon-sm" data-toggle="modal" data-target="#create_record_modal">
                                       <i class="la la-plus"></i>
                                       New Record
                                       </a>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="kt-portlet__body">
                              <!--begin: Datatable -->
                              <table class="table table-striped- table-bordered table-hover table-checkable add-search" id="kt_table_1">
                                 <thead>
                                    <tr>
                                       <th>Email</th>
                                       <th>Password</th>
                                       <th>Port No.</th>
                                       <th>IP_Address</th>
                                       <th>Actions</th>
                                    </tr>
                                 </thead>
                                 <tbody>
                                    <?
                                       $query= "select * from ".$g_projectSlug."_email_servers where userId='$session_userId'";
                                       $result = $con->query($query);
                                       while($row = $result->fetch_assoc()) 
                                       { 
                                       if(true){
                                       ?>
                                    <tr>
                                       <td><?echo $row['email'];?></td>
                                       <td><?echo $row['password'];?></td>
                                       <td><?echo $row['port_no'];?></td>
                                       <td><?echo $row['ip_address'];?></td>
                                       <td>
                                          <a href="#" class="btn btn-warning" data-toggle="modal" data-target="#create_record_modal" data-mydata='<?echo  (json_encode($row, true));?>' >Edit</a>
                                          <a href="#" data-bs-target="#delete_record" class="btn btn-danger" data-toggle="modal" data-target="#delete_record" data-url="?delete-record=<?echo $row['id']?>">Delete</a>
                                       </td>
                                    </tr>
                                    <?}}?>
                                 </tbody>
                              </table>
                              <!--end: Datatable -->
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <script>
         var KTAppOptions = {
         	"colors": {
         		"state": {
         			"brand": "#591df1",
         			"light": "#ffffff",
         			"dark": "#282a3c",
         			"primary": "#5867dd",
         			"success": "#34bfa3",
         			"info": "#36a3f7",
         			"warning": "#ffb822",
         			"danger": "#fd3995"
         		},
         		"base": {
         			"label": ["#c5cbe3", "#a1a8c3", "#3d4465", "#3e4466"],
         			"shape": ["#f0f3ff", "#d9dffa", "#afb4d4", "#646c9a"]
         		}
         	}
         };
      </script>
      <?require("./includes/views/footerjs.php")?>

      <div class="modal fade" id="create_record_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
         <div class="modal-dialog" role="document">
            <div class="modal-content">
               <div class="modal-header">
                  <h5 class="modal-title" id="modelTitle">Add Email Servers</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  </button>
               </div>
               <div class="modal-body">
                  <form class="kt-form" action="" method="Post" enctype="multipart/form-data">
                     <div class="kt-portlet__body">
                        <div class="form-group">
                           <label>Email</label>
                           <input type="text" name="email" class="form-control" required  >
                        </div>
                        <div class="form-group">
                           <label>Password</label>
                           <input type="text" name="password" class="form-control" required  >
                        </div>
                        <div class="form-group">
                           <label>Port No.</label>
                           <input type="number" min="1" name="port_no" class="form-control" required  >
                        </div>
                        <div class="form-group">
                           <label>IP Address</label>
                           <input type="text" name="ip_address" class="form-control" required  >
                        </div>
                        <input type="text" name="actionId" value="" hidden>
                     </div>
                     <div class="kt-portlet__foot">
                        <div class="kt-form__actions">
                           <input type="submit" name="create_server" value="Submit" class="btn btn-primary">
                           <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                        </div>
                     </div>
                  </form>
               </div>
            </div>
         </div>
      </div>
   </body>
   <!-- end::Body -->

<script>
   $(document).ready(function(){
        $("#create_record_modal").on('show.bs.modal', function (e) {
          //get data-id attribute of the clicked element
          var mydata = $(e.relatedTarget).data('mydata');
          console.log(mydata);
          //console.log("mydata", mydata)
          if(mydata!= null){
          	$("#modelTitle").html("Update");
              $("input[name='email']").val(mydata['email'])
              $("input[name='password']").val(mydata['password'])
              $("input[name='port_no']").val(mydata['port_no'])
              $("input[name='ip_address']").val(mydata['ip_address'])
             $("input[name='actionId']").val(mydata['id'])
          }else{
              $("#modelTitle").html("Insert");
              $("input[name='email']").val("")
              $("input[name='port_no']").val("")
              $("input[name='ip_address']").val("")
              $("input[name='password']").val("")
              $("input[name='actionId']").val("")
		  }
        });
   })
   
</script>

</html>