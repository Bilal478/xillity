<?php require("./global.php");

/** PHP CODE **/

?>
<!DOCTYPE html>


<html lang="en">

<!-- begin::Head -->

<head><?php require("./includes/views/head.php") ?>
</head>

<!-- end::Head -->

<!-- begin::Body -->

<body class="<?php echo $g_body_class ?>">

    <?php require("./includes/views/header.php") ?>

    <div class="kt-grid kt-grid--hor kt-grid--root">
        <div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--ver kt-page">
            <div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-wrapper" id="kt_wrapper">

                <!-- begin:: Header -->

                <?php require("./includes/views/topmenu.php") ?>
                <!-- end:: Header -->

                <!-- begin:: Aside -->
                <?php require("./includes/views/leftmenu.php") ?>

                <!-- end:: Aside -->
                <div class="kt-body kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-grid--stretch" id="kt_body">
                    <div class="kt-content  kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor" id="kt_content">

                        <!-- end:: Subheader -->

                        <!-- begin:: Content -->
                        <div class="kt-container  kt-grid__item kt-grid__item--fluid">

                            <?php if (isset($_GET['m'])) { ?>
                                <div class="alert alert-info"><?php echo $_GET['m'] ?></div>
                            <?php } ?>

                            <div class="kt-portlet kt-portlet--mobile">
                                <div class="kt-portlet__head kt-portlet__head--lg">
                                    <div class="kt-portlet__head-label">
                                        <span class="kt-portlet__head-icon">
                                        </span>
                                        <h3 class="kt-portlet__head-title">
                                            <?php echo ucfirst(str_replace("_", " ", $primaryTableName)); ?>
                                        </h3>
                                    </div>
                                    <div class="kt-portlet__head-toolbar">




                                        <ul class="nav nav-pills nav-pills-sm nav-pills-label nav-pills-bold bg-white p-3" role="tablist">

                                            <li class="nav-item">
                                                <a class="nav-link active" data-toggle="tab" href="#kt_widget6_clinical_content" role="tab">
                                                    Clinical
                                                </a>
                                            </li>
                                            <li class="nav-item">
                                                <a class="nav-link" data-toggle="tab" href="#kt_widget6_mental_content" role="tab">
                                                    Mental
                                                </a>
                                            </li>
                                            <li class="nav-item">
                                                <a class="nav-link" data-toggle="tab" href="#kt_widget6_general_wellness" role="tab">
                                                    General Wellness
                                                </a>
                                            </li>

                                        </ul>

                                        

                                    </div>
                                </div>
                                <div class="kt-portlet__body">
                                    <form action="" method="post">
                                        <?php if (checkGlobalPermission('g_enableBulkDelete')) { ?>
                                            <button type="button" class="btn btn-info btn-sm text-white " onclick="selectAll();">Select All</button>
                                            <button type="submit" class="btn btn-danger btn-sm text-white ">Delete Bulk</button>
                                        <?php } ?>

                                        <!-- TABLE HTML CODE-->

                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php require("./includes/views/footer.php") ?>
            </div>
        </div>
    </div>
    <?php require("./includes/views/footerjs.php") ?>
</body>

<!-- end::Body -->

<div class="modal fade" id="create_record_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modelTitle">Insert</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                </button>
            </div>
            <div class="modal-body">

                <form class="kt-form" action="" method="Post" enctype="multipart/form-data">
                    <div class="kt-portlet__body">

                        <!-- MODAL FIELD CODE-->

                    </div>
                    <div class="kt-portlet__foot">
                        <div class="kt-form__actions">
                            <input type="submit" name="create_package" value="Submit" class="btn btn-primary">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<!-- MODAL EDIT SCRIPT CODE-->



</html>