<?php  require("./global.php");

/** PHP CODE **/
$primaryTableName = "planes";

    array(
        // field_name [type, isrequired, array_select, inner_type] <= "template"
        "name" => ["input", "", "", "text"],
       "flight" => ["input", "", "", "text"],
"capacity" => ["input", "", "", "text"],
"milage" => ["input", "", "", "text"]
    );

;
    

if(isset($_POST['create_package'])){
    $actionId = escape(($_POST['actionId']));
    $name = escape($_POST['name']);    
    $flight = escape($_POST['flight']);    
    $capacity = escape($_POST['capacity']);    
    $milage = escape($_POST['milage']);    
    if($actionId==""){
        $id = generateRandomString();
        $actionId = $id;
        $query = "insert into smsCampaigner_planes set id='$id' , name='$name', flight='$flight', capacity='$capacity', milage='$milage', timeAdded='$timeAdded', userId='$session_userId' ";
    }else{
        $query = "update smsCampaigner_planes set id='$actionId' , name='$name', flight='$flight', capacity='$capacity', milage='$milage' where id='$actionId'";
    }
    runQuery($query);

    header("Location: ?".generateUrlParams_return(["m"=>"Data was saved successfully!","type"=>"success"]));exit();
}
    
if(isset($_GET['delete-record'])){
    $id = escape($_GET['delete-record']);
    $query = "delete from smsCampaigner_planes where id='$id'";
    runQuery($query);
}

?>
<!DOCTYPE html>


<html lang="en">

    <!-- begin::Head -->
    <head><?php require("./includes/views/head.php")?>
</head>

    <!-- end::Head -->

    <!-- begin::Body -->
    <body class="<?php echo $g_body_class?>">

        <?php require("./includes/views/header.php")?>
        
            <div class="kt-grid kt-grid--hor kt-grid--root">
            <div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--ver kt-page">
                <div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-wrapper" id="kt_wrapper">

                    <!-- begin:: Header -->
                    
                    <?php require("./includes/views/topmenu.php")?>
                    <!-- end:: Header -->

                    <!-- begin:: Aside -->
                    <?php require("./includes/views/leftmenu.php")?>

                    <!-- end:: Aside -->
                    <div class="kt-body kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-grid--stretch" id="kt_body">
                        <div class="kt-content  kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor" id="kt_content">

                            <!-- end:: Subheader -->

                            <!-- begin:: Content -->
                            <div class="kt-container  kt-grid__item kt-grid__item--fluid">
                                
                                <?php if(isset($_GET['m'])){?>
                                    <div class="alert alert-info"><?php echo $_GET['m']?></div>
                                <?php }?>

                                <div class="kt-portlet kt-portlet--mobile">
                                    <div class="kt-portlet__head kt-portlet__head--lg">
                                        <div class="kt-portlet__head-label">
                                            <span class="kt-portlet__head-icon">
                                            </span>
                                            <h3 class="kt-portlet__head-title">
                                                <?php echo ucfirst(str_replace("_", " ", $primaryTableName));?>
                                            </h3>
                                        </div>
                                        <div class="kt-portlet__head-toolbar">
                                            <div class="kt-portlet__head-wrapper">
                                                <div class="kt-portlet__head-actions">
                                                    
                                                    <?php renderImportExportButtons($primaryTableName);?>
                                                    
                                                    <a href="#" class="btn btn-brand btn-elevate btn-icon-sm" data-toggle="modal" data-target="#create_record_modal">
                                                        <i class="la la-plus"></i>
                                                        New Record
                                                    </a>
                                                            
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="kt-portlet__body">
                                        <form action="" method="post">
                                            <?php if(checkGlobalPermission('g_enableBulkDelete')){?>
                                                <button type="button" class="btn btn-info btn-sm text-white " onclick="selectAll();">Select All</button>
                                                <button type="submit"  class="btn btn-danger btn-sm text-white ">Delete Bulk</button>
                                            <?php }?>

                                            <!-- TABLE HTML CODE-->
                                            
<table class="table table-striped- table-bordered table-hover table-checkable add-search" >
    <thead>
        <tr>
            <th>Name</th>
            <th>Flight</th>
            <th>Capacity</th>
            <th>Milage</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
    <?php  $query = "select * from smsCampaigner_planes t order by t.timeAdded desc";
    $results = getAll($con, $query);
        foreach($results as $row){?>
            <tr>
                <td><?php echo $row['name']?></td>
                <td><?php echo $row['flight']?></td>
                <td><?php echo $row['capacity']?></td>
                <td><?php echo $row['milage']?></td>
                <td >
                        <div class="btn-group">
                            <a href="#" class="btn btn-warning" data-toggle="modal" data-target="#create_record_modal" data-mydata='<?php echo  htmlspecialchars(json_encode($row, JSON_UNESCAPED_UNICODE));?>' >Edit</a>
                            <a href="#" class="btn btn-danger" data-toggle="modal" data-target="#delete_record" data-url="?<?echo generateUrlParams()?>delete-record=<?php echo $row['id']?>">Delete</a>
                        </div>
                </td>
            </tr>
        <?php }?>
    </tbody>
</table>


                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php require("./includes/views/footer.php")?>
                </div>
            </div>
        </div>
        <?php require("./includes/views/footerjs.php")?>
    </body>

    <!-- end::Body -->
    
    <div class="modal fade" id="create_record_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modelTitle">Insert</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    </button>
                </div>
                <div class="modal-body">
                    
                    <form class="kt-form" action="" method="Post" enctype="multipart/form-data">
                        <div class="kt-portlet__body">
                            
                            <!-- MODAL FIELD CODE-->
                            <!-- modal -->

<div>
<div class="form-group">
    <label>Name</label>
    <input type="text" name="name" class="form-control"   >
</div>
	
<div class="form-group">
    <label>Flight</label>
    <input type="text" name="flight" class="form-control"   >
</div>
	
<div class="form-group">
    <label>Capacity</label>
    <input type="text" name="capacity" class="form-control"   >
</div>
	
<div class="form-group">
    <label>Milage</label>
    <input type="text" name="milage" class="form-control"   >
</div>
	
<input type="text" name="actionId" value="" hidden>

</div>
                            
                        </div>
                        <div class="kt-portlet__foot">
                            <div class="kt-form__actions">
                                <input type="submit" name="create_package" value="Submit" class="btn btn-primary">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    
    <!-- MODAL EDIT SCRIPT CODE-->
                <script>$(document).ready(function(){
	      

          $("#create_record_modal").on('show.bs.modal', function (e) {
            var mydata = $(e.relatedTarget).data('mydata');
            console.log("mydata->",mydata);
            $("input[type='checkbox']").prop('checked', false);
            if(mydata!= null){
            	$("#modelTitle").html("Update");            	
                $("input[name='name']").val(mydata['name'])                
                $("input[name='flight']").val(mydata['flight'])                
                $("input[name='capacity']").val(mydata['capacity'])                
                $("input[name='milage']").val(mydata['milage'])                                
                $("input[name='actionId']").val(mydata['id'])
            }else{
                $("#modelTitle").html("Insert");
                $("input[name='name']").val("")
                $("input[name='flight']").val("")
                $("input[name='capacity']").val("")
                $("input[name='milage']").val("")
            
                $("input[name='actionId']").val("")
            }
        });
    })
</script>
        
                                
</html> 