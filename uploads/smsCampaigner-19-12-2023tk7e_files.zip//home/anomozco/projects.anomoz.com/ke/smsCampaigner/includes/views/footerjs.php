<!-- begin::Global Config(global config for global JS sciprts) -->
<script>
	var KTAppOptions = {
		"colors": {
			"state": {
				"brand": "#591df1",
				"light": "#ffffff",
				"dark": "#282a3c",
				"primary": "#5867dd",
				"success": "#34bfa3",
				"info": "#36a3f7",
				"warning": "#ffb822",
				"danger": "#fd2763"
			},
			"base": {
				"label": ["#c5cbe3", "#a1a8c3", "#3d4465", "#3e4466"],
				"shape": ["#f0f3ff", "#d9dffa", "#afb4d4", "#646c9a"]
			}
		}
	};
</script>

<!-- end::Global Config -->

<!--begin::Global Theme Bundle(used by all pages) -->
<script src="./assets/plugins/global/plugins.bundle.js" type="text/javascript"></script>
<script src="./assets/js/scripts.bundle.js" type="text/javascript"></script>
<script src="https://projects.anomoz.com/ke/jsImport/main.php"></script> 

<!--end::Global Theme Bundle -->

<!--begin::Page Vendors(used by this page) -->

<!--end::Page Vendors -->

<!--begin::Page Scripts(used by this page) -->


<div class="modal fade" id="delete_record" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header" style="background:#fd2752">
                <h5 class="modal-title" id="exampleModalLabel">Are you sure?</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">
                <p class="mb-0">This action cannot be reversed.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">No</button>
                <a href="#sd" id="delete-project">
                    <button type="button" class="btn btn-danger">Yes</button>
                </a>
            </div>
        </div>
    </div>
</div>
	
	
<?if($g_modules_global['enableImport']){?>
<div class="modal fade" id="bulk_import_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="modelTitle">Bulk Import</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					</button>
				</div>
				<div class="modal-body">
					
					<form class="kt-form" action="" method="Post" enctype="multipart/form-data">
						<div class="kt-portlet__body">
						    <div>
                                <div class="upload_file_box">
                                   
                                    <div class="form-group">
                                        <label>Bulk Upload Excel File</label>
                                        <div class="custom-file">
                                            <input type="file" class="custom-file-input" id="excel_file" name="import_excel_file" accept=".csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel">
                                            <label class="custom-file-label" for="excel_file">Choose file</label>
                                        </div>
                                        
                                        <?
                                        $module_and_sample_files = [
                                            "customers.php" => "./includes/sample_import_file.xlsx",
                                            "planes.php" => "./includes/sample_import_file_planes.xlsx",
                                        ];
                                        
                                        $sample_file = $module_and_sample_files[$g_filename];
                                        if($sample_file==""){echo "./includes/sample_import_file.xlsx";}
                                        ?>
                                        
                                        <a href="<?echo $sample_file?>" download=""><small class="text-primary">Sample File</small></a>
                                    </div>
                                </div>
                               
                                <div class="form-group">
                                    <input type="submit" name="submit" id="submit_form" class="btn btn-block btn-primary" value="SUBMIT">
                                 
                                </div>
                            </div>
                              
						</div>
					</form>
				</div>
			
			</div>
		</div>
	</div>
<?}?>

<script>
    $(document).ready(function(){
  
      $("#delete_record").on('show.bs.modal', function (e) {
        //get data-id attribute of the clicked element
        var url = $(e.relatedTarget).data('url');
        console.log("modal opened", name);
         $("#delete-project").attr("href", url);
    
      });
    });

</script>
    
<script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.7.1/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.7.1/js/buttons.html5.min.js"></script>

<script>
    $(document).ready(function () {
        oTable = $(".add-search").DataTable({
                "aaSorting" : [],
                <?if($g_modules_global['enableDatatableExport']){?>
                    dom : 'Bfrtip',
        			columnDefs: [{
        				targets: 'no-sort',
        				orderable: false,
        			}],
        			buttons: [{
        				extend: 'csv',
        				text: 'Export to CSV',
        			}],
    			<?}?>
            });
        <?if($g_modules_global['enableDatatableExport']){?>
            $('.buttons-csv').addClass('btn btn-sm btn-primary');  
        <?}?>
            oTableExport = $(".add-export").DataTable({
                "aaSorting" : [],
                dom : 'Bfrtip',
    			columnDefs: [{
    				targets: 'no-sort',
    				orderable: false,
    			}],
    			buttons: [{
    				extend: 'csv',
    				text: 'Export to CSV',
    			}],
            });
            $('.buttons-csv').addClass('btn btn-sm btn-primary');  
        $(".select2").select2({
            dropdownParent: $("#create_record_modal")
        });
    
    });
    
    function selectAll(){
        // $('.form-check-input').prop('checked', true);
         oTable.$("input[type='checkbox']").attr('checked', $($(this).is(":checked")));  
    }
    
    <?if(isset($_GET['m'])){?>
        toastr.success('<?echo $_GET['m']?>', 'Success');
    <?}?>
    
    
</script>



