<? require("./global.php");
$primaryTableName = "order_items";
$primaryTablepayment = "order_payments";
$ids = $_GET["id"];

if ($ids == "") {
    header("./orders.php");
}

array(
    // field_name [type, isrequired, array_select, inner_type] <= "template"

    "title" => ["input", "", "", "text"],
    "description" => ["input", "", "", "text"],
    "order_id" => ["input", "", "", "text"],

    //payments
    "order_id" => ["input", "", "", "text"],
    "payment_amount" => ["input", "", "", "text"],
    "payment_status" => ["input", "", "", "text"],
    // "document" => ["input", "", "", "file"],
);




if (isset($_POST['create_package'])) {
    $timeAdded = time();
    $actionId = mb_htmlentities(($_POST['actionId']));
    $title = mb_htmlentities($_POST['title']);
    $description = mb_htmlentities($_POST['description']);
    $order_id = $ids;
    if ($actionId == "") {
        $id = generateRandomString();
        $actionId = $id;
        $query = "insert into ".$g_projectSlug."_order_items set id='$id' , title='$title', description='$description', order_id='$order_id', timeAdded='$timeAdded', userId='$session_userId' ";
    } else {
        $query = "update ".$g_projectSlug."_order_items set id='$actionId' , title='$title', description='$description', order_id='$order_id' where id='$actionId'";
    }
    $stmt = $con->prepare($query);
    if (!$stmt) {
        echo "err: <code>$query</code>";
    }
    if (!$stmt->execute()) {
        echo "err: <code>$query</code>";
    }

    $rStr = "";
    if (isset($_GET['id'])) {
        $rStr .=  "&id=" . $_GET['id'];
    }
    header("Location: ?m=Data was saved successfully!" . $rStr );
}

if (isset($_GET['delete-record'])) {
    $id = mb_htmlentities($_GET['delete-record']);
    if ($id != "admin") {
        $stmt = $con->prepare("delete from ".$g_projectSlug."_order_items where id=?");
        $stmt->bind_param("s", $id);
        if (!$stmt->execute()) {
            echo "err";
        }
    }
}






if (isset($_POST['create_payments'])) {
    $timeAdded = time();
    $actionId = mb_htmlentities(($_POST['actionId']));
    $order_id = $ids;
    $payment_amount = mb_htmlentities($_POST['payment_amount']);
    $payment_status = mb_htmlentities($_POST['payment_status']);
    if ($actionId == "") {
        $id = generateRandomString();
        $actionId = $id;
        $query = "insert into ".$g_projectSlug."_order_payments set id='$id' , order_id='$order_id', payment_amount='$payment_amount', payment_status='$payment_status', timeAdded='$timeAdded', userId='$session_userId' ";
    } else {
        $query = "update ".$g_projectSlug."_order_payments set id='$actionId' , order_id='$order_id', payment_amount='$payment_amount', payment_status='$payment_status' where id='$actionId'";
    }
    $stmt = $con->prepare($query);
    if (!$stmt) {
        echo "err: <code>$query</code>";
    }
    if (!$stmt->execute()) {
        echo "err: <code>$query</code>";
    }

    $rStr = "";
    if (isset($_GET['id'])) {
        $rStr .=  "&id=" . $_GET['id'];
    }
    header("Location: ?m=Data was saved successfully!" . $rStr );
}

if (isset($_GET['delete-payment'])) {
    $id = mb_htmlentities($_GET['delete-payment']);
    if ($id != "admin") {
        $stmt = $con->prepare("delete from ".$g_projectSlug."_order_payments where id=?");
        $stmt->bind_param("s", $id);
        if (!$stmt->execute()) {
            echo "err";
        }
    }
}




?>

<!DOCTYPE html>


<html lang="en">

<!-- begin::Head -->

<head><? require("./includes/views/head.php") ?>
</head>

<!-- end::Head -->

<!-- begin::Body -->

<body class="<? echo $g_body_class ?>">

    <? require("./includes/views/header.php") ?>

    <div class="kt-grid kt-grid--hor kt-grid--root">
        <div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--ver kt-page">
            <div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-wrapper" id="kt_wrapper">

                <!-- begin:: Header -->

                <? require("./includes/views/topmenu.php") ?>
                <!-- end:: Header -->

                <!-- begin:: Aside -->
                <? require("./includes/views/leftmenu.php") ?>

                <!-- end:: Aside -->
                <div class="kt-body kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-grid--stretch" id="kt_body">
                    <div class="kt-content  kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor" id="kt_content">

                        <!-- end:: Subheader -->

                        <!-- begin:: Content -->
                        <div class="kt-container  kt-grid__item kt-grid__item--fluid">

                            
                            <? if (isset($_GET['m'])) { ?>
                                <div class="alert alert-info"><? echo $_GET['m'] ?></div>
                            <? } ?>
                            
                            <div class="kt-portlet ">
                                
                                <?$query = "SELECT * , o.description description_project
                                FROM ".$g_projectSlug."_orders o
                                INNER JOIN ".$g_projectSlug."_users
                                ON o.client_id = ".$g_projectSlug."_users.id WHERE o.id = '$ids'";
                                $orderRow = getRow($con, $query);
                                
                                ?>
									<div class="kt-portlet__body">
										<div class="kt-widget kt-widget--user-profile-3">
											<div class="kt-widget__top">
												
												<div class="kt-widget__pic kt-widget__pic--danger kt-font-danger kt-font-boldest kt-font-light">
													<?echo strtoupper(substr($orderRow['title'], 0, 2));?>
												</div>
												<div class="kt-widget__content">
													<div class="kt-widget__head">
														<a href="#" class="kt-widget__username kt-hidden">
															<?echo $orderRow['title'];?>
															<i class="flaticon2-correct"></i>
														</a>
														<a href="#" class="kt-widget__title"><? echo $orderRow['title'];?></a>
														<div class="kt-widget__action">
														    <?if(checkGlobalPermission('enableMessages')){?>
															    <!--<a href="./messages.php?u=<?echo $orderRow['userId'];?>" class="btn btn-sm btn-success btn-primary ">Message</a>-->
															<?}?>
															<?if($orderRow['email']!=""){?>
															<a href="mailto:<?echo $orderRow['email']?>" class="btn btn-brand btn-sm btn-upper">E-mail</a>
															<?}?>
														</div>
													</div>
													<!--<div class="kt-widget__subhead ">-->
													<!--	<a href="#"><i class="flaticon2-new-email"></i><?echo $orderRow['email']?></a>-->
													<!--	<a href="#"><i class="flaticon2-phone"></i><?echo $orderRow['phone']?></a>-->
													<!--	<a href="#"><i class="flaticon2-placeholder"></i><?echo $orderRow['address']?></a>-->
													<!--</div>-->
													<div class="kt-widget__info">
													    
													    <? echo $orderRow['description_project'];?>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
						
                            
                            <div class="kt-portlet kt-portlet--mobile">
                                <div class="kt-portlet__head kt-portlet__head--lg">
                                    <div class="kt-portlet__head-label">
                                        <span class="kt-portlet__head-icon">
                                        </span>
                                        <h3 class="kt-portlet__head-title">
                                            <? echo ucfirst(str_replace("_", " ", $primaryTableName)); ?>
                                        </h3>
                                    </div>
                                    <div class="kt-portlet__head-toolbar">
                                        <div class="kt-portlet__head-wrapper">
                                            <div class="kt-portlet__head-actions">

                                                <? renderImportExportButtons($primaryTableName); ?>

                                                <a href="#" class="btn btn-brand btn-elevate btn-icon-sm" data-toggle="modal" data-target="#create_record_modal">
                                                    <i class="la la-plus"></i>
                                                    ADD ITEM
                                                </a>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="kt-portlet__body">
                                    <form action="" method="post">
                                        <? if (checkGlobalPermission('g_enableBulkDelete')) { ?>
                                            <button type="button" class="btn btn-info btn-sm text-white " onclick="selectAll();">Select All</button>
                                            <button type="submit" class="btn btn-danger btn-sm text-white ">Delete Bulk</button>
                                        <? } ?>


                                        <table class="table table-striped- table-bordered table-hover table-checkable add-search">
                                            <thead>
                                                <tr>
                                                    <th>Title</th>
                                                    <th>Description</th>
                                                    <th>Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $query = "select * from ".$g_projectSlug."_order_items t where  t.order_id='$ids' order by t.timeAdded desc";
                                                $results = getAll($con, $query);
                                                foreach ($results as $row) { ?>
                                                    <tr>
                                                        <td><?php echo $row['title'] ?></td>
                                                        <td><?php echo $row['description'] ?></td>
                                                        <td>
                                                            <div class="btn-group">
                                                                <a href="#" class="btn btn-warning" data-toggle="modal" data-target="#create_record_modal" data-mydata='<?php echo  htmlspecialchars(json_encode($row, JSON_UNESCAPED_SINGLEQUOTES | JSON_UNESCAPED_UNICODE)); ?>'>Edit</a>
                                                                <a href="#" class="btn btn-danger" data-toggle="modal" data-target="#delete_record" data-url="?<?php if (isset($_GET['id'])) {
                                                                                                                                                                    echo "id=" . $_GET['id'] . "&";
                                                                                                                                                                } ?>delete-record=<?php echo $row['id']  ?>">Delete</a>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                <?php } ?>
                                            </tbody>
                                        </table>





                                    </form>
                                </div>
                            </div>
                                
                                
                            <div class="kt-portlet kt-portlet--mobile">
                                <div class="kt-portlet__head kt-portlet__head--lg">
                                    <div class="kt-portlet__head-label">
                                        <span class="kt-portlet__head-icon">
                                        </span>
                                        <h3 class="kt-portlet__head-title">
                                            <? echo ucfirst(str_replace("_", " ", $primaryTablepayment)); ?>
                                        </h3>
                                    </div>
                                    <div class="kt-portlet__head-toolbar">
                                        <div class="kt-portlet__head-wrapper">
                                            <div class="kt-portlet__head-actions">

                                                <? renderImportExportButtons($primaryTablepayment); ?>

                                                <a href="#" class="btn btn-brand btn-elevate btn-icon-sm" data-toggle="modal" data-target="#create_payment_modal">
                                                    <i class="la la-plus"></i>
                                                    ADD PAYMENT
                                                </a>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="kt-portlet__body">
                                    <form action="" method="post">
                                        <? if (checkGlobalPermission('g_enableBulkDelete')) { ?>
                                            <button type="button" class="btn btn-info btn-sm text-white " onclick="selectAll();">Select All</button>
                                            <button type="submit" class="btn btn-danger btn-sm text-white ">Delete Bulk</button>
                                        <? } ?>





                                        <table class="table table-striped- table-bordered table-hover table-checkable add-search">
                                            <thead>
                                                <tr>
                                                    <th>Item Name</th>
                                                    <th>Payment status</th>
                                                    <th>Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php 
                                                $query = "select * from ".$g_projectSlug."_order_payments t where  t.order_id='$ids' order by t.timeAdded desc";
                                                $results = getAll($con, $query);
                                                foreach ($results as $row) { ?>
                                                    <tr>
                                                        <td><?php echo $row['payment_amount'] ?></td>
                                                        <td><?php echo $row['payment_status'] ?></td>
                                                        <td>
                                                            <div class="btn-group">
                                                                <a href="#" class="btn btn-warning" data-toggle="modal" data-target="#create_payment_modal" data-mydata='<?php echo  htmlspecialchars(json_encode($row, JSON_UNESCAPED_SINGLEQUOTES | JSON_UNESCAPED_UNICODE)); ?>'>Edit</a>
                                                                <a href="#" class="btn btn-danger" data-toggle="modal" data-target="#delete_record" data-url="?<?php if (isset($_GET['id'])) {
                                                                                                                                                                    echo "id=" . $_GET['id'] . "&";
                                                                                                                                                                } ?>delete-payment=<?php echo $row['id']  ?>">Delete</a>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                <?php } ?>
                                            </tbody>
                                        </table>




                                    </form>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>



    <? require("./includes/views/footerjs.php") ?>
</body>

<!-- end::Body -->



<div class="modal fade" id="create_record_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modelTitle">Insert</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                </button>
            </div>
            <div class="modal-body">

                <form class="kt-form" action="" method="Post" enctype="multipart/form-data">
                    <div class="kt-portlet__body">

                        <!-- modal -->



                        <div>
                            <div class="form-group">
                                <label>Title</label>
                                <input type="text" name="title" class="form-control">
                            </div>

                            <div class="form-group">
                                <label>Description</label>
                                <textarea name="description" id="" cols="30" rows="5" class="form-control"></textarea>
                            </div>

                            <input type="text" name="actionId" value="" hidden>

                        </div>

                        <div class="kt-portlet__foot">
                            <div class="kt-form__actions">
                                <input type="submit" name="create_package" value="Submit" class="btn btn-primary">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                            </div>
                        </div>
                </form>
            </div>
        </div>
    </div>
</div>
</div>

<div class="modal fade" id="create_payment_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modelTitle">Insert</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                </button>
            </div>
            <div class="modal-body">

                <form class="kt-form" action="" method="Post" enctype="multipart/form-data">
                    <div class="kt-portlet__body">

                        <!-- modal -->

                        <!-- modal -->

                        <div>

                            <div class="form-group">


                                <div class="form-group">
                                    <label>Payment Amount</label>
                                    <input type="text" name="payment_amount" class="form-control">
                                </div>



                                <label>Payment Status</label>
                                <select class="form-control" name="payment_status">
                                    <option value="paid">Paid</option>
                                    <option value="unpaid">UnPaid</option>
                                </select>
                            </div>



                            <input type="text" name="actionId" value="" hidden>

                        </div>
                        <div class="kt-portlet__foot">
                            <div class="kt-form__actions">
                                <input type="submit" name="create_payments" value="Submit" class="btn btn-primary">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                            </div>
                        </div>
                </form>
            </div>
        </div>
    </div>
</div>
</div>



<script>
    $(document).ready(function() {


        $("#create_record_modal").on('show.bs.modal', function(e) {
            var mydata = $(e.relatedTarget).data('mydata');
            console.log("mydata->", mydata);
            $("input[type='checkbox']").prop('checked', false);
            if (mydata != null) {
                $("#modelTitle").html("Update");
                $("input[name='title']").val(mydata['title'])
                $("input[name='description']").val(mydata['description'])
                $("input[name='order_id']").val(mydata['order_id'])
                $("input[name='actionId']").val(mydata['id'])
            } else {
                $("#modelTitle").html("Insert");
                $("input[name='title']").val("")
                $("input[name='description']").val("")
                $("input[name='order_id']").val("")

                $("input[name='actionId']").val("")
            }
        });
    });

    $(document).ready(function() {
        $("#create_payment_modal").on('show.bs.modal', function(e) {
            var mydata = $(e.relatedTarget).data('mydata');
            console.log("mydata->", mydata);
            $("input[type='checkbox']").prop('checked', false);
            if (mydata != null) {
                $("#modelTitle").html("Update");
                $("input[name='order_id']").val(mydata['order_id'])
                $("input[name='payment_amount']").val(mydata['payment_amount'])
                $("input[name='payment_status']").val(mydata['payment_status'])
                $("input[name='actionId']").val(mydata['id'])
            } else {
                $("#modelTitle").html("Insert");
                $("input[name='order_id']").val("")
                $("input[name='payment_amount']").val("")
                $("input[name='payment_status']").val("")

                $("input[name='actionId']").val("")
            }
        });
    })
</script>



</html>


<!-- Task -->