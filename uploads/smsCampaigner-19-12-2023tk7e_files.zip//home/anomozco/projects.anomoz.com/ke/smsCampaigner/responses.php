<?  
require("./global.php");
$idToQuestions=array();
$result=getAll($con,"select * from ".$g_projectSlug."_questionnaires_questions");
foreach($result as $row)
{
    $idToQuestions[$row['id']]=$row['question'];    
}


$formId=$_GET['formId'];
$subId=$_GET['subId'];

$query = "select * from ".$g_projectSlug."_data_entries where formId='$formId' order by timeAdded DESC";
$allSubmissions=getAll($con,$query);
$submissionsData=array();
// $index=0;
foreach($allSubmissions as $row)
{
    $index = $row['full_submission_id'];
    $submissionsData[$index]['submissionId']=$row['submissionId'];
	$submissionsData[$index]['is_trash']=$row['is_trash'];
	$submissionsData[$index]['timeAdded']=$row['timeAdded'];
    $submissionsData[$index]['full_submission_id']=$row['full_submission_id'];
    $submissionsData[$index]['formId']=$row['formId'];
    $submissionsData[$index]['questions'][$row['question']]=$row['answer']; 
    // $index++;
} 
$questionsData = [];
foreach($allSubmissions=getAll($con,"select * from ".$g_projectSlug."_questionnaires_questions ") as $row)
{
    $questionsData[$row['id']] = $row['question'];
}

// var_dump($questionsData);

if(isset($_GET['delete-submission']))
{
    $id=$_GET['delete-submission'];
    $query="delete from ".$g_projectSlug."_data_entries where full_submission_id='$id'";
    $result=$con->query($query);
    if(!$result)
        echo $con->error;
    $formId=$_GET['formId'];    
    header("Location:?formId=$formId&m=Deleted successfully.");
}


if(isset($_GET['trash-submission']))
{
    $id=$_GET['trash-submission'];
	$action=$_GET['action'];
	if($action == 'trash'){$action=1;}
	if($action == 'undo'){$action=0;}
    $query="update ".$g_projectSlug."_data_entries set is_trash='$action' where full_submission_id='$id' ";
    $result=$con->query($query);
    if(!$result)
    echo $con->error;
    $formId=$_GET['formId'];    
    header("Location:?formId=$formId&m=Marked  Lead successfully.");
}



if(isset($_POST['create_note'])){
    $id = generateRandomString();
    $note = mb_htmlentities(($_POST['note']));
    $time = time();
    $query="insert into ".$g_projectSlug."_notes set id='$id', customerId='$subId', note='$note', timeAdded='$time'";
    $result=$con->query($query);
    if(!$result)
        echo $con->error;
    
}
if(isset($_POST['create_package'])){
    
    $subId=$_GET['edit'];
    $query="delete from ".$g_projectSlug."_data_entries where full_submission_id='$subId'";
    $result=$con->query($query);
    if(!$result)
        echo $con->error;
    
    $answer = $_POST['answer'];
    $question = $_POST['question'];
    $question_type = $_POST['question_type'];
    $totalEntries=$_POST['totalEntries'];
    $imageI = 0;
    $formId=$_GET['formId'];
    $timeAdded=time();
    $i=0;                       //to track the correct index of answers
    
 
    $submissionId=generateRandomString();
    for($j=0;$j<$totalEntries;$j++)
    {
        if($question_type_i=="File Upload Answers"){
        //upload pics
        if(isset($_FILES['fileToUpload'])){
            //upload pic
            if(isset($_FILES["fileToUpload"])){
                    $random = generateRandomString();
                    $target_dir = "./uploads/";
                    $fileName_db = "Anomoz_"."$random".basename($_FILES["fileToUpload"]["name"][$imageI]);
                    $realname =  basename($_FILES["fileToUpload"]["name"]);
                    $target_file = $target_dir . "Anomoz_"."$random".basename($_FILES["fileToUpload"]["name"][$imageI]);
                    $uploadOk = 1;
                    $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
                    // Check if image file is a actual image or fake image
                    if($_FILES["fileToUpload"]["tmp_name"][$imageI]!="") {
                        
                        $uploadOk = 1;
                    
                        // Check if file already exists
                        if (file_exists($target_file)) {
                            //echo "Sorry, file already exists.";
                            $filename=basename( $_FILES["fileToUpload"]["name"][$imageI]);
                            $uploadOk = 1;
                        }
                        // Check file size
                        if ($_FILES["fileToUpload"]["size"][$imageI] > 500000000000000000000) {
                            echo "Sorry, your file is too large.";
                            $uploadOk = 0;
                        }
                        // Allow certain file formats
                        if(false) {
                            echo "Sorry, only JPG, JPEG, PNG, & GIF files are allowed.";
                            $uploadOk = 0;
                        }
                        // Check if $uploadOk is set to 0 by an error
                        if ($uploadOk == 0) {
                            echo "Sorry, your file was not uploaded.";
                        // if everything is ok, try to upload file
                        } else {
                            if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"][$imageI], $target_file)) {
                                //echo "The file ". basename( $_FILES["fileToUpload"]["name"][$imageI]). " has been uploaded.";
                                $filename=basename( $_FILES["fileToUpload"]["name"][$imageI]);
                                $uploadOk = 1;
                            } else {
                                echo "Sorry, there was an error uploading your file.";
                            }
                        }
                    }
                    
                    $imageI = $imageI+1;
                
            }
            
            if(($filename!="Noe") && ($uploadOk=='1')){
                $answer_i = $fileName_db;
            }

        }
                
    }    
        
        $id=generateRandomString();
        $question_i = mb_htmlentities($question[$i]);
        $answer_i = mb_htmlentities($answer[$i]);
        $question_type_i = mb_htmlentities($question_type[$i]);
        $query_new="select html from ".$g_projectSlug."_questionnaires_questions where id='$question_i'";
        $result_new=getRow($con,$query_new);
        $html=$result_new['html'];
        $i++;
        
        $query="insert into ".$g_projectSlug."_data_entries set id='$id',formId='$formId',companyName='$companyName',organizationType='$organizationType',question='$question_i',questionType='$question_type_i'
        ,answer='$answer_i',timeAdded='$timeAdded',submissionId='$submissionId',userId='$session_userId',html='$html'";
        $result=$con->query($query);
        if(!$result)
            echo $con->error;
    }
    
    header("Location:./responses.php?formId=".$formId);

}
?>
<!DOCTYPE html>


<html lang="en">

	<!-- begin::Head -->
	<head><?require("./includes/views/head.php")?>
</head>

	<!-- end::Head -->

	<!-- begin::Body -->
	<body class="<?echo $g_body_class?>">

		<?require("./includes/views/header.php")?>
        
        	<div class="kt-grid kt-grid--hor kt-grid--root">
			<div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--ver kt-page">
				<div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-wrapper" id="kt_wrapper">

					<!-- begin:: Header -->
					
                    <?require("./includes/views/topmenu.php")?>
					<!-- end:: Header -->

					<!-- begin:: Aside -->
					<?require("./includes/views/leftmenu.php")?>

					<!-- end:: Aside -->
					<div class="kt-body kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-grid--stretch" id="kt_body">
						<div class="kt-content  kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor" id="kt_content">

							<!-- end:: Subheader -->

							<!-- begin:: Content -->
							<div class="kt-container  kt-grid__item kt-grid__item--fluid">
							    
							    <?if(!isset($_GET['edit'])){?>
    							    <?if(isset($_GET['m'])){?>
    							        <div class="alert alert-info"><?echo $_GET['m']?></div>
    							    <?}?>
    							    

    								<div class="kt-portlet kt-portlet--mobile">
    									<div class="kt-portlet__head kt-portlet__head--lg">
    										<div class="kt-portlet__head-label">
    											<span class="kt-portlet__head-icon">
    											</span>
    											<h3 class="kt-portlet__head-title">
													Data
    											</h3>
    										</div>
    										<div class="kt-portlet__head-toolbar">
    											<div class="kt-portlet__head-wrapper">
    												<div class="kt-portlet__head-actions my-2">
    												   
    												    <?if(true){?>
    												    
                                                            <!--<a href="./questionnaires.php?submit_questionnaire=<?echo $_GET['formId'];?>" class="btn btn-primary"><i class="la la-plus" ></i>New</a>-->
                                                        <?}?>
    												</div>
    											</div>
    										</div>
    									</div>
    									<div class="kt-portlet__body">
                                            <form action="" method="post">
                                                <?
                                                if(true){?>
        										<!--begin: Datatable -->
        										<table class="table table-striped- table-bordered table-hover table-checkable add-search" id="kt_table_1">
        											<thead>
        											    <tr>
        											    <?
        											    $questionIds = [];
        											    $subId=$submissionsData[0]['full_submission_id'];
        											     //order by order_no asc
        											    $query="select * from ".$g_projectSlug."_questionnaires_questions where questionnaire_id='$formId' group by question";

        											 //   echo $query;
        											    $results=getAll($con,$query);
        											    foreach($results as $row){
        											        $questionIds[] = $row['id'];
        											    ?>
        											        <th><?echo $row['question'];?></th>
        											    <?}?>
														
														<th>Time Added</th>
        											    <th>Actions</th>
        											    </tr>
        											</thead> 
                                                    <?if(true){?>
        											<tbody>
        											    <?foreach( $submissionsData as $subId => $val){?>
														<?if($submissionsData[$subId]['is_trash'] =='1'){ $background="style='background:#ffe6e6!important'";}
														else {$background="style='background:#ffffff!important'";}?>
        											       <tr>
        											       <? 
        											       foreach($questionIds as $questionId){
        											            ?>
        											            <td <?echo $background;?>>
        											                <?echo $submissionsData[$subId]['questions'][$questionId];?>
        											            </td>
        											            <?
    											            
        											       }
    											           
        											            
        											        ?>
															<td <?echo $background;?>><?echo date("Y-m-d",$submissionsData[$subId]['timeAdded']);?></td>
        											        <td <?echo $background;?>>
															<div class='btn-group'>
        											            <!--<a href="?subId=<?echo $subId?>&formId=<?echo $formId;?>&view_entry=1" class="btn btn-primary">View Entry</a>-->
        											            <!--<a href="?edit=<?echo $subId?>&formId=<?echo $formId;?>" class="btn btn-warning">Edit</a>-->
															<?if($submissionsData[$subId]['is_trash'] =='1'){?>
        											            <a  class="btn btn-warning btn-sm"  href="?action=undo&trash-submission=<?echo $subId?>&formId=<?echo $formId?>">Undo</a>  
															<?}?>
															<?if($submissionsData[$subId]['is_trash'] =='0'){?>
        											            <a  class="btn btn-warning btn-sm"  href="?action=trash&trash-submission=<?echo $subId?>&formId=<?echo $formId?>">Trash</a>  
															<?}?>
															   
															   <a href="#" class="btn btn-danger btn-sm " data-toggle="modal" data-target="#delete_record" data-url="?delete-submission=<?echo $subId?>&formId=<?echo $formId?>">Delete</a>
        											        </div>
															</td>
        											        </tr>
        											        <?
        											    }
        											    
        											    
        											    ?>
    
        											</tbody>
        											<?}?>
        											
        										</table>
        										<?}?>
                                            </form>
    										<!--end: Datatable -->
    									</div>
    								</div>
    							
    							
							    <?}?>
							    
							</div>

							
							

							<!-- end:: Content -->
						</div>
					</div>

					<!-- begin:: Footer -->
					
					<?require("./includes/views/footer.php")?>

					<!-- end:: Footer -->
				</div>
			</div>
		</div>

        <?require("./includes/views/footerjs.php")?>

	</body>
	
	<div class="modal fade" id="create_record_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="modelTitle">Insert</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					</button>
				</div>
				<div class="modal-body">
					
					<form class="kt-form" action="" method="Post" enctype="multipart/form-data">
						<div class="kt-portlet__body">
						    <?
						    $subId=$_GET['edit'];
						    $formId=$_GET['formId'];
						    $query="select * from ".$g_projectSlug."_data_entries where formId='$formId' && full_submission_id='$subId'";
						    $results=getAll($con,$query);
    						foreach($results as $row)
    						{
						    ?>
						    
    										<div class="">
                                                    

                                                    <div class="">
                                                        <input type="text" name="totalEntries" value="<?echo count($results);?>" hidden>
                                                        <input required hidden type="text" name="question[]" value="<?echo $row['question']?>">
                                                        <input required hidden type="text" name="question_type[]" value="<?echo $row['questionType']?>">
                                                        <br><h6><?echo $idToQuestions[$row['question']];?></h6>
                                                        
                                                            <?if($row['questionType']=="Short Answer"){?>
                                                                
                                                                <div class="">
                                                                    <input value="<?echo $row['answer']?>" required type="text" name="answer[]" class="form-control" placeholderno="Response" />
                                                                </div>
                                                                
                                                            <?}else if ($row['questionType']=="Long Answer"){?>
                                                                
                                                                <div class="">
                                                                    <textarea required type="text" name="answer[]" class="form-control" placeholderno="Question" ><?echo $row['answer']?></textarea>
                                                                </div>
                                                                
                                                            <?}else if ($row['questionType']=="Multiple Choice"){?>
                                                                <?
                                                                $html = json_decode($row['html'], true);
                                                                ?>
                                                                <div class="">
                                                                    <div class="form-group">
                                                                        <select class="form-control" name="answer[]" id="type">
                                                                            <?foreach( $html as $option ){?>
                                                                            <option <?if($row['answer']==$option){echo "selected";}?> value="<?echo $option?>"><?echo  $option?></option>
                                                                            <?}?>
                                                                            
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                            <?}else if ($row['questionType']=="Score Answers"){?>
                                                                <?
                                                                $html = json_decode($row['html'], true);
                                                                ?>
                                                                <div class="">
                                                                    <div class="form-group">
                                                                        <div class="range-slider">
                                                                            <div class="range-slider ">
                                                                              <input required class="range-slider__range " name="answer[]" type="range" value="<?echo (($html['score_min']+$html['score_max'])/2)?>" min="<?echo $html['score_min']?>" max="<?echo $html['score_max']?>">
                                                                              <span class="range-slider__value">0</span>
                                                                            </div> 
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                
                                                            <?}else if ($row['questionType']=="File Upload Answers"){?>
                                                                
                                                               <div class="">
                                                                   <?
                                                                $html = json_decode($row['html'], true);
                                                                ?>
                                                                  
                                                                    <!--<label for="exampleFormControlInput1">Upload Response File</label>-->
                                                                    <input required hidden  value="--" type="text" name="answer[]" class="form-control" placeholderno="Question" />
                                                                    <input required type="file" accept="*" name="fileToUpload[]" class="form-control" id="exampleFormControlInput1" />
                                                                    
                                                                  
                
                                                                </div>
                                                                
                                                             <?}else if ($row['questionType']=="True False Question"){?>
                                                                
                                                               <div class="">
                                                                   <?
                                                                $html = json_decode($row['html'], true);
                                                                ?>
                                                                
                                                                    <select required class="form-control" name="answer[]" id="type">
                                                                            <option value="None"  disabled>Select One</option>
                                                                            <option <?if($row['answer']=="True"){echo "selected";}?> value="True">True</option>
                                                                            <option <?if($row['answer']=="False"){echo "selected";}?> value="False">False</option>
                                                                        </select>
                                                                        
                                                                        
                                                                </div>
                                                                
                                                             <?}else if ($row['questionType']=="Yes No Question"){?>
                                                                
                                                               <div class="">
                                                                   <?
                                                                $html = json_decode($row['html'], true);
                                                                ?>
    
                                                                     <select required class="form-control" name="answer[]" id="type">
                                                                            <option value="None"  disabled>Select One</option>
                                                                            <option <?if($row['answer']=="Yes"){echo "selected";}?> value="Yes">Yes</option>
                                                                            <option <?if($row['answer']=="No"){echo "selected";}?> value="No">No</option>
                                                                        </select>
                                                                        
                                                                    </div>
                                                                
                                                             <?}else if ($row['questionType']=="Rating Question"){?>
                                                                
                                                               <div class="">
                                                                   <?
                                                                $html = json_decode($row['html'], true);
                                                                ?>
                                                                
                                                                <div class="rating">
                                                                    <span><input required type="radio" name="answer[]" id="str5" value="5"><label for="str5"></label></span>
                                                                    <span><input required type="radio" name="answer[]" id="str4" value="4"><label for="str4"></label></span>
                                                                    <span><input required type="radio" name="answer[]" id="str3" value="3"><label for="str3"></label></span>
                                                                    <span><input required type="radio" name="answer[]" id="str2" value="2"><label for="str2"></label></span>
                                                                    <span><input required type="radio" name="answer[]" id="str1" value="1"><label for="str1"></label></span>
                                                                </div>
                                                                
                                                                </div>
                                                                             
                                                             <?}else if ($row['questionType']=="Phonenumber Question"){?>
                                                                
                                                               <div class="">
                                                                   <div class="">
                                                                    <input required type="text" value="<?echo $row['answer']?>" name="answer[]" class="form-control" id="exampleFormControlInput1" placeholderno="Phone number" />
                                                                </div>
                                                                </div>
                                                                                                                   
                                                             <?}else if ($row['questionType']=="Email Question"){?>
                                                                
                                                               <div class="">
                                                                   <div class="">
                                                                    <input required type="email" value="<?echo $row['answer']?>" name="answer[]" class="form-control" id="exampleFormControlInput1" placeholderno="Email Address" />
                                                                </div>
                                                                </div>
                                                                  
                                                            <?}?>
                                                            
                                                           
                                                            
                                                    </div>
                                            </div>

							<?}?>
						
							<input type="text" name="actionId" value="" hidden>
							
						</div>
						<div class="kt-portlet__foot">
							<div class="kt-form__actions" style="margin-top: 20px;">
								<input type="submit" name="create_package" value="Submit" class="btn btn-primary">
								<button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
							</div>
						</div>
					</form>
				</div>
			
			</div>
		</div>
	</div>
	
	
	<div class="modal fade" id="create_notes_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="modelTitle">Insert</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					</button>
				</div>
				<div class="modal-body">
					
					<form class="kt-form" action="" method="Post" enctype="multipart/form-data">
						<div class="kt-portlet__body">
						    
						    <label>Note</label>
						   <textarea  required type="text" name="note" class="form-control" placeholderno="Response" ></textarea>



							<input type="text" name="actionId" value="" hidden>
							
						</div>
						<div class="kt-portlet__foot">
							<div class="kt-form__actions" style="margin-top: 20px;">
								<input type="submit" name="create_note" value="Submit" class="btn btn-primary">
								<button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
							</div>
						</div>
					</form>
				</div>
			
			</div>
		</div>
	</div>
	
	<script>
	    
          <?if(isset($_GET['edit'])){?>
            $("#create_record_modal").modal("toggle");
          <?}?>
	</script>
	<!-- end::Body -->
</html>