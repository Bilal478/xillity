<!DOCTYPE html>
<html>
<head>
    <title>PHP Function List</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }

        th, td {
            border: 1px solid black;
            padding: 8px;
            text-align: left;
        }
    </style>
</head>
<body>

<h2>PHP Function List</h2>

<table>
    <tr>
        <th>Function Name</th>
        <th>Parameters</th>
        <th>File Name</th>
        <th>File Path</th>
        
    </tr>

    <?php
    // Specify the base directory to start searching
    $baseDirectory = './'; // Change this to your base directory

    // Pattern to exclude JavaScript/jQuery functions
    $excludedPattern = '/\bfunction\s+\$\(|\bfunction\s+\$\.|\bfunction\s+document\./';

    // Function to search for PHP functions in a file
    function searchForPHPFunctions($file, $excludedPattern)
    {
        $contents = file_get_contents($file);
        $matches = [];

        // Use regular expression to find function names and parameters, excluding JavaScript/jQuery patterns
        preg_match_all('/\bfunction\s+([a-zA-Z_\x7f-\xff][a-zA-Z0-9_\x7f-\xff]*)\s*\(([^)]*)\)/', $contents, $matches);

        if (!empty($matches[1])) {
            // Output each PHP function along with parameters, file name, and path
            foreach ($matches[1] as $index => $function) {
                // Check if the function name is not excluded
                if (!preg_match($excludedPattern, $contents)) {
                    $parameters = $matches[2][$index];
                    echo "<tr>";
                    echo "<td><strong>" . $function . "</strong></td>";
                    echo "<td>" . $parameters . "</td>";
                    echo "<td>" . basename($file) . "</td>";
                    echo "<td>" . $file . "</td>";
                    echo "</tr>";
                }
            }
        }
    }

    // Recursive function to search for PHP functions in directories and subdirectories
    function searchForPHPFunctionsRecursive($directory, $excludedPattern)
    {
        // Get a list of all files and directories in the current directory
        $filesAndDirs = scandir($directory);

        // Iterate through each item
        foreach ($filesAndDirs as $item) {
            // Skip '.' and '..' entries
            if ($item === '.' || $item === '..') {
                continue;
            }

            // Construct the full path to the item
            $itemPath = $directory . '/' . $item;

            // Check if the item is a file
            if (is_file($itemPath) && pathinfo($itemPath, PATHINFO_EXTENSION) === 'php') {
                // If it's a PHP file, search for functions
                searchForPHPFunctions($itemPath, $excludedPattern);
            } elseif (is_dir($itemPath)) {
                // If it's a directory, recursively search in that directory
                searchForPHPFunctionsRecursive($itemPath, $excludedPattern);
            }
        }
    }

    // Start the recursive search from the base directory
    searchForPHPFunctionsRecursive($baseDirectory, $excludedPattern);
    ?>
</table>

</body>
</html>
