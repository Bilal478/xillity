<? require("./global.php");

// $sql ="CREATE TABLE folders (
//     id VARCHAR(255) PRIMARY KEY,
//     name VARCHAR(255) NOT NULL
// );";
// mysqli_query($con, $sql);


// dd(getAll($con, "show tables like '%$g_projectSlug%'"));

if (!checkGlobalPermission('enableEmployeeManagement') || $session_role != "admin") {
	header("Location: ./home.php?m=Oops! Error occured");
}
// checkGlobalPermission('enableEdit') = checkPermission('customers','edits',$session_userId);
// checkGlobalPermission('enableDelete') = checkPermission('customers','deletes',$session_userId);
// $g_enableemployeeProfile = checkPermission('customers','view',$session_userId);

if(!isset($_GET['f'])){header("Location: ?f=/");}

$arrayFields_crud = array(
	// field_name [type, isrequired, array_select, inner_type, small_comment] <= "template"
	"name" => ["input", "required", "", "file", ""],
	"addedBy" => ["input", "required hidden value='$session_userId'", "", "text", ""],
);

//for generating table generation queries
if (false) {
	$t = "DROP TABLE IF EXISTS " . $g_projectSlug . "_" . $primaryTableName . "; CREATE TABLE " . $g_projectSlug . "_files(<br>id VARCHAR(200) PRIMARY KEY,<br>";
	foreach ($arrayFields_crud as $col => $info) {
		$t .= "$col VARCHAR(256) DEFAULT '' ,<Br>";
	}
	$t .= "timeAdded VARCHAR(256) NULL,<br>userId VARCHAR(256) NULL);";
	echo "<code>$t</code>";
}



if (isset($_POST['create_package'])) { // If isset upload button or not
	$timeAdded = time();
	$id = generateRandomString();
	$location = "./uploads/";
	$file_new_name = date("dmy") . time() . $_FILES["name"]["name"]; // New and unique name of uploaded file
	$file_name = $_FILES["name"]["name"]; // Get uploaded file name
	$file_temp = $_FILES["name"]["tmp_name"]; // Get uploaded file temp
	$file_size = $_FILES["name"]["size"];
	$folder=$_GET['f']; // Get uploaded file size
	move_uploaded_file($file_temp, $location . $file_new_name);

	$query = "insert into " . $g_projectSlug . "_files set id='$id' ,name='$file_name',new_name='$file_new_name',folder='$folder', timeAdded='$timeAdded', userId='$session_userId' ";
	$stmt = $con->prepare($query);
	if (!$stmt) {
		echo "err: <code>$query</code>";
	}
	if (!$stmt->execute()) {
		echo "err: <code>$query</code>";
	}
	// 	header("Location: ?m=Data was saved successfully!");
	echo $query;
	exit();
}
if (isset($_GET['delete-record'])) {
	$id = $_GET['delete-record'];
	if ($id != "admin") {
		$sql = "delete from " . $g_projectSlug . "_files where id='$id'";
		if (!mysqli_query($con, $sql)) {
			echo "err";
		}
	}
}

if (isset($_POST['share_create_package'])) {

	$file_id = $_POST['actionId'];
	$timeAdded = time();

	$files = $_POST['sharefiles'];
	foreach ($files as $row) {
		$id = generateRandomString();
		$query = "insert into " . $g_projectSlug . "_share_file set id='$id' ,shared_with='$row',shared_from='$session_userId',file_id='$file_id', timeAdded='$timeAdded', userId='$session_userId' ";
		$stmt = $con->prepare($query);
		if (!$stmt) {
			echo "err: <code>$query</code>";
		}
		if (!$stmt->execute()) {
			echo "err: <code>$query</code>";
		}
	}
	header("Location: ?m=Data was shared successfully!");
}

$primaryTableName = "folders";

    array(
        // field_name [type, isrequired, array_select, inner_type] <= "template"
        "name" => ["input", "", "", "text"],
"folder" => ["input", "", "", "text"],
        
    );

;
    
if (isset($_POST['create_folder_package'])) {
    $actionId = escape($_POST['actionId']);
    $folder = escape($_POST['folder']);
	$parentFolder=escape($_GET['f']);

    // Assuming you have a function to generate a unique ID like 'generateRandomString()'
    if (empty($actionId)) {
        $id = generateRandomString();
        $query = "INSERT INTO " . $g_projectSlug . "_folders (id, folder, timeAdded, userId,parentFolder) VALUES ('$id', '$folder', NOW(), '$session_userId','$parentFolder')";
    } else {
        $query = "UPDATE " . $g_projectSlug . "_folders SET folder='$folder',parentFolder='$parentFolder' WHERE id='$actionId'";
    }

    runQuery($query);

   

    header("Location:./files_storage.php?f=$parentFolder&m=Data was saved successfully!");
}

if (isset($_GET['delete-record'])) {
    $id = escape($_GET['delete-record']);
    $query = "delete from " . $g_projectSlug . "_folders where id='$id'";
    runQuery($query);

    // Specify the parent directory where the folder was deleted from.
    $parentDirectory = './uploads';

    // Delete the child folder within the parent folder
    $childDirectory = $parentDirectory . '/' . $folder;

    if (is_dir($childDirectory)) {
        rmdir($childDirectory);
    }
}




?>
<!DOCTYPE html>


<html lang="en">

<!-- begin::Head -->

<head>
	<? require("./includes/views/head.php") ?>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
	<style>
		.kt-widget__files .kt-widget__desc {
			font-size: 1rem;
			padding-top: 1rem;
		}

		.kt-portlet .kt-portlet__body {
			height: 220px;
		}
		.kt-nav .kt-nav__item > .kt-nav__link {
 
  padding: .55rem 0.75rem;
		}
	</style>

</head>

<!-- end::Head -->

<!-- begin::Body -->

<body class="<? echo $g_body_class ?>">

	<? require("./includes/views/header.php") ?>

	<div class="kt-grid kt-grid--hor kt-grid--root">
		<div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--ver kt-page">
			<div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-wrapper" id="kt_wrapper">

				<!-- begin:: Header -->

				<? require("./includes/views/topmenu.php") ?>
				<!-- end:: Header -->

				<!-- begin:: Aside -->
				<? require("./includes/views/leftmenu.php") ?>

				<!-- end:: Aside -->
				<div class="kt-body kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-grid--stretch"
					id="kt_body">
					<div class="kt-content  kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor" id="kt_content">

						<!-- end:: Subheader -->

						<!-- begin:: Content -->
						<div class="kt-container  kt-grid__item kt-grid__item--fluid">

							<? if (isset($_GET['m'])) { ?>
								<div class="alert alert-info">
									<? echo $_GET['m'] ?>
								</div>
							<? } ?>


							<div class="kt-grid__item kt-grid__item--fluid kt-todo__content" id="kt_todo_content">
								<div class="kt-todo__top">
									<div class="kt-portlet row">
									
										<div class="col-md-12">
											<!--Begin:: Tasks Toolbar-->
											<div class="kt-todo__header">
												<div class="kt-portlet__head kt-portlet__head--noborder">
													<div class="kt-portlet__head-label">
													<h3 class="kt-portlet__head-title">
																	File Manager : <strong><?php echo $_GET['f']; ?></strong>
																</h3>

													</div>
													<div class="kt-portlet__head-toolbar">
														<input class="form-control w-100" placeholder="Search..."
															name="search_box">

														<a href="#" style="width:200px;height: 37px;line-height: 20px;"
															class="btn btn-brand btn-sm btn-elevate btn-icon-sm"
															data-toggle="modal" data-target="#create_record_modal">
															<i class="fa fa-plus"></i>
															Upload File
														</a>
													</div>
												</div>
											</div>
											<!--End:: Tasks Toolbar-->
										</div>
									</div>
								</div>
								
								<div class="row">
								    <div class="col-md-2 p-0">
								        <div class="kt-portlet h-100">
        									<div class="kt-portlet__body h-100">
        									    
        									    <a href="#" class="btn btn-brand btn-sm btn-block" data-toggle="modal" data-target="#create_record_folder_modal">Create Folder</a>
        									    
        									    <ul class="kt-nav">
													<li class="kt-nav__item mb-3">
														<a href="files_storage.php?f=/" class="btn btn-success btn-sm btn-block">Home</a>
													</li>
													<?php
													
													$parentFolder=escape($_GET['f']);
													$query1 = "select * from " . $g_projectSlug . "_folders where parentFolder='$parentFolder'  ";
													$result1 = $con->query($query1);

													foreach ($result1 as $row1) {
														$folderName = $row1['folder'];
														$folderId = $row1['id'];
														?>
														<li class="kt-nav__item">
															<a href="files_storage.php?f=/<?php echo urlencode($folderName); ?>" class="kt-nav__link  p-1">
																<span class="btn btn-secondary btn-sm btn-block"><?php echo $folderName; ?></span>
															</a>
														
														</li>
														<?php
													}
													?>
												</ul>

												
        									
        									</div>
        								</div>
								        
								    </div>
								    <div class="col-md-10">
								        <div class="kt-todo__bottom searchtable">

        									<!--Begin::Section-->
        
        									<div class="row">
        										<?
												$folder=$_GET['f'];
        
        										$query = "select * from " . $g_projectSlug . "_files where folder='$folder' ";
        										$result = $con->query($query);
        
        										foreach ($result as $row) { ?>
        											<div class="col-md-2 col-sm-6 searchitem">
        
        												<!--Begin::Portlet-->
        												<div class="kt-portlet">
        													<div class="kt-portlet__body">
        														<!--begin::Widget -->
        														<?php
        														$path = './uploads/' . $row['new_name'];
        														$extension = pathinfo($path, PATHINFO_EXTENSION);
        
        														?>
        														<a href="<? echo $path ?>" download class="kt-widget__files">
        															<div class="kt-widget__media">
        																<img class="kt-widget__img"
        																	src="https://projects.anomoz.com/commonAssets/assets/media/files/<? echo $extension ?>.svg"
        																	alt="image">
        															</div>
        															<div class="kt-widget__desc">
        																<? echo $row['name'] ?>
        															</div>
        														</a>
        														<a data-toggle="modal"
        															style="cursor: pointer;width: 50px;margin: 1px auto;"
        															data-target="#delete_record"
        															data-url="?delete-record=<? echo $row['id'] ?>"
        															class=" mt-2 badge badge-warning kt-nav__link">
        															<i class="kt-nav__link-icon fa fa-bin"></i><span
        																class="kt-nav__link-text">Delete</span>
        														</a>
        													</div>
        
        												</div>
        
        												<!--End::Portlet-->
        											</div>
        
        
        										<? } ?>
        									</div>
        
        								</div>
								        
								    </div>
								</div>
								
								

								
							</div>

							<? require("./includes/views/footer.php") ?>

							<!-- end:: Footer -->
						</div>
					</div>
				</div>

				<? require("./includes/views/footerjs.php") ?>
			
</body>

<!-- end::Body -->

<div class="modal fade" id="create_record_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
	aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="modelTitle">Insert</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				</button>
			</div>
			<div class="modal-body">

				<form class="kt-form" action="" method="Post" enctype="multipart/form-data" id="uploadForm">
					<div class="kt-portlet__body">


						<input type="file" name="name" id="name" class="form-control" style="height: 300px;"
							onchange="GetFileSize()">
						<p id="size"></p>

						<progress id="uploadProgress" value="0" max="100" class="progress progress-primary w-100"
							style="display:none;"></progress>
						<p id="statusMessage"></p>
						


						<input type="text" name="actionId" id="actionId" value="" hidden>
						<input type="text" name="create_package" id="actionId" value="" hidden>

					</div>
					<div class="kt-portlet__foot">
						<div class="kt-form__actions">
							<input type="submit" name="create_package" value="Submit" class="btn btn-primary">
							<button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
						</div>
					</div>
				</form>
			</div>

		</div>
	</div>
</div>
<div class="modal fade" id="create_record_folder_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
	aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="modelTitle">Create Folder</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				</button>
			</div>
			<div class="modal-body">

				<form class="kt-form" action="" method="Post" enctype="multipart/form-data" id="uploadForm">
					<div class="kt-portlet__body">

                        <label>Folder</label>
						<input type="text" name="folder" id="folder" class="form-control" >


						<input type="text" name="actionId" id="actionId" value="" hidden>

					</div>
					<div class="kt-portlet__foot mt-3">
						<div class="kt-form__actions">
							<input type="submit" name="create_folder_package" value="Submit" class="btn btn-primary">
							<button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
						</div>
					</div>
				</form>
			</div>

		</div>
	</div>
</div>


<script>
	$(document).ready(function () {


		$("#create_record_modal").on('show.bs.modal', function (e) {
			//get data-id attribute of the clicked element
			var mydata = $(e.relatedTarget).data('mydata');
			console.log(mydata);
			//console.log("mydata", mydata)
			if (mydata != null) {
				$("#modelTitle").html("Update");
				<? foreach ($arrayFields_crud as $col => $info) {
					if (strpos($info[1], "hidden") == false) { ?>
						$("<? echo $info[0] ?>[name='<? echo $col ?>']").val(mydata['<? echo $col ?>'])
					<? }
				} ?>

				$("input[name='actionId']").val(mydata['id'])
				$("input[name='password']").val("")


			} else {
				$("#modelTitle").html("Insert");
				$("input[name='actionId']").val("")
				<? foreach ($arrayFields_crud as $col => $info) {
					if (strpos($info[1], "hidden") == false) { ?>
						$("<? echo $info[0] ?>[name='<? echo $col ?>']").val("")
					<? }
				} ?>

				$("input[name='actionId']").val("")

			}


		});
	})
</script>
<script>
	function GetFileSize() {
		var fi = document.getElementById('name'); // GET THE FILE INPUT.

		// VALIDATE OR CHECK IF ANY FILE IS SELECTED.
		if (fi.files.length > 0) {
			// RUN A LOOP TO CHECK EACH SELECTED FILE.
			for (var i = 0; i <= fi.files.length - 1; i++) {

				var fsize = fi.files.item(i).size; // THE SIZE OF THE FILE.
				document.getElementById('size').innerHTML =
					document.getElementById('size').innerHTML + '<br /> ' +
					'<b> File Size:' + Math.round((fsize / 1024)) + '</b> KB';
			}
		}
	}

	$("#uploadForm").submit(function (e) {
		e.preventDefault();

		var formData = new FormData(this);
		$("#uploadProgress").show();
		var progressBar = $("#uploadProgress");
		var statusMessage = $("#statusMessage");

		$.ajax({
			type: "POST",
			url: "",
			data: formData,
			contentType: false,
			processData: false,
			xhr: function () {
				var xhr = $.ajaxSettings.xhr();
				if (xhr.upload) {
					xhr.upload.addEventListener('progress', function (e) {
						if (e.lengthComputable) {
							var percent = (e.loaded / e.total) * 100;
							// console.log("percent", percent)
							progressBar.val(percent);
							statusMessage.text(percent.toFixed(2) + "% uploaded");

							if (percent === 100) {
								// Show the image when the progress reaches 100%
								statusMessage.html('<img src="./assets/loader.gif" style="width:100px" alt="Uploaded Image">');
							}
						}
					}, false);
				}
				return xhr;
			},
			success: function (response) {
				statusMessage.text("Upload complete. " + "");
				window.location="?m=File was uploaded successfully!&f=<?echo $parentFolder?>";
				location.reload();

			},
			error: function (error) {
				statusMessage.text("Upload error: " + error.statusText);
			}
		});
	});
</script>
<script>
	$("input[name=search_box]").on("keyup", function () {
		var value = $(this).val().toLowerCase();
		$(".searchtable .searchitem").filter(function () {
			$(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
		});
	});
</script>


</html>