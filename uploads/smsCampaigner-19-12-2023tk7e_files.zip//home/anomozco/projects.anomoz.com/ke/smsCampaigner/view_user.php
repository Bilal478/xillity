<? require("./global.php");

$customer_id = mb_htmlentities($_GET['id']);
$customer_info = getRow($con, "select * from " . $g_projectSlug . "_" . "users" . " where id='$customer_id'");

$arrayFields_crud_documents = array(
	"title" => ["input", "required", "", "text"],
	"customerId" => ["input", "required hidden value='$customer_id'", "", "text"],
	"document" => ["input", "", "", "file"],
);
$arrayFields_crud_notes = array(
	"note" => ["textarea", "required", "", "text"],
	"customerId" => ["input", "required hidden value='$customer_id'", "", "text"],
	"document" => ["input", "", "", "file"],
);

//for insert & update of notes and documents
if (isset($_POST['create_modal_submitted'])) {
	if (isset($_POST['create_documents'])) {
		$arrayFields_crud = $arrayFields_crud_documents;
		$tableName = "documents";
	} else if (isset($_POST['create_notes'])) {
		$arrayFields_crud = $arrayFields_crud_notes;
		$tableName = "notes";
	}
	$timeAdded = time();
	$actionId = mb_htmlentities(($_POST['actionId']));
	$files_array = [];
	$queryExtra = '';
	foreach ($arrayFields_crud as  $col => $info) {

		if (in_array($info[3], ["image", "file"])) {
			//for images
			if (isset($_FILES[$col])) {

				if ((strpos($info[1], 'multiple') !== false)) {
					$imageArray = [];
					foreach ($_FILES[$col]['tmp_name'] as $k => $pic) {
						$figure = uploadMultipleFile($_FILES[$col], $k, "./uploads/");
						if($figure!=''){
						    $imageArray[] = $figure;
						}
					}
					if(count($imageArray)>0){
					    $fileLink = json_encode($imageArray, true);
					}
				} else {
					$fileLink = storeFile($_FILES[$col]);
				}
                
                if($fileLink!=""){
				    $files_array[$col] = $fileLink;
                }
			}
		} else {
			//for text
			//if multiple type field
			if ((strpos($info[1], 'multiple') !== false)) {
				$val = (json_encode($_POST[$col], true));
			} else {
				$val = mb_htmlentities($_POST[$col]);
			}

			if ($val != '' && $val != NULL) {
				$queryExtra .= ", $col='" . $val . "' ";
			}
		}
	}
	

	$timeAdded = time();
	$id = generateRandomString();
	if ($actionId == "") {
		$actionId = $id;
		$query = "insert into " . $g_projectSlug . "_" . $tableName . " set id='$id' $queryExtra, timeAdded='$timeAdded', userId='$session_userId' ";
		$stmt = $con->prepare($query);
		if (!$stmt) {
			echo "err: <code>$query</code>";
		}
		if (!$stmt->execute()) {
			echo "err: <code>$query</code>";
		}
	} else {
		//update
		$query = "update " . $g_projectSlug . "_" . $tableName . " set id='$actionId' $queryExtra where id='$actionId'";
		$stmt = $con->prepare($query);
		if (!$stmt) {
			echo "err: <code>$query</code>";
		}
		if (!$stmt->execute()) {
			echo "err: <code>$query</code>";
		}
	}

	//update files
	foreach ($files_array as $col => $file) {
		if ($file != "") {
			$stmt = $con->prepare("update " . $g_projectSlug . "_" . $tableName . " set $col='$file' where id='$actionId'");
			if (!$stmt) {
				echo "err: <code>$query</code>";
			}
			if (!$stmt->execute()) {
				echo "err: <code>$query</code>";
			}
		}
	}

	if ($g_redirectHomeOnSave) {
		header("Location: ./home.php?m=Data was saved successfully!");
	} else {
		header("Location: ?id=$customer_id&m=Data was saved successfully!");
	}
}

if (isset($_GET['delete-record'])) {
	$id = mb_htmlentities($_GET['delete-record']);
	$tableName = mb_htmlentities($_GET['table-name']);
	if ($id != "admin") {
		$stmt = $con->prepare("delete from " . $g_projectSlug . "_" . $tableName . " where id=?");
		$stmt->bind_param("s", $id);
		if (!$stmt->execute()) {
			echo "err";
		}
	}
}

if (checkGlobalPermission('g_enableBulkDelete')) {
	if (isset($_POST['delete_bulk'])) {
		$del  = "('" . implode("', '", $_POST['delete_bulk']) . "')";
		$sql = "delete from " . $g_projectSlug . "_" . $tableName . " where id in $del";
		if (!mysqli_query($con, $sql)) {
			echo "can not";
		}
	}
}

//udpate secondary values
if (isset($_POST['update_client'])) {

	$sql = "delete from " . $g_projectSlug . "_customer_field_values where customer_id = '$customer_id'";
	if (!mysqli_query($con, $sql)) {
		echo "can not";
	}

	$fields = getAll($con, "SELECT * FROM " . $g_projectSlug . "_customer_fields");
	foreach ($fields as $field) {
		$field_id = $field['id'];
		$value = $_POST[$field_id];
		$time = time();
		$id = generateRandomString();
		$sql = "insert into " . $g_projectSlug . "_customer_field_values set id='$id', field_id='$field_id', value='$value', 
        timeAdded='$time',  customer_id = '$customer_id', userId='$session_userId'";
		if (!mysqli_query($con, $sql)) {
			echo "can not";
		}
	}
}



?>
<!DOCTYPE html>


<html lang="en">

<!-- begin::Head -->

<head><? require("./includes/views/head.php") ?>
</head>

<!-- end::Head -->

<!-- begin::Body -->

<body class="<? echo $g_body_class ?>">

	<? require("./includes/views/header.php") ?>

	<div class="kt-grid kt-grid--hor kt-grid--root">
		<div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--ver kt-page">
			<div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-wrapper" id="kt_wrapper">

				<!-- begin:: Header -->

				<? require("./includes/views/topmenu.php") ?>
				<!-- end:: Header -->

				<!-- begin:: Aside -->
				<? require("./includes/views/leftmenu.php") ?>

				<!-- end:: Aside -->
				<div class="kt-body kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-grid--stretch" id="kt_body">
					<div class="kt-content  kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor" id="kt_content">

						<!-- end:: Subheader -->

						<!-- begin:: Content -->
						<div class="kt-container  kt-grid__item kt-grid__item--fluid">

							<? if (isset($_GET['m'])) { ?>
								<div class="alert alert-info"><? echo $_GET['m'] ?></div>
							<? } ?>


							<div class="kt-portlet ">
								<div class="kt-portlet__body">
									<div class="kt-widget kt-widget--user-profile-3">
										<div class="kt-widget__top">
											<div class="kt-widget__pic kt-widget__pic--danger kt-font-danger kt-font-boldest kt-font-light">
												<? echo strtoupper(substr($customer_info['name'] . " " . $customer_info['last_name'], 0, 2)); ?>
											</div>
											<div class="kt-widget__content">
												<div class="kt-widget__head">
													<a href="#" class="kt-widget__title"><? echo $customer_info['name'] . " " . $customer_info['last_name']; ?></a>
													<div class="kt-widget__action">
														<? if (checkGlobalPermission('enableMessages') && checkGlobalPermission('enableCustomerToLogin')) { ?>
															<a href="./messages.php?u=<? echo $customer_info['userId']; ?>" class="btn btn-sm btn-success btn-primary ">Message</a>
														<? } ?>
														<? if ($customer_info['email'] != "") { ?>
															<a href="mailto:<? echo $customer_info['email'] ?>" class="btn btn-brand btn-sm btn-upper">E-mail</a>
														<? } ?>
													</div>
												</div>
												<div class="kt-widget__subhead ">
													<?if($customer_info['email']!=""){?><a href="mailto:<? echo $customer_info['address'] ?>"><i class="fa fa-envelope"></i><? echo $customer_info['email'] ?></a><?}?>
													<?if($customer_info['phone']!=""){?><a href="tel:<? echo $customer_info['phone'] ?>"><i class="fa fa-phone"></i><? echo $customer_info['phone'] ?></a><?}?>
													<?if($customer_info['address']!=""){?><a href="https://maps.google.com/?q=<? echo $customer_info['address'] ?>" target="_blank"><i class="fa fa-map-marker"></i><? echo $customer_info['address'] ?></a><?}?>
												</div>
												<div class="kt-widget__info">


												</div>
											</div>
										</div>
									</div>
								</div>
							</div>


							<? if (checkGlobalPermission('enableCustomerSecondaryFields')) { ?>
								<div class="kt-portlet">
									<div class="kt-portlet__body">
										<div class="row">
											<div class="col-md-12">

												<form action="" method="post">
													<div class="form-row">
														<?
														$field_values = [];
														$temp = getAll($con, "SELECT * FROM " . $g_projectSlug . "_customer_field_values where customer_id='$customer_id'");
														foreach ($temp as $row) {
															$field_values[$row['field_id']] = $row['value'];
														}
														$fields = getAll($con, "SELECT * FROM " . $g_projectSlug . "_customer_fields");
														foreach ($fields as $field) { ?>
															<div class="form-group col-md-4">
																<label for=""><? echo ucfirst($field['field_name']) ?></label>
																<input type="text" placeholder="<? echo ucfirst($field['field_name']) ?>" name="<? echo ($field['id']) ?>" value='<? echo $field_values[$field['id']]; ?>' class="form-control">
															</div>
														<? } ?>

													</div>
													<button name="update_client" class="btn btn-primary">Update</button>
												</form>
											</div>
										</div>
									</div>
								</div>


							<? } ?>
                            
                            <!--customer documents-starts-->
							<div class="row">
								<? $moduleNames = ["documents", "notes"];
								foreach ($moduleNames as $module) { ?>
									<div class="col-md-6">
										<?
										$showModule = false;
										$tableName = $module;
										if ($module == "documents" && checkGlobalPermission('enableCustomerDocuments')) {
											$showModule = true;
											$arrayFields_crud = $arrayFields_crud_documents;
										} else if ($module == "notes" && checkGlobalPermission('enableCustomerNotes')) {
											$showModule = true;
											$arrayFields_crud = $arrayFields_crud_notes;
										}

										if ($showModule) { ?>
											<div class="kt-portlet kt-portlet--mobile">
												<div class="kt-portlet__head kt-portlet__head--lg">
													<div class="kt-portlet__head-label">
														<span class="kt-portlet__head-icon">
														</span>
														<h3 class="kt-portlet__head-title">
															<? echo ucfirst($tableName) ?>
														</h3>
													</div>
													<div class="kt-portlet__head-toolbar">
														<div class="kt-portlet__head-wrapper">
															<div class="kt-portlet__head-actions">

																<? renderImportExportButtons($module); ?>

																<a href="#" class="btn btn-brand btn-elevate btn-icon-sm" data-toggle="modal" data-target="#create_<? echo $module ?>_modal">
																	<i class="fa fa-plus"></i>
																	New Record
																</a>

															</div>
														</div>
													</div>
												</div>
												<div class="kt-portlet__body">
													<form action="" method="post">
														<? if (checkGlobalPermission('g_enableBulkDelete')) { ?>
															<button type="button" class="btn btn-info btn-sm text-white " onclick="selectAll();">Select All</button>
															<button type="submit" class="btn btn-danger btn-sm text-white ">Delete Bulk</button>
														<? } ?>
														<!--begin: Datatable -->
														<table class="table table-striped- table-bordered table-hover table-checkable add-search" id="kt_table_1">
															<thead>
																<tr>
																	<?
																	$query = "select * from " . $g_projectSlug . "_" . $tableName . " where customerId='$customer_id' order by timeAdded desc";
																	$header = getRow($con, $query . " limit 1");
																	if (checkGlobalPermission('g_enableBulkDelete')) { ?><th>Select</th><? } ?>
																	<? foreach ($arrayFields_crud as  $col => $info) {
																		if (array_key_exists($col, $header) || (empty($header))) { ?>
																			<? if (strpos($info[1], "hidden") === false) { ?>
																				<th><? echo ucfirst(str_replace("_", " ", $col)) ?></th>
																	<? }
																		}
																	} ?>
																	<th>Time Added</th>
																	<th>Actions</th>
																</tr>
															</thead>
															<tbody>
																<? $results = getAll($con, $query);
																foreach ($results as $row) { ?>
																	<tr>
																		<? if (checkGlobalPermission('g_enableBulkDelete')) { ?>
																			<th>
																				<div class="form-check">
																					<label class="form-check-label">
																						<input class="form-check-input" type="checkbox" name="delete_bulk[]" value="<? echo $row['id'] ?>">
																						<span class="form-check-sign">
																							<span class="check"></span>
																						</span>
																					</label>
																				</div>
																			</th>
																		<? } ?>
																		<? foreach ($arrayFields_crud as $col => $info) { ?>
																			<? if (strpos($info[1], "hidden") === false) {
																				if (array_key_exists($col, $header) || (empty($header))) { ?>
																					<td><? if ($info[3] == "image") { ?>
																							<a href="./uploads/<? echo $row[$col] ?>" target="_blank"><img src="./uploads/<? echo $row[$col] ?>" class="img-thumbnail" style="height:90px;" onerror="this.src='./assets/media/404.png';"></a>
																							<? } else if ($info[3] == "file") {
																							if ($row[$col] != "") { ?>
																								<a href="./uploads/<? echo $row[$col] ?>" target="_blank" class='badge btn-info btn-sm'>View File</a>
																						<? }
																						} else {
																							echo ($row[$col]);
																						} ?>
																					</td>
																		<? }
																			}
																		} ?>
																		<td><? echo  date("d M Y h:i", $row["timeAdded"]) ?></td>
																		<td>
																			<? if (checkGlobalPermission('enableEdit')) { ?>
																				<a href="#" class="btn btn-warning" data-toggle="modal" data-target="#create_<? echo $module ?>_modal" data-mydata='<? echo (json_encode($row, true)); ?>'>Edit</a>
																			<? } ?>
																			<? if (checkGlobalPermission('enableDelete')) { ?>
																				<a href="#" class="btn btn-danger" data-toggle="modal" data-target="#delete_record" data-url="?id=<? echo $customer_id ?>&delete-record=<? echo $row['id'] ?>&table-name=<? echo $module ?>">Delete</a>
																			<? } ?>
																		</td>
																	</tr>
																<? } ?>

															</tbody>
														</table>
													</form>
													<!--end: Datatable -->
												</div>
											</div>
										<? } ?>
									</div>
								<? } ?>
							</div>
							<!--customer documents-ends-->
							
							
							<!--add new modules here-->



						</div>
						<!-- end:: Content -->
					</div>
				</div>

				<!-- begin:: Footer -->
				<? require("./includes/views/footer.php") ?>
				<!-- end:: Footer -->
			</div>
		</div>
	</div>

	<? require("./includes/views/footerjs.php") ?>

</body>

<!-- end::Body -->

<? foreach ($moduleNames as $module) {
	$showModule = false;
	$tableName = $module;
	if ($module == "documents" && checkGlobalPermission('enableCustomerDocuments')) {
		$showModule = true;
		$arrayFields_crud = $arrayFields_crud_documents;
	} else if ($module == "notes" && checkGlobalPermission('enableCustomerNotes')) {
		$showModule = true;
		$arrayFields_crud = $arrayFields_crud_notes;
	}
	if ($showModule) { ?>
		<div class="modal fade" id="create_<? echo $module ?>_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title" id="modelTitle">Insert</h5>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						</button>
					</div>
					<div class="modal-body">

						<form class="kt-form" action="" method="Post" enctype="multipart/form-data">
							<div class="kt-portlet__body">

								<? foreach ($arrayFields_crud as $col => $info) { ?>
									<div class="form-group">
										<? if (strpos($info[1], "hidden") === false) { ?>
											<label><? echo ucfirst(str_replace("_", " ", $col)) ?></label>
											<? if ($info[4] != "") { ?>
												<small><? echo $info[4] ?></small>
											<? } ?>
										<? } ?>
										<? if ($info[0] == "input" && in_array($info[3], ["text", "email", "password", "number", "file"])) { ?>
											<input type="<? echo $info[3] ?>" name="<? echo $col ?>" class="form-control" <? echo $info[1] ?>>
										<? } else if ($info[0] == "select") { ?>
											<select name="<? echo $col ?>" class="form-control" <? echo $info[1] ?>>
												<? foreach ($info[2] as $option) { ?>
													<option><? echo $option ?></option>
												<? } ?>
											</select>
										<? } else if ($info[0] == "input" && in_array($info[3], ["image"])) { ?>
											<input type="file" name="<? echo $col ?>" class="form-control" <? echo $info[1] ?>>
										<? } else if ($info[0] == "textarea") { ?>
											<textarea type="text" name="<? echo $col ?>" class="form-control" <? echo $info[1] ?>></textarea>
										<? } else { ?>
											<code><? echo $col ?> Couldn't render</code>
										<? } ?>
									</div>
								<? } ?>

								<input type="text" name="actionId" value="" hidden>
								<input type="text" name="create_modal_submitted" value="create_modal_submitted" hidden>

							</div>
							<div class="kt-portlet__foot">
								<div class="kt-form__actions">
									<input type="submit" name="create_<? echo $module ?>" value="Submit" class="btn btn-primary">
									<button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
								</div>
							</div>
						</form>
					</div>

				</div>
			</div>
		</div>


		<script>
			$(document).ready(function() {


				$("#create_<? echo $module ?>_modal").on('show.bs.modal', function(e) {
					//get data-id attribute of the clicked element
					var mydata = $(e.relatedTarget).data('mydata');
					console.log(mydata);
					//console.log("mydata", mydata)
					if (mydata != null) {
						$("#modelTitle").html("Update");
						<? foreach ($arrayFields_crud as $col => $info) {
							if ((strpos($info[1], "hidden") === false) && !in_array($info[3], ["file", "image"])) { ?>
								$("<? echo $info[0] ?>[name='<? echo $col ?>']").val(mydata['<? echo $col ?>'])
						<? }
						} ?>

						$("input[name='actionId']").val(mydata['id'])


					} else {
						$("#modelTitle").html("Insert");
						$("input[name='actionId']").val("")
						<? foreach ($arrayFields_crud as $col => $info) {
							if ((strpos($info[1], "hidden") === false) && !in_array($info[3], ["file", "image"])) { ?>
								$("<? echo $info[0] ?>[name='<? echo $col ?>']").val("")
						<? }
						} ?>

						$("input[name='actionId']").val("")

					}


				});
			})
		</script>
<? }
} ?>





</html>