<?  require("./global.php");

$primaryTableName = "faq";

    array(
        // field_name [type, isrequired, array_select, inner_type] <= "template"
        "title" => ["input", "", "", "text"],
        "description" => ["input", "", "", "text"],
        "myfiles" => ["input", "multiple", "", "file"],
     
    );

;
    


if(isset($_POST['create_package'])){
    $timeAdded = time();
    $actionId = mb_htmlentities(($_POST['actionId']));
    $title = mb_htmlentities($_POST['title']);    
    $description = mb_htmlentities($_POST['description']);    
	
	
	$file_name;
	$file_size;
	$file_type;
	if(isset($_FILES['files'])) {
      $errors = array();
      $uploadedFiles = array();
      $extension = array("jpeg","jpg","png","gif","mp4","pdf");
      $bytes = 1024;
      $totalBytes = 10485760;
      foreach($_FILES['files']['tmp_name'] as $key => $tmp_name) {
        $file_name = $_FILES['files']['name'][$key];
        $file_size = $_FILES['files']['size'][$key];
        $file_tmp = $_FILES['files']['tmp_name'][$key];
        $file_type = $_FILES['files']['type'][$key];
        $file_ext = strtolower(end(explode('.',$file_name)));
        
        if(empty($errors)==true){
          move_uploaded_file($file_tmp,"./uploads/".$file_name);
          $uploadedFiles[] = $file_name;
    
          // Insert file information into MySQL database
         
        }
      }
	}
	
	$uploadedFiles = json_encode($uploadedFiles, true);
	

    if($actionId==""){
        $id = generateRandomString();
        $actionId = $id;
        $query = "insert into midwifeManager_faq set id='$id' , title='$title', description='$description', name='$uploadedFiles',size='$file_size',type='$file_type', timeAdded='$timeAdded', userId='$session_userId' ";
    }else{
        $query = "update midwifeManager_faq set id='$actionId' , title='$title', description='$description', name='$uploadedFiles',size='$file_size',type='$file_type' where id='$actionId'";
    }
    $stmt = $con->prepare($query);
    if(!$stmt){echo "err: <code>$query</code>";}
    if(!$stmt->execute()){echo "err: <code>$query</code>";}

    $myfiles = [];

    if($_FILES['myfiles']){
		foreach ($_FILES['myfiles']['tmp_name'] as $k => $pic) {
		
		    $figure = uploadMultipleFile($_FILES['myfiles'],$k,"./uploads/");
			if($figure!=""){
			    $myfiles[] = $figure;
			}
			
		}
	}
	
	$myfiles = json_encode($myfiles, true);
    if($myfiles!=""){
        $stmt = $con->prepare("update midwifeManager_faq set myfiles='$myfiles' where id='$actionId'");
        if(!$stmt){echo "err: <code>$query</code>";}
        if(!$stmt->execute()){echo "err: <code>$query</code>";}
    }
    
	$thumbnail = storeFile($_FILES['thumbnail']);
    if($thumbnail!=""){
        $stmt = $con->prepare("update midwifeManager_faq set thumbnail='$thumbnail' where id='$actionId'");
        if(!$stmt){echo "err: <code>$query</code>";}
        if(!$stmt->execute()){echo "err: <code>$query</code>";}
    }

    $rStr = "";
    if(isset($_GET['id'])){$rStr .=  "&id=".$_GET['id'];}
    header("Location: ?m=Data was saved successfully!".$rStr);
}



    
    
if(isset($_GET['delete-record'])){
    $id = mb_htmlentities($_GET['delete-record']);
    if($id!="admin"){
        $stmt = $con->prepare("delete from midwifeManager_faq where id=?");
        $stmt->bind_param("s", $id);
        if(!$stmt->execute()){echo "err";}
    }
}




?>
<!DOCTYPE html>


<html lang="en">

	<!-- begin::Head -->
	<head><?require("./includes/views/head.php")?>
</head>

	<!-- end::Head -->

	<!-- begin::Body -->
	<body class="<?echo $g_body_class?>">

		<?require("./includes/views/header.php")?>
        
        	<div class="kt-grid kt-grid--hor kt-grid--root">
			<div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--ver kt-page">
				<div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-wrapper" id="kt_wrapper">

					<!-- begin:: Header -->
					
                    <?require("./includes/views/topmenu.php")?>
					<!-- end:: Header -->

					<!-- begin:: Aside -->
					<?require("./includes/views/leftmenu.php")?>

					<!-- end:: Aside -->
					<div class="kt-body kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-grid--stretch" id="kt_body">
						<div class="kt-content  kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor" id="kt_content">

							<!-- end:: Subheader -->

							<!-- begin:: Content -->
							<div class="kt-container  kt-grid__item kt-grid__item--fluid">
							    
							    <?if(isset($_GET['m'])){?>
							        <div class="alert alert-info"><?echo $_GET['m']?></div>
							    <?}?>

								<div class="kt-portlet kt-portlet--mobile">
									<div class="kt-portlet__head kt-portlet__head--lg">
										<div class="kt-portlet__head-label">
											<span class="kt-portlet__head-icon">
											</span>
											<h3 class="kt-portlet__head-title">
												Knowledge Base FAQs
											</h3>
										</div>
										<div class="kt-portlet__head-toolbar">
											<div class="kt-portlet__head-wrapper">
												<div class="kt-portlet__head-actions">
												    
												    <?renderImportExportButtons();?>
												    <?if($session_role=="admin"){?>
													<a href="#" class="btn btn-brand btn-elevate btn-icon-sm" data-toggle="modal" data-target="#create_record_modal">
														<i class="la la-plus"></i>
														New Record
													</a>
													<?}?>
															
												</div>
											</div>
										</div>
									</div>
									<div class="kt-portlet__body">
                                        <form action="" method="post">
                                            <?if(checkGlobalPermission('enableBulkDelete')){?>
                                                <button type="button" class="btn btn-info btn-sm text-white " onclick="selectAll();">Select All</button>
                                                <button type="submit"  class="btn btn-danger btn-sm text-white ">Delete Bulk</button>
                                            <?}?>
    										<!--begin: Datatable -->
    										<? $query = "select * from midwifeManager_faq t order by t.timeAdded desc";
    $results = getAll($con, $query);
        foreach($results as $id=>$row){?>
        
		<div class="col-md-12">
		    
		    


		    <div class="accordion accordion-solid accordion-toggle-plus" id="accordionExample1<?echo $id?>">
			<div class="card">
            	<div class="card-header" id="headingTwo1<?echo $id?>">
            		<div class="card-title collapsed" data-toggle="collapse" data-target="#collapseTwo1<?echo $id?>" aria-expanded="false" aria-controls="collapseTwo1<?echo $id?>">
            				<? echo $row['title']?>
            		</div>
            	</div>
            	<div id="collapseTwo1<?echo $id?>" class="collapse" aria-labelledby="headingTwo1<?echo $id?>" data-parent="#accordionExample1<?echo $id?>" style="">
            		<div class="card-body">
            				<? echo $row['description'];
            				
            				?>
            				
            				<br><br>
            				<?foreach(json_decode($row['myfiles'] , true) as $mt){?>
            				<?if($row['thumbnail']==""){?>
            				    <a href="./uploads/<?echo $mt?>" target="_blank" class="badge badge-primary">View file</a>
            				    <?}else{?>
            				    <a href="./uploads/<?echo $mt?>" target="_blank" class="badge1 badge-primary1">
            				        <img src="./uploads/<?echo $row['thumbnail']?>" style="height:80px;">
            				    </a>
            				    <?}?>
            				<?}; ?>
            				
            				
            				<?if($session_role=="admin"){?>
            				<Br>
            				<div class="btn-group">
                				<a href="#" class="btn btn-warning btn-sm" data-toggle="modal" data-target="#create_record_modal" data-mydata='<?echo  (json_encode($row, true));?>' >Edit</a>
            					<a href="#" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#delete_record" data-url="?delete-record=<?echo $row['id']?>">Delete</a>
            		        </div>
            		        <?}?>
            		</div>
            	</div>
            </div>
	<br>
</div>

		 
													</div>
		<?}?>

                                        </form>
										<!--end: Datatable -->
									</div>
								</div>
							
							
							</div>

							
							

							<!-- end:: Content -->
						</div>
					</div>

					<!-- begin:: Footer -->
					
					<?require("./includes/views/footer.php")?>

					<!-- end:: Footer -->
				</div>
			</div>
		</div>

        <?require("./includes/views/footerjs.php")?>

	</body>

	<!-- end::Body -->
	
	<div class="modal fade" id="create_record_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="modelTitle">Insert</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					</button>
				</div>
				<div class="modal-body">
					
					<form class="kt-form" action="" method="Post" enctype="multipart/form-data">
						<div class="kt-portlet__body">
						    
						   
						  <!-- modal -->

<div>
<div class="form-group">
    <label>Title</label>
    <input type="text" name="title" class="form-control"   >
</div>
	
<div class="form-group">
    <label>Description</label>
    <input type="text" name="description" class="form-control"   >
</div>

<div class="form-group">
    <label>Files</label>
    <input type="file"    name="myfiles[]" class="form-control" multiple  >
</div>	
<div class="form-group">
    <label>Thumbnail</label>
    <input type="file"    name="thumbnail" class="form-control"   >
</div>	
<input type="text" name="actionId" value="" hidden>

</div>
							
						
							<input type="text" name="actionId" value="" hidden>
							
							<div class="alert alert-outline-primary">When uploading videos, please make sure you upload small size videos.</div>
						</div>
						<div class="kt-portlet__foot">
							<div class="kt-form__actions">
								<input type="submit" name="create_package" value="Submit" class="btn btn-primary">
								<button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
							</div>
						</div>
					</form>
				</div>
			
			</div>
		</div>
	</div>
	

	<script>$(document).ready(function(){
	      

          $("#create_record_modal").on('show.bs.modal', function (e) {
            var mydata = $(e.relatedTarget).data('mydata');
            console.log("mydata->",mydata);
            $("input[type='checkbox']").prop('checked', false);
            if(mydata!= null){
            	$("#modelTitle").html("Update");            	
                $("input[name='title']").val(mydata['title'])                
                $("input[name='description']").val(mydata['description'])                
                
                $("input[name='actionId']").val(mydata['id'])
            }else{
                $("#modelTitle").html("Insert");
                $("input[name='title']").val("")
                $("input[name='description']").val("")
            
                $("input[name='actionId']").val("")
            }
        });
    })
</script>
	
				
		
								
</html>