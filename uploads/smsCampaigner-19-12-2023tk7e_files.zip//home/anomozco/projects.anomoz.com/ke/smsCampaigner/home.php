<?require("./global.php");

if(checkGlobalPermission('enableEmployeeAccessAccount')){
    if (isset($_GET['access_account'])) {
		$id = $_GET['access_account'];
		$deets = getRow($con, "select * from " . $g_projectSlug . "_users where id='$id'");
		$_SESSION['session_access_id'] = $session_id; //the person who accessed the account

		$_SESSION['email'] = $deets['email'];
		$_SESSION['password'] = $deets['password'];
		$_SESSION['user_id'] = $deets['id'];
		if ($_SESSION['isAdmin'] == "admin")
			$_SESSION['isAdmin'] = "notadmin";
		else
			$_SESSION['isAdmin'] = "admin";

		if ($session_role == "admin") {
			$_SESSION['user_original_id'] = "admin";
		}

		if ($_SESSION['user_original_id'] == $_SESSION['session_access_id']) {
			unset($_SESSION['session_access_id']);
			$filename = "home.php";
		}
		
		if ($filename=='') {
		    $filename = "employees.php";
		}

		header("Location: ./$filename?m=Account accessed successfully!");
	}
}

?>
<!DOCTYPE html>


<html lang="en">

<!-- begin::Head -->

<head>
    <?require("./includes/views/head.php")?>
    <style>
    .rounded {
        border-radius: 20px !important
    }
    </style>
</head>

<!-- end::Head -->

<!-- begin::Body -->

<body class="<?echo $g_body_class?>" onload="">

    <?require("./includes/views/header.php")?>

    <div class="kt-grid kt-grid--hor kt-grid--root">
        <div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--ver kt-page">
            <div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-wrapper" id="kt_wrapper">

                <!-- begin:: Header -->

                <?require("./includes/views/topmenu.php")?>
                <!-- end:: Header -->

                <!-- begin:: Aside -->
                <?require("./includes/views/leftmenu.php")?>

                <!-- end:: Aside -->
                <div class="kt-body kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-grid--stretch"
                    id="kt_body">
                    <div class="kt-content p-0 kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor" id="kt_content">

                        <!-- end:: Subheader -->

                        


                        <!-- begin:: Content -->
                        <div class="kt-container  kt-grid__item kt-grid__item--fluid"
                            style="top: 10px;position: relative;">


                            <!--if exported-->
                            <?if(isset($_GET['export'])){?>
                            <div class="alert alert-success">Dowloaded generated files: <a
                                    href="<?echo $filename_exported?>" class="text-white "><strong>Download export
                                        file</strong></a></div>
                            <?}?>

                            <?if(isset($_GET['m'])){?>
                            <div class="alert alert-info">
                                <?echo $_GET['m']?>
                            </div>
                            <?}?>

                            <? if ($session_role != "admin" && $session_userId!=$_SESSION['user_original_id'] && $_SESSION['user_original_id']!="") { ?>
                            <a href="./home.php?access_account=<?echo $_SESSION['user_original_id'];?>&nosetorg=1"
                                class="alert alert-info" style="background: #1ad91a;">Click here to return to your
                                account</a>
                            <? } ?>

                            <div class="p-4 mb-3"
                                style="border-radius: 20px;background-image: url('https://projects.anomoz.com/commonAssets/shapes-light.png');background-position: center;background-size: cover;">
                                <div class="row mb-2" style="min-height: 300px;">
                                    <div class="col-md-6  mb-sm">
                                        <div class="hero-1-padding rounded shadow"
                                            style="height: 100%;background:#edf4fa;max-height: 392px;border-bottom: 51px solid <?echo $g_primaryColor?>;">
                                            <h2 class="h1"><strong>
                                                    <?echo $g_projectTitle?>
                                                </strong></h2>
                                            <h3 class="h4">
                                                <?echo substr($g_tagline, 0, 72)?>.
                                            </h3>
                                            <?if($logged==0){?>
                                            <a href="./login.php" class="btn btn-primary mt-3">Get Started</a>
                                            <?}else{?>
                                            <?if($g_modules_global['enableEmployeeManagement'] && $session_role=="admin"){?>
                                            <a href="./employees.php" class="btn btn-primary mt-3">Manage Employees</a>
                                            <?}?>
                                            <?}?>
                                        </div>
                                    </div>

                                    <div class="col-md-3  mb-sm">
                                        <div class="hero-2-padding rounded shadow "
                                            style="height: 100%;background: #fff;border: 1px <?echo $g_primaryColor?> solid;">
                                            <h3>Hello
                                                <?if($session_name==""){?>Visitor
                                                <?}else{echo $session_name;}?>!
                                            </h3>


                                            <?if($logged==0){?>
                                            <h5 class="h6">Looks like you aren't looked in. Signup now to access the
                                                website.</h5>
                                            <a href="./login.php" class="mt-3 btn btn-outline-dark">Login</a>
                                            <?if(!checkGlobalPermission('signupEnabled')){?>
                                            <a href="./signup.php" class="btn btn-primary mt-3">Get Started</a>
                                            <?}?>
                                            <?}else{?>
                                            <h5 class="h6">Welcome to your fully Custom
                                                <?echo $g_projectTitle?> Portal. This CRM contains all the features that
                                                you need to run a successfull business, and which takes care of all your
                                                business needs.
                                            </h5>
                                            <a href="./?logout=1" class="mt-3 btn btn-outline-danger">Logout</a>
                                            <a href="<?if(!$g_modules_global['accountSettingsEnabled']){?>#<?}?>./settings.php"
                                                class="mt-3 btn btn-outline-secondary">Account Settings</a>
                                            <?}?>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="hero-2-padding bg-primary text-white rounded shadow"
                                            style="height: 50%;border: 1px <?echo $g_primaryColor?> solid;">
                                            <h3>
                                                <?echo date("D, d M Y")?>
                                            </h3>
                                            <h5 class="h6">Location:
                                                <?echo $_SESSION['location']?>
                                            </h5>
                                        </div>
                                        <a href="#nofifications"
                                            class="shadow rounded d-block hero-2-padding bg-secondary mt-3 text-dark"
                                            style="height: 45.5%;border: 1px <?echo $g_primaryColor?> solid;background:#f6fcff17 !important;backdrop-filter: blur(10px);">
                                            <h3>No new notifications.</h3>
                                            <h5 class="h6">Your inbox is empty. You have no new notifications.</h5>
                                        </a>
                                    </div>
                                </div>
                            </div>

                            <div class="alert alert-info">More features coming in upcoming sprints.</div>




                        </div>



                        <!-- end:: Content -->
                    </div>
                </div>

                <!-- begin:: Footer -->

                <?require("./includes/views/footer.php")?>

                <!-- end:: Footer -->
            </div>
        </div>
    </div>


    <?require("./includes/views/footerjs.php")?>


</body>

<!-- end::Body -->

</html>