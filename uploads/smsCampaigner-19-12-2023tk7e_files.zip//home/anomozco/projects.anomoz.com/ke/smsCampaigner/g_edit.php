<?
include_once("./global.php");

$table = $_GET['t'];
$row = $_GET['r'];
$id = $_GET['i'];
$id_value = $_GET['iv'];
$callback = $_GET['c'];

//echo $row;
    
if(isset($_POST['title'])){
    $title = trim($_POST['title']);
    
    $table = $_GET['t'];
    $row = $_GET['r'];
    $id = $_GET['i'];
    $id_value = $_GET['iv'];
    $callback = $_GET['c'];
    
    $sql="update $table set $row='$title' where $id='$id_value' ";
    //echo $sql;
        if(!mysqli_query($con,$sql))
        {
            echo "err";
            echo mysqli_error($con);
        }else{
        ?>
        <script type="text/javascript">
            window.location = "<?echo $callback;?>";
        </script>
        <?
    }
}
?>
<!DOCTYPE html>
<html>

<head>
 <?require("./includes/views/head.php")?>
 	  <link rel="stylesheet" href="article-editor.min.css" />

</head>

<body class="<?echo $g_body_class?>">
   
  <!-- Sidenav -->
  <?require("./includes/views/header.php")?>
        
  <!-- Main content -->
  <div class="main-content" id="panel">
    <!-- Topnav -->
    <!-- Header -->
    <!-- Header -->
    <form method="post" action="" enctype="multipart/form-data">
    <div class="header bg-primary pb-6">
      <div class="container-fluid">
        <div class="header-body">
          <div class="row align-items-center py-4">
            <div class="col-lg-6 col-7">
              <h6 class="h2 text-white d-inline-block mb-0">Edit Value</h6>
              
            </div>
            <?if($session_role=="admin" || $session_role=="teacher"){?>
                <div class="col-lg-6 col-5 text-right">
                  <input type="submit" value="Save" class="btn btn-md btn-neutral" />
                </div>
            <?}?>
            
          </div>
          <!-- Card stats -->
        </div>
      </div>
    </div>
    <!-- Page content -->
    <div class="container-fluid mt--6">
      <div class="row">
        <div class="col-xl-12 col-md-21 col-lg-12">
          <div class="card">
            <div class="card-header bg-transparent">
              <div class="row align-items-center">
                <div class="col">
                  <h5 class="h3 mb-0">Edit Value</h5>
                </div>
              </div>
            </div>
            <div class="card-body">
                
                    <?
                    $table = $_GET['t'];
                    $row = $_GET['r'];
                    $id = $_GET['i'];
                    $id_value = $_GET['iv'];
                    $callback = $_GET['c'];


                    $sql="select $row from $table where $id='$id_value' ";
                    $result = $con->query($sql);
                    if ($result->num_rows > 0){
                        while($row1 = $result->fetch_assoc()) 
                        {
                            $value = htmlentities($row1[$row]);
                        }
                    }
                    
                    //echo $value;
                    ?>
                  <div class="form-group">
                    <textarea type="text" name="title" class="form-control" id="exampleFormControlInput1" placeholder="New Value" required><?echo $value?></textarea>
                    
                    <button type="submit" class="btn btn-primary">Save</button>
                  </div>
           
            </div>
          </div>
        </div>
      </div>
      <!-- Footer -->
      <?include_once("./phpParts/footer.php")?>
    </div>
    </form>
  </div>
  <!-- Scripts -->
  <?include_once("./phpParts/footer-scripts.php")?>
  
  				
<script src="article-editor.min.js"></script>

<!-- call -->
<script>
ae = ArticleEditor("textarea",
{
    /*image: {
        upload: './image-upload.php'
    }*/
});
</script>		

</body>

</html>
