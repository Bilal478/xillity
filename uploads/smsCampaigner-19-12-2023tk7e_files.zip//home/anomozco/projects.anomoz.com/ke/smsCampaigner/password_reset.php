<?include_once("global.php");
 
$id = $_GET['id'];
$stmt = getAll($con, "select r.resetlinktimestamp, u.id, u.password, u.email from ".$g_projectSlug."_password_resets r inner join ".$g_projectSlug."_users u on r.email=u.email where r.passwordResetId='$id'");
$i=0;
foreach ($stmt as $row ) {
    $resetlinktimestamp = $row['resetlinktimestamp'];
    $password_old = $row['password'];
    $id = $row['id'];
    $i+=1;
}

if($i==0){
    // header("location: ./");
}

        

   

include("./includes/models/users.php");


?>
<!DOCTYPE html>

<html lang="en">

	<!-- begin::Head -->
	<head>
	    <?require("./includes/views/head.php")?>
		<link href="assets/css/pages/login/login-1.css" rel="stylesheet" type="text/css" />
		<style>
body { background: #efefef; }
            .password-strength-indicator
            {
                border: 1px solid transparent;
                border-radius: 3px;
                display: inline-block;
                min-height: 18px;
                min-width: 80px;
                text-align: center;
                padding: 5px 10px;
                color: #fff;
                margin-top: 30px;
            }

            .password-strength-indicator.very-weak
            {
                background: #cf0000;
                border-color: #a60000;
            }

            .password-strength-indicator.weak
            {
                background: #f6891f;
                border-color: #c56e19;
            }

            .password-strength-indicator.mediocre
            {
                background: #eeee00;
                border-color: #d6d600;
            }

            .password-strength-indicator.strong
            {
                background: #99ff33;
                border-color: #7acc29;
            }

            .password-strength-indicator.very-strong
            {
                background: #22cf00;
                border-color: #1B9900;
            }
            .container { margin: 150px auto; }
</style>
	</head>

	<!-- end::Head -->

	<!-- begin::Body -->
	<body class="kt-page--loading-enabled kt-page--loading kt-quick-panel--right kt-demo-panel--right kt-offcanvas-panel--right kt-header--fixed kt-header--minimize-menu kt-header-mobile--fixed kt-subheader--enabled kt-subheader--transparent kt-aside--enabled kt-aside--left kt-aside--fixed kt-page--loading">

		<!-- begin::Page loader -->

		<!-- end::Page Loader -->

		<!-- begin:: Page -->
		<div class="kt-grid kt-grid--ver kt-grid--root kt-page">
			<div class="kt-grid kt-grid--hor kt-grid--root  kt-login kt-login--v1" id="kt_login">
				<div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--desktop kt-grid--ver-desktop kt-grid--hor-tablet-and-mobile">

					<!--begin::Aside-->
					<?require("./includes/views/signupsidebar.php")?>

					<!--begin::Aside-->

					<!--begin::Content-->
					<div class="kt-grid__item kt-grid__item--fluid  kt-grid__item--order-tablet-and-mobile-1  kt-login__wrapper">

						<!--begin::Head-->
						<!--
						<div class="kt-login__head">
							<span class="kt-login__signup-label">Don't have an account yet?</span>&nbsp;&nbsp;
							<a href="./signup.php" class="kt-link kt-login__signup-link">Sign Up!</a>
						</div>
						-->

						<!--end::Head-->

						<!--begin::Body-->
						<div class="kt-login__body">

							<!--begin::Signin-->
							<div class="kt-login__form">
								<div class="kt-login__title">
									<h3>Password Reset</h3>
								</div>

								<!--begin::Form-->
								<form class="kt-form" action="" method="post" novalidate="novalidate" id="kt_login_form" >
								
									<div class="form-group">
										<input class="form-control" id="pass" type="password" placeholder="Password" name="password" autocomplete="off">
									</div>
									<div class="form-group">
										<input class="form-control" id="pass1" type="password" placeholder="Re-type Password" name="password1" autocomplete="off">
									</div>

									<!--begin::Action-->
									<div class="kt-login__actions">
									    
									
										<input type="submit" name="password_reset" value="Set" id="kt_login_signin_submit" class="btn btn-primary btn-elevate kt-login__btn-primary">
									</div>

									<!--end::Action-->
								</form>

								<!--end::Form-->

							

								<!--end::Divider-->

								<!--begin::Options
								<div class="kt-login__options">
									<a href="./signup.php" class="btn btn-primary kt-btn">
										Signup Now!
									</a>
								</div>
								-->

								<!--end::Options-->
							</div>

							<!--end::Signin-->
						</div>

						<!--end::Body-->
					</div>

					<!--end::Content-->
				</div>
			</div>
		</div>

		<!-- end:: Page -->

		<!-- begin::Global Config(global config for global JS sciprts) -->
		<script>
			var KTAppOptions = {
				"colors": {
					"state": {
						"brand": "#591df1",
						"light": "#ffffff",
						"dark": "#282a3c",
						"primary": "#5867dd",
						"success": "#34bfa3",
						"info": "#36a3f7",
						"warning": "#ffb822",
						"danger": "#fd3995"
					},
					"base": {
						"label": ["#c5cbe3", "#a1a8c3", "#3d4465", "#3e4466"],
						"shape": ["#f0f3ff", "#d9dffa", "#afb4d4", "#646c9a"]
					}
				}
			};
		</script>

		<!-- end::Global Config -->
		 <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js'></script>
                <script src='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.4.1/js/bootstrap.min.js'></script>

        
            <script src="https://www.jqueryscript.net/demo/inform-password-strength/jquery.passwordstrength.js"></script>
            <script>
    			$(function() {
    					$("#pass").passwordStrength();
    					$("#pass1").passwordStrength();
    			});
    		</script>
		

		<!--begin::Global Theme Bundle(used by all pages) -->
		<script src="assets/plugins/global/plugins.bundle.js" type="text/javascript"></script>
		<script src="assets/js/scripts.bundle.js" type="text/javascript"></script>

		<!--end::Global Theme Bundle -->

		<!--begin::Page Scripts(used by this page) -->

		<!--end::Page Scripts -->
	</body>

	<!-- end::Body -->
</html>