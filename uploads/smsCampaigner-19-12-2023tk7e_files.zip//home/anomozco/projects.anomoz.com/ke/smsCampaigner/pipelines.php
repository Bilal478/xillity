<?  require("./global.php");

$primaryTableName = "pipelines";

array(
	// field_name [type, isrequired, array_select, inner_type] <= "template"
	"pipeline_name" => ["input", "", "", "text"],
	"description" => ["input", "", "", "text"],
	"color" => ["input", "", "", "text"],


	// "document" => ["input", "", "", "file"],
);;

if(isset($_POST['create_package'])){
$timeAdded = time();
$actionId = escape(($_POST['actionId']));
$pipeline_name = escape($_POST['pipeline_name']);    
$description = escape($_POST['description']);    
$color = escape($_POST['color']);    
if($actionId==""){
	$id = generateRandomString();
	$actionId = $id;
	$query = "insert into ".$g_projectSlug."_pipelines set id='$id' , pipeline_name='$pipeline_name', description='$description', color='$color', timeAdded='$timeAdded', userId='$session_userId' ";
}else{
	$query = "update ".$g_projectSlug."_pipelines set id='$actionId' , pipeline_name='$pipeline_name', description='$description', color='$color' where id='$actionId'";
}
$stmt = $con->prepare($query);
if(!$stmt){echo "err: <code>$query</code>";}
if(!$stmt->execute()){echo "err: <code>$query</code>";}

$rStr = "";
if(isset($_GET['id'])){$rStr .=  "&id=".$_GET['id'];}
header("Location: ?m=Data was saved successfully!".$rStr);
}

if(isset($_GET['delete-record'])){
$id = escape($_GET['delete-record']);
if($id!="admin"){
	$stmt = $con->prepare("delete from ".$g_projectSlug."_pipelines where id=?");
	$stmt->bind_param("s", $id);
	if(!$stmt->execute()){echo "err";}
}
}


?>
<!DOCTYPE html>


<html lang="en">

	<!-- begin::Head -->
	<head><?require("./includes/views/head.php")?>
</head>

	<!-- end::Head -->

	<!-- begin::Body -->
	<body class="<?echo $g_body_class?>">

		<?require("./includes/views/header.php")?>
        
        	<div class="kt-grid kt-grid--hor kt-grid--root">
			<div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--ver kt-page">
				<div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-wrapper" id="kt_wrapper">

					<!-- begin:: Header -->
					
                    <?require("./includes/views/topmenu.php")?>
					<!-- end:: Header -->

					<!-- begin:: Aside -->
					<?require("./includes/views/leftmenu.php")?>

					<!-- end:: Aside -->
					<div class="kt-body kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-grid--stretch" id="kt_body">
						<div class="kt-content  kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor" id="kt_content">

							<!-- end:: Subheader -->

							<!-- begin:: Content -->
							<div class="kt-container  kt-grid__item kt-grid__item--fluid">
							    
							    <?if(isset($_GET['m'])){?>
							        <div class="alert alert-info"><?echo $_GET['m']?></div>
							    <?}?>

								<div class="kt-portlet kt-portlet--mobile">
									<div class="kt-portlet__head kt-portlet__head--lg">
										<div class="kt-portlet__head-label">
											<span class="kt-portlet__head-icon">
											</span>
											<h3 class="kt-portlet__head-title">
												<?echo ucfirst($primaryTableName)?>
											</h3>
										</div>
										<div class="kt-portlet__head-toolbar">
											<div class="kt-portlet__head-wrapper">
												<div class="kt-portlet__head-actions">
												    
												    <?renderImportExportButtons();?>
												    
													<a href="#" class="btn btn-brand btn-elevate btn-icon-sm" data-toggle="modal" data-target="#create_record_modal">
														<i class="fa fa-plus"></i>
														New Record
													</a>
															
												</div>
											</div>
										</div>
									</div>
									<div class="kt-portlet__body">
                                        <form action="" method="post">
                                            <?if(checkGlobalPermission('g_enableBulkDelete')){?>
                                                <button type="button" class="btn btn-info btn-sm text-white " onclick="selectAll();">Select All</button>
                                                <button type="submit"  class="btn btn-danger btn-sm text-white ">Delete Bulk</button>
                                            <?}?>
    										<!--begin: Datatable -->

											<table class="table table-striped- table-bordered table-hover table-checkable add-search" >
											    <thead>
											        <tr>
											            <th>Pipeline name</th>
											            <th>Description</th>
											            <th>Color</th>
											            <th>Actions</th>
											        </tr>
											    </thead>
											    <tbody>
											    <?php  $query = "select * from ".$g_projectSlug."_pipelines t where t.userId like '%$session_userId_filter%' order by t.timeAdded desc";
											    $results = getAll($con, $query);
											        foreach($results as $row){?>
											            <tr>
											                <td><?php echo $row['pipeline_name']?></td>
											                <td><?php echo $row['description']?></td>
											                <td><div style="background-color: <?php echo $row['color']?>; height:15px; width:15px; border:1px solid black;" ></div></td>
											                <td >
											                        <div class="btn-group">
											                            <a href="#" class="btn btn-warning" data-toggle="modal" data-target="#create_record_modal" data-mydata='<?php echo  htmlspecialchars(json_encode($row, JSON_UNESCAPED_UNICODE));?>' >Edit</a>
											                            <a href="#" class="btn btn-danger" data-toggle="modal" data-target="#delete_record" data-url="?<?echo generateUrlParams()?>delete-record=<?php echo $row['id']?>">Delete</a>
											                        </div>
											                </td>
											            </tr>
											        <?php }?>
											    </tbody>
											</table>


                                        </form>
										<!--end: Datatable -->
									</div>
								</div>
							
							
							</div>


							<!-- end:: Content -->
						</div>
					</div>

					<!-- begin:: Footer -->
					
					<?require("./includes/views/footer.php")?>

					<!-- end:: Footer -->
				</div>
			</div>
		</div>

        <?require("./includes/views/footerjs.php")?>

	</body>

	<!-- end::Body -->
	
	<div class="modal fade" id="create_record_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="modelTitle">Insert</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					</button>
				</div>
				<div class="modal-body">
					
					<form class="kt-form" action="" method="Post" enctype="multipart/form-data">
						<div class="kt-portlet__body">
						    
								<!-- modal -->

								<div>
								<div class="form-group">
								    <label>Pipeline name</label>
								    <input type="text" name="pipeline_name" class="form-control"   >
								</div>

								<div class="form-group">
								    <label>Description</label>
								    <input type="text" name="description" class="form-control"   >
								</div>

								<div class="form-group">
								    <label>Color</label>
								    <input type="color" name="color" class="form-control"   >
								</div>

								<input type="text" name="actionId" value="" hidden>

								</div>
							
						</div>
						<div class="kt-portlet__foot">
							<div class="kt-form__actions">
								<input type="submit" name="create_package" value="Submit" class="btn btn-primary">
								<button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
							</div>
						</div>
					</form>
				</div>
			
			</div>
		</div>
	</div>
	
	
	<script>
	$(document).ready(function(){
	      

          $("#create_record_modal").on('show.bs.modal', function (e) {
            var mydata = $(e.relatedTarget).data('mydata');
            console.log("mydata->",mydata);
            $("input[type='checkbox']").prop('checked', false);
            if(mydata!= null){
            	$("#modelTitle").html("Update");            	
                $("input[name='pipeline_name']").val(mydata['pipeline_name'])                
                $("input[name='description']").val(mydata['description'])                
                $("input[name='color']").val(mydata['color'])                                
                $("input[name='actionId']").val(mydata['id'])
            }else{
                $("#modelTitle").html("Insert");
                $("input[name='pipeline_name']").val("")
                $("input[name='description']").val("")
                $("input[name='color']").val("")
            
                $("input[name='actionId']").val("")
            }
        });
    })
</script>
				
		
								
</html>