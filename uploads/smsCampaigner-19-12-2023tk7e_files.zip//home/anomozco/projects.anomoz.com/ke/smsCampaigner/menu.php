<?require("./global.php");

$icons = [
    'all_functions' => 'la la-cogs',
    'analytics' => 'la la-chart-bar',
    'api' => 'la la-code',
    'assets' => 'la la-image',
    'attendance' => 'la la-calendar-check',
    'calendar_reminders' => 'la la-bell',
    'campaignView' => 'la la-bullhorn',
    'campaigns' => 'la la-bullhorn',
    'chatGPT' => 'la la-comments',
    'coupons' => 'la la-tags',
    'cronjob_campaign' => 'la la-clock',
    'cronjob_email' => 'la la-clock',
    'crud' => 'la la-database',
    'cruds' => 'la la-database',
    'customer_fields' => 'la la-users',
    'customers' => 'la la-users',
    'database' => 'la la-database',
    'email_inbox' => 'la la-envelope',
    'email_servers' => 'la la-server',
    'embed_lead_form' => 'la la-code',
    'employee_schedule' => 'la la-calendar',
    'employees' => 'la la-user',
    'files_storage' => 'la la-folder',
    'forget_password' => 'la la-lock',
    'formpage' => 'la la-clipboard',
    'g_edit' => 'la la-edit',
    'getEmails' => 'la la-envelope',
    'global' => 'la la-globe',
    'home' => 'la la-home',
    'index' => 'la la-list',
    'inventory_action' => 'la la-boxes',
    'invoices' => 'la la-file-invoice',
    'knowledge_base' => 'la la-book',
    'lead_generation' => 'la la-handshake',
    'leads' => 'la la-user-plus',
    'leave_manager' => 'la la-calendar-times',
    'login' => 'la la-sign-in-alt',
    'mailbox' => 'la la-inbox',
    'menu' => 'la la-bars',
    'messages' => 'la la-comments',
    'newPermission' => 'la la-user-lock',
    'newsletters' => 'la la-newspaper',
    'notifications' => 'la la-bell',
    'orders' => 'la la-shopping-cart',
    'password_reset' => 'la la-key',
    'payment' => 'la la-money-bill',
    'payment_webook' => 'la la-money-bill-wave',
    'pdf' => 'la la-file-pdf',
    'permission' => 'la la-user-lock',
    'permission_data' => 'la la-lock-open',
    'pipelines' => 'la la-tasks',
    'pricing' => 'la la-dollar-sign',
    'print' => 'la la-print',
    'products' => 'la la-shopping-bag',
    'project_view' => 'la la-project-diagram',
    'projects' => 'la la-folder-open',
    'questionnaires' => 'la la-question',
    'questionnaires_questions' => 'la la-question-circle',
    'questionnaires_submit' => 'la la-clipboard-check',
    'referrals' => 'la la-share',
    'responses' => 'la la-comments',
    'settings' => 'la la-cog',
    'signup' => 'la la-user-plus',
    'tasks' => 'la la-tasks',
    'test' => 'la la-flask',
    'tickets' => 'la la-ticket-alt',
    'time_tracker' => 'la la-stopwatch',
    'update_pipeline' => 'la la-tasks',
    'view_order' => 'la la-file-invoice',
    'view_pipeline' => 'la la-tasks',
    'view_user' => 'la la-user-circle',
    'webview' => 'la la-globe',
    'widget' => 'la la-puzzle-piece',
];


?>
<!DOCTYPE html>

<html lang="en">
    <!-- begin::Head -->
    <head>
        <?require("./includes/views/head.php")?>
        <style>

        .kt-header-menu .kt-menu__nav > .kt-menu__item {
            white-space: pre;
        }
        .col-lg-2{
            padding:5px;
            height:120px;
        }
        .col-lg-2:hover {
          background: #F5F6FC;
          /*color: #fff !important;*/
          /*border: 1px #c8c5c5 solid;*/
          box-shadow: 0 4px 4px 0 rgba(0, 0, 0, 0.11), 0 6px 4px 0 rgba(0, 0, 0, 0.19);
        }
        
        a {
            color: #4b5173;
        }
        .kt-menu__link-text{
            font-size: 16px;
        }
            
        </style>
        
    </head>

    <!-- end::Head -->

    <!-- begin::Body -->
    <body class="<?echo $g_body_class?>" onload="">
        <?require("./includes/views/header.php")?>

        <div class="kt-grid kt-grid--hor kt-grid--root">
            <div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--ver kt-page">
                <div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-wrapper" id="kt_wrapper">
                    <!-- begin:: Header -->

                    <?require("./includes/views/topmenu.php")?>
                    <!-- end:: Header -->

                    <!-- begin:: Aside -->
                    <?require("./includes/views/leftmenu.php")?>

                    <!-- end:: Aside -->
                    <div class="kt-body kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-grid--stretch" id="kt_body">
                        <div class="kt-content kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor" id="kt_content">
                            <!-- end:: Subheader -->

                            <!-- begin:: Content -->
                            <div class="kt-container kt-grid__item kt-grid__item--fluid">
                                <!--if exported-->
                              

                                <?if(isset($_GET['m'])){?>
                                <div class="alert alert-info"><?echo $_GET['m']?></div>
                                <?}?>

                            
                                <br>
                                <div class="row bg-white rounded-0 m-0 shadow-sm">
                                    <div class="col-lg-12 col-xl-12" style="text-align:center;">
                                        <div class="p-4">
                                            <div class="row">

                                               
                                               
                                                <?foreach($menuItems as $menuItem){?>
                                                    <a href="./<?echo $menuItem[0]?>" class="col-lg-2 mb-4 kt-menu__link">
                                                        <div class="">
                                                            <br>
                                                            <!--&#xf124;-->
                                                            <h6 class="font-weight-bold text-uppercase"><i style="font-size:24px" class="<?echo $icons[str_replace(".php","",$menuItem[0])]?>"></i></h6>
                                                            <ul class="list-unstyled">
                                                                <li class="kt-menu__item <?if($filenameLink==$menuItem[0]){echo 'kt-menu__item--here';}?>" data-ktmenu-submenu-toggle="click" aria-haspopup="true">
                                                                    <span class="kt-menu__link-text"><?echo $menuItem[1]?></span>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </a>
                                                <?}?>
                                                
                                               
                                              
                                            </div>
                                        </div>


                                    



                                        



                                    </div>

                                    <!-- end:: Content -->
                                </div>
                            </div>

                            <!-- begin:: Footer -->

                            <?require("./includes/views/footer.php")?>

                            <!-- end:: Footer -->
                        </div>
                    </div>
                </div>

                <?require("./includes/views/footerjs.php")?>

                <!-- end::Body -->
            </div>
        </div>
    </body>
</html>
