<?php
require("./global.php");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $actionId = $_POST['actionId'];

    // Perform a query to fetch data from keynote_history based on company_id
    $query = "SELECT * FROM limitedMinds_keynote_history WHERE company_id = '$actionId'";
    $result = getAll($con, $query);
    foreach ($result as $row) {
       echo $row['date'];
    }

   
}
?>
