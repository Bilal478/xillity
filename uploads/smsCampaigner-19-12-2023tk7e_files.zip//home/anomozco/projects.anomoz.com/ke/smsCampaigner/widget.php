<?require("./global.php"); //can be removed if needed

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Include any necessary head content -->
    <?php require("./includes/views/head.php") ?>
    <style>
        /* Add CSS styling here */
        .search-container {
            display: flex;
            align-items: center;
        }

        .search-input {
            padding: 5px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .search-button {
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .search-button:hover {
            background-color: #45a049;
        }
    </style>
    
    <style>
    @import url("https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700&display=swap");
  
	.card {
	  width: 400px;
	  height: 180px;
	  border-radius: 15px;
	  box-shadow: 0 4px 6px 0 rgba(0, 0, 0, 0.2);
	  background-color: <?echo $g_primaryColor?>;
	  padding: 10px 10px;
	  position: relative;
	}

	.main,
	.copy-button {
	  display: flex;
	  justify-content: space-between;
	  padding: 0 10px;
	  align-items: center;
	}
	.card::after {
	  position: absolute;
	  content: "";
	  height: 40px;
	  right: -20px;
	  border-radius: 40px;
	  z-index: 1;
	  top: 70px;
	  background-color:#F9F9FC;
	  width: 40px;
	}

	.card::before {
	  position: absolute;
	  content: "";
	  height: 40px;
	  left: -20px;
	  border-radius: 40px;
	  z-index: 1;
	  top: 70px;
	  background-color: #F9F9FC;
	  width: 40px;
	}

	.co-img img {
	  width: 100px;
	  height: 100px;
	}
	.vertical {
	  border-left: 5px dotted #fff;
	  height: 100px;
	  position: absolute;
	  left: 40%;
	}

	.content h1 {
	  font-size: 35px;
	  margin-left: -10px;
	  color: #fff;
	}

	.content h1 span {
	  font-size: 15px;
	}
	.content h2 {
	  font-size: 22px;
	  margin-left: -10px;
	  color: #fff;
	  text-transform: uppercase;
	}

	.content p {
	  font-size: 10px;
	  color: #fff;
	  margin-left: -10px;
	}

	.copy-button {
	  margin: 12px 0 -5px 0; 
	  height: 45px;
	  border-radius: 10px;
	  padding: 0 5px;
	  border: 1px solid #e1e1e1;
	}

	.copy-button input {
	  width: 100%;
	  height: 100%;
	  border: none;
	  outline: none;
	  font-size: 15px;
	}

	.copy-button button {
	  padding:2px 20px;
	  width:100%;
	  /*background-color: #FFC900;*/
	  color: #fff;
	  border: 1px solid transparent;
	  border-radius: 5px;

	}

	.toast {
            background-color: <?echo $g_primaryColor?> !important;
        }

        /* Set the text color of the toast to white */
        .toast-title,
        .toast-message {
            color: #fff !important;
        }

    </style>
</head>

<body class="<?php echo $g_body_class ?>">
    <?php require("./includes/views/header.php") ?>

    <div class="kt-grid kt-grid--hor kt-grid--root">
        <div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--ver kt-page">
            <div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-wrapper" id="kt_wrapper">
                <!-- Header -->
                <?php require("./includes/views/topmenu.php") ?>

                <!-- Aside -->
                <?php require("./includes/views/leftmenu.php") ?>

                <div class="kt-body kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-grid--stretch" id="kt_body">
                    <div class="kt-content  kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor" id="kt_content">
                        <div class="kt-container  kt-grid__item kt-grid__item--fluid">
                            <?php if (isset($_GET['m'])) { ?>
                                <div class="alert alert-info"><?php echo $_GET['m'] ?></div>
                            <?php } ?>

                            <div class="container1 mb-2">
								<div class="card">
									<div class="main">
										<div class="co-img">
											<img src="<?echo $g_modules_global['logo']?>" alt="" style="object-fit: contain;">
										</div>
										<div class="vertical"></div>
										<div class="content">
											<h2><?echo $g_projectTitle?>⚡</h2>
											<h1><span>Integrate Property Listing</span></h1>
											<p> CLICK BELOW BUTTON!</p>
										</div>
									</div>
									 <code class="d-none" id="codeSnippet"><?php echo htmlentities('<iframe style="width:100%;height:100%;min-height:800px;border:none;" src="'.$g_website.'/embed_properties.php"></iframe>');?></code>
									<div class="copy-button"> 
										<button  onclick="copyCodeToClipboard()" class="copybtn btn btn-light text-dark ">COPY CODE</button>
									</div>
								</div> 
							</div>
            									
            									
                        </div>
                    </div>
                </div>
                <!-- Footer -->
                <?php require("./includes/views/footer.php") ?>
            </div>
        </div>
    </div>

    <!-- Include any necessary footer JS scripts -->
    <?php require("./includes/views/footerjs.php") ?>
        
        
     <!-- Toastr CSS CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css">
    
    <!-- Toastr JavaScript CDN -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
    
    <script>
        function copyCodeToClipboard() {
            /* Get the text of the code snippet */
            var codeSnippet = document.getElementById('codeSnippet');
            var codeText = codeSnippet.innerText || codeSnippet.textContent;
    
            /* Create a temporary text area and copy the code to it */
            var tempTextArea = document.createElement('textarea');
            tempTextArea.value = codeText;
            document.body.appendChild(tempTextArea);
    
            /* Select and copy the text from the text area */
            tempTextArea.select();
            document.execCommand('copy');
    
            /* Remove the temporary text area */
            document.body.removeChild(tempTextArea);
    
            /* Show a Toastr notification */
            toastr.success('Code copied to clipboard', 'Success', {
                closeButton: true,
                progressBar: true,
            });
        }
    </script>

</body>

</html>