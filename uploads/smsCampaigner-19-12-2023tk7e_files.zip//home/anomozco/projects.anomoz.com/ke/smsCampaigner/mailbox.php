<?require("./global.php");


?>
<!DOCTYPE html>

<html lang="en">

	<!-- begin::Head -->
	<head>
		<?require("./includes/views/head.php")?>
		<link href="assets/css/pages/inbox/inbox.css" rel="stylesheet" type="text/css" />
		<style>
		    .kt-inbox .kt-inbox__list .kt-inbox__items .kt-inbox__item .kt-inbox__datetime {
    width: 270px;
}
		</style>
	</head>

	<!-- end::Head -->

		<body class="<?echo ""?>" onload="">

		<?require("./includes/views/header.php")?>
        
        	<div class="kt-grid kt-grid--hor kt-grid--root">
			<div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--ver kt-page">
				<div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-wrapper" id="kt_wrapper">

					<!-- begin:: Header -->
					
                    <?require("./includes/views/topmenu.php")?>
					<!-- end:: Header -->

					<!-- begin:: Aside -->
					<?require("./includes/views/leftmenu.php")?>

					<!-- end:: Aside -->

					<div class="kt-body kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-grid--stretch" id="kt_body">
						<div class="kt-content  kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor" id="kt_content">

							<!-- begin:: Content -->
							<div class="kt-container  kt-grid__item kt-grid__item--fluid">

								<!--Begin::Inbox-->
								<div class="kt-grid kt-grid--desktop kt-grid--ver-desktop  kt-inbox" id="kt_inbox">

									<!--Begin::Aside Mobile Toggle-->
									<button class="kt-inbox__aside-close" id="kt_inbox_aside_close">
										<i class="la la-close"></i>
									</button>

									<!--End:: Aside Mobile Toggle-->

									<!--Begin:: Inbox Aside-->
									<div class="kt-grid__item   kt-portlet  kt-inbox__aside" id="kt_inbox_aside">
										<!--<button type="button" class="btn btn-brand  btn-upper btn-bold  kt-inbox__compose" data-toggle="modal" data-target="#kt_inbox_compose">new message</button>-->
										<div class="kt-inbox__nav">
											<ul class="kt-nav">
											    <?
													$query= "select * from ".$g_projectSlug."_email_servers where userId='$session_userId'";
													$result = $con->query($query);
													while($row = $result->fetch_assoc()){
												?>
												<li class="kt-nav__item kt-nav__item--active">
													<a href="?serverId=<?echo $row['id']?>" class="kt-nav__link" >
														<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px" height="24px" viewBox="0 0 24 24" version="1.1" class="kt-svg-icon kt-nav__link-icon">
															<g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
																<rect x="0" y="0" width="24" height="24" />
																<path d="M6,2 L18,2 C18.5522847,2 19,2.44771525 19,3 L19,13 C19,13.5522847 18.5522847,14 18,14 L6,14 C5.44771525,14 5,13.5522847 5,13 L5,3 C5,2.44771525 5.44771525,2 6,2 Z M13.8,4 C13.1562,4 12.4033,4.72985286 12,5.2 C11.5967,4.72985286 10.8438,4 10.2,4 C9.0604,4 8.4,4.88887193 8.4,6.02016349 C8.4,7.27338783 9.6,8.6 12,10 C14.4,8.6 15.6,7.3 15.6,6.1 C15.6,4.96870845 14.9396,4 13.8,4 Z" fill="#000000" opacity="0.3" />
																<path d="M3.79274528,6.57253826 L12,12.5 L20.2072547,6.57253826 C20.4311176,6.4108595 20.7436609,6.46126971 20.9053396,6.68513259 C20.9668779,6.77033951 21,6.87277228 21,6.97787787 L21,17 C21,18.1045695 20.1045695,19 19,19 L5,19 C3.8954305,19 3,18.1045695 3,17 L3,6.97787787 C3,6.70173549 3.22385763,6.47787787 3.5,6.47787787 C3.60510559,6.47787787 3.70753836,6.51099993 3.79274528,6.57253826 Z" fill="#000000" />
															</g>
														</svg> <span class="kt-nav__link-text"><? echo $row['email']; ?></span>
														<!--<span class="kt-nav__link-badge">
															<span class="kt-badge kt-badge--unified-success kt-badge--md kt-badge--rounded kt-badge--boldest">3</span>
														</span>-->
													</a>
												</li>
											
												<?
													}
												?>
											</ul>
										</div>
									</div>

									<!--End::Aside-->

									<!--Begin:: Inbox List-->
									<div class="kt-grid__item kt-grid__item--fluid    kt-portlet    kt-inbox__list kt-inbox__list--shown" id="kt_inbox_list">
										<div class="kt-portlet__body kt-portlet__body--fit-x">
											<div class="kt-inbox__items" data-type="inbox">
											    <?
											        $serverId = $_GET['serverId'];
													$query= "select * from ".$g_projectSlug."_emails where server_id like '%$serverId%' and userId = '$session_userId'";
													$result = $con->query($query);
													while($row = $result->fetch_assoc()){
												?>
												<div class="kt-inbox__item" data-type="inbox" onclick="window.location='./view_email.php?id=<?echo $row['id']?>'">
												    <a href="./view_email.php?id=<?echo $row['id']?>">
    													<div class="kt-inbox__info">
    														<div class="kt-inbox__sender">
    															<span class="kt-media kt-media--sm kt-media--brand">
    																<span><?echo substr($row['from_email'], 0, 1)?></span>
    															</span>
    															<a href="./view_email.php?id=<?echo $row['id']?>" class="kt-inbox__author"><?echo ($row['from_email'])?></a>
    														</div>
    													</div>
    													<div class="kt-inbox__details">
    														<div class="kt-inbox__message">
    															<span class="kt-inbox__subject"><?echo $row['subject']?></span>
    															<span class="kt-inbox__summary"><?echo $row['message']?></span>
    														</div>
    													</div>
    													<div class="kt-inbox__datetime">
    														<?echo $row['date']?>
    													</div>
													</a>
												</div>
												<?}?>

											</div>
										</div>
									</div>

									<!--End:: Inbox List-->

									<!--Begin:: Inbox View-->
									

									<!--End:: Inbox View-->
								</div>

								<!--End::Inbox-->

								<!--Begin:: Inbox Compose-->

								<!--End:: Inbox Compose-->
							</div>

							<!-- end:: Content -->
						</div>
					</div>

					<!-- begin:: Footer -->


					<!-- end:: Footer -->
				</div>
			</div>
		</div>

		<!-- end:: Page -->

		<!-- begin::Scrolltop -->
		<div id="kt_scrolltop" class="kt-scrolltop">
			<i class="fa fa-arrow-up"></i>
		</div>

		<!-- end::Scrolltop -->

		<!-- begin::Sticky Toolbar -->


		<!-- end::Sticky Toolbar -->

		<!-- begin::Demo Panel -->


		<!-- end::Demo Panel -->

		<!--Begin:: Chat-->


		<!--ENd:: Chat-->

		<!-- begin::Global Config(global config for global JS sciprts) -->
		<script>
			var KTAppOptions = {
				"colors": {
					"state": {
						"brand": "#591df1",
						"light": "#ffffff",
						"dark": "#282a3c",
						"primary": "#5867dd",
						"success": "#34bfa3",
						"info": "#36a3f7",
						"warning": "#ffb822",
						"danger": "#fd3995"
					},
					"base": {
						"label": ["#c5cbe3", "#a1a8c3", "#3d4465", "#3e4466"],
						"shape": ["#f0f3ff", "#d9dffa", "#afb4d4", "#646c9a"]
					}
				}
			};
		</script>

	

        <?require("./includes/views/footerjs.php")?>

	</body>

	<!-- end::Body -->
</html>