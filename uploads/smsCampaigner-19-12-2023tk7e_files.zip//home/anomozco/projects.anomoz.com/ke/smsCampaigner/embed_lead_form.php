<?  require("./global.php");

// if(!checkGlobalPermission('enableCustomerManagement')){header("Location: ./home.php?m=Oops! Error occured");}

$primaryTableName = "users";

$login_fields_hidden = "";
if(!checkGlobalPermission('enableCustomerToLogin')){
    $login_fields_hidden = "hidden";
}
$arrayFields_crud = array(
    // field_name [type, isrequired, array_select, inner_type, small_comment] <= "template"
    "name" => ["input", "required", "", "text", ""],
    "email" => ["input", "required", "", "email", ""],
    "phone" => ["input", "required", "", "text", ""],
    "role" => ["input", "required hidden value='customer'", "", "text", ""],
    "addedBy" => ["input", "required hidden value='$session_userId'", "", "text", ""],
);
if(checkGlobalPermission('enablePipelineManagement') && false){
    $stages = [];
    $temp = getAll($con, "select * from ".$g_projectSlug."_"."pipelines"." order by timeAdded desc");
    foreach($temp as $row){$stages[$row['id']] = $row['pipeline_name'];}
    $arrayFields_crud["current_pipeline_stage"] =  ["select", "", $stages, "text", ""];
}

//for generating table generation queries
if(false){
    $t = "DROP TABLE IF EXISTS ".$g_projectSlug."_".$primaryTableName."; CREATE TABLE ".$g_projectSlug."_users(<br>id VARCHAR(200) PRIMARY KEY,<br>";
    foreach($arrayFields_crud as  $col => $info){
        $t.= "$col VARCHAR(256) DEFAULT '' ,<Br>";
    }
    $t.= "timeAdded VARCHAR(256) NULL,<br>userId VARCHAR(256) NULL);";
    echo "<code>$t</code>";
}

//for insert & update
if(isset($_POST['create_package'])){
    $timeAdded = time();
    $actionId = mb_htmlentities(($_POST['actionId']));
    $files_array = [];
	$queryExtra = '';
	
	if(isset($_POST['password'])){
	    $email = $_POST['email'];
	    $password = $_POST['password'];
	    $_POST['password'] = mb_htmlentities( md5(md5(sha1( $_POST['password'])).'Anomoz')); 
	}
	
	foreach($arrayFields_crud as  $col => $info){
	    //for text
	    if(!in_array($info[3], ["image", "file"])){
    	    $val = mb_htmlentities($_POST[$col]);
    	    if($val!='' && $val!=NULL){
    	        $queryExtra.= ", $col='".$val."' ";
    	    }
	    }else{
	        //for images
	        if(isset($_FILES[$col])){
                $files_array[$col] = storeFile($_FILES[$col]); 
            }
	    }
	}

    $timeAdded = time();
    $id = generateRandomString();
    if($actionId==""){
        $actionId = $id;
        $query = "insert into ".$g_projectSlug."_".$primaryTableName." set id='$id' $queryExtra, timeAdded='$timeAdded', userId='$session_userId', source='landing page' ";
        
        
        $stmt = $con->prepare($query);
        if(!$stmt){echo "err: <code>$query</code>";}
        if(!$stmt->execute()){echo "err: <code>$query</code>";}
        
        if(false){
        $desc = "Hi! Your account has been created. Here are your credentials:<br>
URL: $g_website<br>            
Email: $email<br>            
Password: $password<br>            
";
        sendEmailNotification_mailjet("Account Created", $desc, $_POST['email']);
        }
        
    }else{
        //update
        $query = "update ".$g_projectSlug."_".$primaryTableName." set id='$actionId' $queryExtra where id='$actionId'";
        $stmt = $con->prepare($query);
        if(!$stmt){echo "err: <code>$query</code>";}
        if(!$stmt->execute()){echo "err: <code>$query</code>";}
    }
    
    //update files
    foreach($files_array as $col => $file){
        $stmt = $con->prepare("update ".$g_projectSlug."_".$primaryTableName." set $col='$file' where id='$actionId'");
        if(!$stmt){echo "err: <code>$query</code>";}
        if(!$stmt->execute()){echo "err: <code>$query</code>";}
    }

    if($g_redirectHomeOnSave){
        header("Location: ./home.php?m=Data was saved successfully!");
    }else{
        header("Location: ?m=Data was saved successfully!");
    }
    
}

if(isset($_GET['delete-record'])){
    $id = mb_htmlentities($_GET['delete-record']);
    if($id!="admin"){
        $stmt = $con->prepare("delete from ".$g_projectSlug."_".$primaryTableName." where id=?");
        $stmt->bind_param("s", $id);
        if(!$stmt->execute()){echo "err";}
    }
}

if(checkGlobalPermission('enableBulkDelete')){
    if(isset($_POST['delete_bulk'])){
        $del  = "('".implode("', '", $_POST['delete_bulk'])."')";
        $sql="delete from ".$g_projectSlug."_".$primaryTableName." where id in $del";
        if(!mysqli_query($con,$sql))
        {
            echo"can not";
        }
    }

}


?>
<!DOCTYPE html>


<html lang="en">

	<!-- begin::Head -->
	<head><?require("./includes/views/head.php")?>
</head>

	<!-- end::Head -->

	<!-- begin::Body -->
	<body class="<?echo $g_body_class?>">


        	<div class="kt-grid kt-grid--hor kt-grid--root">
			<div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--ver kt-page">
				<div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-wrapper" id="kt_wrapper">


					<!-- end:: Aside -->
					<div class="kt-body kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-grid--stretch" id="kt_body">
						<div class="kt-content  kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor" id="kt_content">

							<!-- end:: Subheader -->

							<!-- begin:: Content -->
							<div class="kt-container  kt-grid__item kt-grid__item--fluid">
							    
							    <?if(isset($_GET['m'])){?>
							        <div class="alert alert-info"><?echo $_GET['m']?></div>
							    <?}?>




								<div class="kt-portlet kt-portlet--mobile mx-auto" style="max-width:600px;">
									<!--<div class="kt-portlet__head kt-portlet__head--lg">-->
									<!--	<div class="kt-portlet__head-label">-->
									<!--		<span class="kt-portlet__head-icon">-->
									<!--		</span>-->
									<!--		<h3 class="kt-portlet__head-title">-->
									<!--			Send Message.-->
									<!--		</h3>-->
									<!--	</div>-->
									<!--	<div class="kt-portlet__head-toolbar">-->
										
									<!--	</div>-->
									<!--</div>-->
									<div class="kt-portlet__body">
                                        <form class="kt-form" action="" method="Post" enctype="multipart/form-data">
						<div class="kt-portlet__body">
						    
						    <!-- modal -->

<?foreach($arrayFields_crud as $col => $info){?>
						    <div class="form-group">
						        <?if(strpos($info[1], "hidden")==false){?>
								    <label><?echo ucfirst(str_replace("_", " ", $col))?></label>
								    <?if($info[4]!=""){?>
								        <small><?echo $info[4]?></small>
								    <?}?>
								<?}?>
								<?if($info[0]=="input" && in_array($info[3], ["text", "email", "password", "number", "file"])){?>
								    <input type="<?echo $info[3]?>" name="<?echo $col?>" class="form-control" <?echo $info[1]?>  >
								<?}else if($info[0]=="select"){?>
								    <select name="<?echo $col?>" class="form-control" <?echo $info[1]?>  >
    								    <?foreach($info[2] as $i=> $option){?>
    								        <option value="<?echo $i?>"><?echo $option?></option>
    								    <?}?>
								    </select>
								<?}else if($info[0]=="input" && in_array($info[3], ["image"])){?>
								    <input type="file" name="<?echo $col?>" class="form-control" <?echo $info[1]?>  >
								<?}else if($info[0]=="textarea"){?>
								    <textarea type="text" name="<?echo $col?>" class="form-control" <?echo $info[1]?>  ></textarea>
								<?}else{?>
								    <code><?echo $col?> Couldn't render</code>
								<?}?>
							</div>
							<?}?>
						
							<input type="text" name="actionId" value="" hidden>
							
						</div>
						<div class="kt-portlet__foot">
							<div class="kt-form__actions">
								<input type="submit" name="create_package" value="Submit" class="btn btn-primary">
							</div>
						</div>
					</form>
										<!--end: Datatable -->
									</div>
								</div>
							
							
							</div>


							<!-- end:: Content -->
						</div>
					</div>

					<!-- begin:: Footer -->
					

					<!-- end:: Footer -->
				</div>
			</div>
		</div>

	</body>


								
</html>