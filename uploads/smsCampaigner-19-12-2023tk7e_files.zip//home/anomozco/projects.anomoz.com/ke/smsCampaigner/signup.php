<?include_once("global.php");

include("./includes/models/users.php");

$role = 'user';

if(!checkGlobalPermission('signupEnabled')){
    header("Location: ./");
}

?>
<!DOCTYPE html>

<html lang="en">

	<!-- begin::Head -->
	<head>
	    <?require("./includes/views/head.php")?>
		<link href="assets/css/pages/login/login-1.css" rel="stylesheet" type="text/css" />
	</head>
	
	<?require("./includes/views/header.php")?>
	
    <!-- begin:: Header -->
    <?require("./includes/views/topmenu.php")?>
	<!-- end:: Header -->

	<!-- begin:: Aside -->
	<?//require("./includes/views/leftmenu.php")?>

	<!-- begin::Body -->
	<body class="kt-page--loading-enabled kt-page--loading kt-quick-panel--right kt-demo-panel--right kt-offcanvas-panel--right kt-header--fixed kt-header--minimize-menu kt-header-mobile--fixed kt-subheader--enabled kt-subheader--transparent kt-aside--enabled kt-aside--left kt-aside--fixed kt-page--loading">

		<!-- begin::Page loader -->

		<!-- end::Page Loader -->

		<!-- begin:: Page -->
		<div class="kt-grid kt-grid--ver kt-grid--root kt-page">
			<div class="kt-grid kt-grid--hor kt-grid--root  kt-login kt-login--v1" id="kt_login">
				<div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--desktop kt-grid--ver-desktop kt-grid--hor-tablet-and-mobile">

					<!--begin::Aside-->
					<?require("./includes/views/signupsidebar.php")?>

					<!--begin::Aside-->

					<!--begin::Content-->
					<div class="kt-grid__item kt-grid__item--fluid  kt-grid__item--order-tablet-and-mobile-1  kt-login__wrapper">

						
						<!--begin::Body-->
						<div class="kt-login__body mt-5 pt-1">

							<!--begin::Signin-->
							<div class="kt-login__form">
							    
							    <div class="kt-portlet kt-portlet--mobile p-4 border border-primary">
    								<div class="kt-login__title">
    								    
    								    <img src="<?echo $g_modules_global['logo']?>" height="90px" class=""></span>
    								    <h1 class="mt-3"><strong><?echo $g_projectTitle?></strong></h1>
    								    <br>
    								    
    									<h3><?echo ucfirst($role)?> Signup</h3>
    								</div>
    
    								<!--begin::Form-->
    								<form class="kt-form" action="" method="post" id="kt_login_form" >
    								    
    								    <?if(isset($_GET['m'])){?>
    								    <div class="form-group">
                                            <div class="alert alert-warning"><?echo $_GET['m']?></div>
                                        </div>
                                        <?}?>
                                        
                                        <?
                                        if($role=="vendor"){
                                            $fields = array("businessName","mobilePhone","address","city","state","zip","website");
                                        }else{
                                            $fields = array("company","mobilePhone", "homePhone","zip");
                                        }
                                        $fields = array();
                                        
                                        foreach($fields as $col){
                                        ?>
                                        <div class="form-group">
    										<input class="form-control" type="text" placeholder="<?echo ucfirst($col)?>" name="<?echo $col?>" >
    									</div>
                                        <?}?>
                                        
                                        <div class="form-group">
    										<input class="form-control" type="text" placeholder="Name" name="name" required>
    										<input class="form-control" type="text" placeholder="Name" name="role" value="<?echo $role?>" hidden required>
    									</div>
    									<div class="form-group">
    										<input class="form-control" type="email" placeholder="Email" name="email" required>
    									</div>
    								
    									<div class="form-group">
    										<input class="form-control" type="password" placeholder="Password" name="password" required>
    									</div>
    									<br>
    									
    									<? if(isset($_GET['_ref'])){
                                        	?>
                                        	<input type="hidden" name="userId" value="<?echo $_GET['_ref']; ?>">
                                        	<input type="hidden" name="usernumber" value="referral">
                                        	<?
                                        }?>
                                        
                                       
    									<!--begin::Action-->
    									<div class="kt-login__actions">
    									    
    										<!--<a href="./forget_password.php" class="kt-link kt-login__link-forgot">-->
    										<!--	Forgot Password ?-->
    										<!--</a>-->
    										
    										<a href="./login.php" class="kt-link kt-login__link-forgot">
    											Already have an account?
    										</a>
    										<input name="create_user" value="signup" hidden>
    									
    										<input type="submit" value="Sign up" id="kt_login_signin_submit" class="btn btn-primary btn-elevate kt-login__btn-primary" >
    										
    										
    										
    									</div>
    									
    								
    									<!--end::Action-->
    								</form>
    
    								<!--end::Form-->
                                </div>
							

								<!--end::Divider-->

								<!--begin::Options
								<div class="kt-login__options">
									<a href="./signup.php" class="btn btn-primary kt-btn">
										Signup Now!
									</a>
								</div>
								-->

								<!--end::Options-->
							</div>

							<!--end::Signin-->
						</div>

						<!--end::Body-->
					</div>

					<!--end::Content-->
				</div>
			</div>
		</div>

		<!-- end:: Page -->

		<!-- begin::Global Config(global config for global JS sciprts) -->
		<script>
			var KTAppOptions = {
				"colors": {
					"state": {
						"brand": "#591df1",
						"light": "#ffffff",
						"dark": "#282a3c",
						"primary": "#5867dd",
						"success": "#34bfa3",
						"info": "#36a3f7",
						"warning": "#ffb822",
						"danger": "#fd3995"
					},
					"base": {
						"label": ["#c5cbe3", "#a1a8c3", "#3d4465", "#3e4466"],
						"shape": ["#f0f3ff", "#d9dffa", "#afb4d4", "#646c9a"]
					}
				}
			};
		</script>

		<!-- end::Global Config -->

		<!--begin::Global Theme Bundle(used by all pages) -->
		<script src="assets/plugins/global/plugins.bundle.js" type="text/javascript"></script>
		<script src="assets/js/scripts.bundle.js" type="text/javascript"></script>

		<!--end::Global Theme Bundle -->

		<!--begin::Page Scripts(used by this page) -->

		<!--end::Page Scripts -->
	</body>
	
</html>