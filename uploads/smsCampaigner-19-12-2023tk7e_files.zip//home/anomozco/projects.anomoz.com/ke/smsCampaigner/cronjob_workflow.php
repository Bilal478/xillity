<?php 
require("./global.php");
$currentDate = time();
$customers = getAll($con,"SELECT * FROM ".$g_projectSlug."_users WHERE role='contact' AND workflow!=''");
foreach($customers as $v){ 
	$wId = $v['workflow'];
	$cId = $v['id'];
	$currentStep = $v['currentWorkflowStep'];
	$lastTimeUpdated = $v['lastTimeUpdated'];
	$waitForDays = $v['waitForDays'];
	
	$runTask = false;
	if($currentStep == 0){
		$runTask = true;
	} else if (($lastTimeUpdated + ($waitForDays * 24 * 60 * 60)) <= $currentDate){
		$runTask = true;
	}
	
	if($runTask){
		$workflowDetails = getRow($con,"SELECT * FROM ".$g_projectSlug."_workflow_details WHERE wId='$wId' and flow='$currentStep'");
		if($workflowDetails){
			$task = $workflowDetails['task'];
			// Remove all Unicode characters
			$task = preg_replace('/[^\p{L}\p{N}\s]/u', '', $task);
			$wait = $workflowDetails['wait'];
			$message1= $workflowDetails['message'];
			$currentStep = $currentStep + 1;
			if($task == ' Email' && $v['email']!=""){ 
				$id = generateRandomString();
				$email= $v["email"];	
				$query = "insert into " . $g_projectSlug . "_workflow_history set id='$id',wid='$wId' , cid='$cId', task='$task', email='$email', phone='$phone', wait='$wait', message='$message1', timeAdded='$timeAdded', userId='$session_userId' ";	
			$stmt = $con->prepare($query);
			echo($query);
				sendEmailNotification_mailjet('Welcome', 'This is welcome email.', $v['email']);
				echo 'Email Sent to ' . $v['email'];
			} else if($task == ' SMS' && $v['phone']!=""){
				$query = "insert into " . $g_projectSlug . "_workflow_history set id='$id',wid='$wId' , cid='$cId', task='$task', email='$email', phone='$phone', wait='$wait', message='$message1', timeAdded='$timeAdded', userId='$session_userId' ";	
			$stmt = $con->prepare($query);
				$message = 'Welcome';
				$m = sendansms($v['phone'], $message);
				echo $m;
			} else if($task == ' Phone' && $v['phone']!=""){
				$query = "insert into " . $g_projectSlug . "_workflow_history set id='$id' ,wid='$wId', cid='$cId', task='$task', email='$email', phone='$phone', wait='$wait', message='$message1', timeAdded='$timeAdded', userId='$session_userId' ";	
			$stmt = $con->prepare($query);
				echo 'Make a Phone Call!';
			}
			 
			$query = "update ".$g_projectSlug."_users set waitForDays='$wait',currentWorkflowStep='$currentStep',lastTimeUpdated='$currentDate' where id='$cId'";	
			$stmt = $con->prepare($query);
			if(!$stmt){echo "err: <code>$query</code>";}
			if(!$stmt->execute()){echo "err: <code>$query</code>";}	
		}
	}

}


?>