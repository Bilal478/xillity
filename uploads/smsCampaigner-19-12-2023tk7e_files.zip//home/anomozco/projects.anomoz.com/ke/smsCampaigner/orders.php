<?  require("./global.php");

    

array(
    // field_name [type, isrequired, array_select, inner_type] <= "template"
        "title" => ["input", "", "", "text"],
        "description" => ["input", "", "", "text"],
        "client_id" => ["input", "", "", "text"],
        "status" => ["input", "", "", "text"],
        "shipping_address" => ["input", "", "", "text"],
        "billing_address" => ["input", "", "", "text"],

    // "document" => ["input", "", "", "file"],
);


if(isset($_POST['create_package'])){
    $timeAdded = time();
    $actionId = mb_htmlentities(($_POST['actionId']));
    $title = mb_htmlentities($_POST['title']);    
    $description = mb_htmlentities($_POST['description']);    
    $client_id = mb_htmlentities($_POST['client_id']);    
    $status = mb_htmlentities($_POST['status']);    
    $shipping_address = mb_htmlentities($_POST['shipping_address']);    
    $billing_address = mb_htmlentities($_POST['billing_address']);    
    if($actionId==""){
        $id = generateRandomString();
        $actionId = $id;
        $query = "insert into ".$g_projectSlug."_orders set id='$id' , title='$title', description='$description', client_id='$client_id', status='$status', shipping_address='$shipping_address', billing_address='$billing_address', timeAdded='$timeAdded', userId='$session_userId' ";
    }else{
        $query = "update ".$g_projectSlug."_orders set id='$actionId' , title='$title', description='$description', client_id='$client_id', status='$status', shipping_address='$shipping_address', billing_address='$billing_address' where id='$actionId'";
    }
    $stmt = $con->prepare($query);
    if(!$stmt){echo "err: <code>$query</code>";}
    if(!$stmt->execute()){echo "err: <code>$query</code>";}

    $rStr = "";
    if(isset($_GET['id'])){$rStr .=  "&id=".$_GET['id'];}
    header("Location: ?m=Data was saved successfully!".$rStr);
}
    
if(isset($_GET['delete-record'])){
    $id = mb_htmlentities($_GET['delete-record']);
    if($id!="admin"){
        $stmt = $con->prepare("delete from ".$g_projectSlug."_orders where id=?");
        $stmt->bind_param("s", $id);
        if(!$stmt->execute()){echo "err";}
    }
}







?>

<!DOCTYPE html>


<html lang="en">

    <!-- begin::Head -->
    <head><?require("./includes/views/head.php")?>
</head>

    <!-- end::Head -->

    <!-- begin::Body -->
    <body class="<?echo $g_body_class?>">

        <?require("./includes/views/header.php")?>




        
        <div class="kt-grid kt-grid--hor kt-grid--root">
            <div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--ver kt-page">
                <div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-wrapper" id="kt_wrapper">

                
                    <!-- begin:: Header -->
                    
                    <?require("./includes/views/topmenu.php")?>
                    <!-- end:: Header -->

                    <!-- begin:: Aside -->
                    <?require("./includes/views/leftmenu.php")?>

                    <!-- end:: Aside -->
                    <div class="kt-body kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-grid--stretch" id="kt_body">
                        <div class="kt-content  kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor" id="kt_content">

                            <!-- end:: Subheader -->

                            <!-- begin:: Content -->
                            <div class="kt-container  kt-grid__item kt-grid__item--fluid">
                                
                                <?if(isset($_GET['m'])){?>
                                    <div class="alert alert-info"><?echo $_GET['m']?></div>
                                <?}?>

                                <div class="kt-portlet kt-portlet--mobile">
                                    <div class="kt-portlet__head kt-portlet__head--lg">
                                        <div class="kt-portlet__head-label">
                                            <span class="kt-portlet__head-icon">
                                            </span>
                                            <h3 class="kt-portlet__head-title">
                                                <?echo ucfirst(str_replace("_", " ", "Orders"));?>
                                            </h3>
                                        </div>
                                        <div class="kt-portlet__head-toolbar">
                                            <div class="kt-portlet__head-wrapper">
                                                <div class="kt-portlet__head-actions">
                                                    
                                                    <?renderImportExportButtons($primaryTableTask);?>
                                                    
                                                    <a href="#" class="btn btn-brand btn-elevate btn-icon-sm" data-toggle="modal" data-target="#create_record_modal">
                                                        <i class="la la-plus"></i>
                                                        New Record
                                                    </a>
                                                            
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="kt-portlet__body">
                                        <form action="" method="post">
                                            <?if(checkGlobalPermission('g_enableBulkDelete')){?>
                                                <button type="button" class="btn btn-info btn-sm text-white " onclick="selectAll();">Select All</button>
                                                <button type="submit"  class="btn btn-danger btn-sm text-white ">Delete Bulk</button>
                                            <?}?>
     
                                        <table class="table table-striped- table-bordered table-hover table-checkable add-search" >
                                            <thead>
                                                <tr>
                                                    <th>Title</th>
                                                    <th>Description</th>
                                                    <th>Client Name</th>
                                                    <th>Status</th>
                                                    <th>Shipping Address</th>
                                                    <th>Billing Address</th>
                                                    <th>Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                            <?php  $query = "SELECT ".$g_projectSlug."_orders.id, ".$g_projectSlug."_orders.title, ".$g_projectSlug."_orders.description, ".$g_projectSlug."_orders.status, ".$g_projectSlug."_orders.shipping_address, ".$g_projectSlug."_orders.billing_address, ".$g_projectSlug."_users.name
                                            FROM ".$g_projectSlug."_orders
                                            INNER JOIN ".$g_projectSlug."_users
                                            ON ".$g_projectSlug."_orders.client_id = ".$g_projectSlug."_users.id WHERE ".$g_projectSlug."_orders.userId = '$session_userId'";
                                            $results = getAll($con, $query);
                                                foreach($results as $row){?>
                                                    <tr>
                                                        <td><?php echo $row['title']?></td>
                                                        <td><?php echo $row['description']?></td>
                                                        <td><?php echo $row['name']?></td>
                                                        <td>
                                                            <? if ($row['status'] == "Pending") {
																			$statusColor = "warning";
																		} else {
																			$statusColor = "primary";
																		} ?>
                                                            <div class="badge badge-<? echo $statusColor ?>"><?php echo $row['status']?></div></td>
                                                        <td><?php echo $row['shipping_address']?></td>
                                                        <td><?php echo $row['billing_address']?></td>
                                                        <td >
                                                                <div class="btn-group">
                                                                    <a href="#" class="btn btn-warning" data-toggle="modal" data-target="#create_record_modal" data-mydata='<?php echo  htmlspecialchars(json_encode($row, JSON_UNESCAPED_SINGLEQUOTES | JSON_UNESCAPED_UNICODE));?>' >Edit</a>
                                                                    <a href="#" class="btn btn-danger" data-toggle="modal" data-target="#delete_record" data-url="?<?php if(isset($_GET['id'])){echo "id=".$_GET['id']."&";}?>delete-record=<?php echo $row['id']?>">Delete</a>
                                                                    <a href="./view_order.php?id=<? echo $row['id']?>" class="btn btn-success" >View Order</a>
                                                                </div>
                                                        </td>
                                                    </tr>
                                                <?php }?>
                                            </tbody>
                                        </table>

                                           

                                            
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?require("./includes/views/footer.php")?>
                </div>
            </div>
        </div>



        <?require("./includes/views/footerjs.php")?>
    </body>

    <!-- end::Body -->

 
    
    <div class="modal fade" id="create_record_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modelTitle">Insert</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    </button>
                </div>
                <div class="modal-body">
                    
                    <form class="kt-form" action="" method="Post" enctype="multipart/form-data">
                        <div class="kt-portlet__body">
                            
                            <!-- modal -->

                        
                            <div>
                            <div class="form-group">
                                <label>Title</label>
                                <input type="text" name="title" class="form-control"   >
                            </div>

                            <div class="form-group">
                                <label>Description</label>
                                <textarea name="description" id="" cols="30" rows="5" class="form-control"></textarea>
                            </div>

                            <div class="form-group">
                                <label>Client</label>
                                <? $qus = "SELECT * FROM ".$g_projectSlug."_users where role='customer'";
                            $resultcat = mysqli_query($con, $qus); ?>
                            <select id="empid" name="client_id" class="form-control">;
                            <?php

                            while ($data = mysqli_fetch_array($resultcat)){
                              echo "<option value=".$data[0].">" .$data[1]. " </option>";
                            
                            }

                            ?>
                            </select>
                        </div>
                                    
                            <div class="form-group">
                                <label>Status</label>
                                <select name="status" class="form-control"   >
                                <option value="Complete" >Complete</option>
                                <option value="Pending" >Pending</option>
                                </select></div>
                                    
                            <div class="form-group">
                                <label>Shipping Address</label>
                                <input type="text" name="shipping_address" class="form-control"   >
                            </div>
                                    
                            <div class="form-group">
                                <label>Billing Address</label>
                                <input type="text" name="billing_address" class="form-control"   >
                            </div>
                                    
                            <input type="text" name="actionId" value="" hidden>
                                    
                            </div>
                            
                            <div class="kt-portlet__foot">
                                <div class="kt-form__actions">
                                    <input type="submit" name="create_package" value="Submit" class="btn btn-primary">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                </div>
                            </div>
                    </form>
                </div>
            </div>
        </div>
    </div>




    <script>$(document).ready(function(){
	      

          $("#create_record_modal").on('show.bs.modal', function (e) {
            var mydata = $(e.relatedTarget).data('mydata');
            console.log("mydata->",mydata);
            $("input[type='checkbox']").prop('checked', false);
            if(mydata!= null){
            	$("#modelTitle").html("Update");            	
                $("input[name='title']").val(mydata['title'])                
                $("textarea[name='description']").val(mydata['description'])                
                $("input[name='client_id']").val(mydata['client_id'])                
                $("input[name='status']").val(mydata['status'])                
                $("input[name='shipping_address']").val(mydata['shipping_address'])                
                $("input[name='billing_address']").val(mydata['billing_address'])                                
                $("input[name='actionId']").val(mydata['id'])
            }else{
                $("#modelTitle").html("Insert");
                $("input[name='title']").val("")
                $("textarea[name='description']").val("")
                $("input[name='client_id']").val("")
                $("input[name='status']").val("")
                $("input[name='shipping_address']").val("")
                $("input[name='billing_address']").val("")
            
                $("input[name='actionId']").val("")
            }
        });
    })
</script>
    

</html> 


<!-- Task -->

