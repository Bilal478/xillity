<? require("./global.php");
$primaryTableName = "tickets";

if (!checkGlobalPermission('enableTicketManagement')) {
	header("Location: ./");
}

$getCustomersFromDB = getAll($con, "SELECT * FROM " . $g_projectSlug . "_users where role='employee' ||  role='admin'");
$employeeArr = [];
foreach ($getCustomersFromDB as $k => $v) {
	$employeeArr[$v['id']] = ucfirst($v['name']);
}

$getCustomersFromDB = getAll($con, "SELECT * FROM " . $g_projectSlug . "_users where role='customer'");
$customerArr = [];
foreach ($getCustomersFromDB as $k => $v) {
	$customerArr[$v['id']] = ucfirst($v['name']);
}



if (isset($_GET['status_change'])) {
	$status = $_GET['status_change'];
	$id = $_GET['id'];
	$query = "update " . $g_projectSlug . "_" . $primaryTableName . " set status='$status' where id='$id'";
	$stmt = $con->prepare($query);
	if (!$stmt) {
		echo "err: <code>$query</code>";
	}
	if (!$stmt->execute()) {
		echo "err: <code>$query</code>";
	}

	if ($status == "Closed") {
		$query = "update " . $g_projectSlug . "_" . $primaryTableName . " set closed_at='$time' where id='$id'";
		$stmt = $con->prepare($query);
		if (!$stmt) {
			echo "err: <code>$query</code>";
		}
		if (!$stmt->execute()) {
			echo "err: <code>$query</code>";
		}
	}
}
if (isset($_POST['update_status'])) {
	$status = mb_htmlentities($_POST['status']);

	$id = $_GET['id'];
	$query = "update " . $g_projectSlug . "_" . $primaryTableName . " set status='$status' where id='$id'";
	$stmt = $con->prepare($query);
	if (!$stmt) {
		echo "err: <code>$query</code>";
	}
	if (!$stmt->execute()) {
		echo "err: <code>$query</code>";
	}

	if ($status == "Closed") {
		$query = "update " . $g_projectSlug . "_" . $primaryTableName . " set closed_at='$time' where id='$id'";
		$stmt = $con->prepare($query);
		if (!$stmt) {
			echo "err: <code>$query</code>";
		}
		if (!$stmt->execute()) {
			echo "err: <code>$query</code>";
		}
	}
}

if (isset($_POST['update_tags'])) {
	$notes = mb_htmlentities($_POST['notes']);
	$tags = mb_htmlentities($_POST['tags']);
	$id = $_GET['id'];
	$query = "update " . $g_projectSlug . "_" . $primaryTableName . " set  tags='$tags' where id='$id'";
	$stmt = $con->prepare($query);
	if (!$stmt) {
		echo "err: <code>$query</code>";
	}
	if (!$stmt->execute()) {
		echo "err: <code>$query</code>";
	}
}


$arrayFields_crud = array(
	// field_name [type, isrequired, array_select, inner_type] <= "template"
	"title" => ["input", "required", "", "text"],
	"description" => ["textarea", "required", "", ""],
	"assigned_to" => ["select", "multiple", $employeeArr, "text"],
	"customer_id" => ["select", "", $customerArr, "text"],
	"files" => ["input", "multiple", "", "file"],
);

/*$primaryTableName = "ticket_replies";
$arrayFields_crud = array(
    // field_name [type, isrequired, array_select, inner_type] <= "template"
    "reply" => ["input", "required", "", "text"],
    "files" => ["input", "multiple", "", "file"],
    "ticketId" => ["input", "hidden value='$ticketId'", "", "text"],
);*/

//for generating table generation queries
if (false) {
	$t = "DROP TABLE IF EXISTS " . $g_projectSlug . "_" . $primaryTableName . "; CREATE TABLE " . $g_projectSlug . "_" . $primaryTableName . "(<br>id VARCHAR(200) PRIMARY KEY,<br>";
	foreach ($arrayFields_crud as  $col => $info) {
		if ((strpos($info[1], 'multiple') !== false) || $col[0] == "textarea") {
			$textSide = "longtext";
		} else {
			$textSide = "VARCHAR(256)";
		}
		$t .= "$col $textSide DEFAULT '' ,<Br>";
	}
	$t .= "timeAdded VARCHAR(256) NULL,<br>userId VARCHAR(256) NULL);";
	echo "<code>$t</code>";
}


//for insert & update
if (isset($_POST['add_reply'])) {
	$reply = mb_htmlentities(($_POST['reply']));
	$ticketId = mb_htmlentities(($_GET['id']));
	$category = mb_htmlentities(($_POST['reply_category']));

	$imageArray = [];
	foreach ($_FILES["files"]['tmp_name'] as $k => $pic) {
		$figure = uploadMultipleFile($_FILES["files"], $k, "./uploads/");
		$imageArray[] = $figure;
	}
	$files = json_encode($imageArray, true);

	$id = generateRandomString();
	$query = "insert into " . $g_projectSlug . "_" . "ticket_replies" . " set id='$id', reply='$reply', files='$files', ticketId='$ticketId', timeAdded='$time', category='$category', userId='$session_userId' ";
	$stmt = $con->prepare($query);
	if (!$stmt) {
		echo "err: <code>$query</code>";
	}
	if (!$stmt->execute()) {
		echo "err: <code>$query</code>";
	}
}
if (isset($_POST['create_package'])) {
	$timeAdded = time();
	$actionId = mb_htmlentities(($_POST['actionId']));
	$files_array = [];
	$queryExtra = '';
	foreach ($arrayFields_crud as  $col => $info) {

		if (in_array($info[3], ["image", "file"])) {
			//for images
			if (isset($_FILES[$col])) {

				if ((strpos($info[1], 'multiple') !== false)) {
					$imageArray = [];
					foreach ($_FILES[$col]['tmp_name'] as $k => $pic) {
						$figure = uploadMultipleFile($_FILES[$col], $k, "./uploads/");
						$imageArray[] = $figure;
					}
					$fileLink = json_encode($imageArray, true);
				} else {
					$fileLink = storeFile($_FILES[$col]);
				}

				$files_array[$col] = $fileLink;
			}
		} else {
			//for text
			//if multiple type field
			if ((strpos($info[1], 'multiple') !== false)) {
				$val = (json_encode($_POST[$col], true));
			} else {
				$val = mb_htmlentities($_POST[$col]);
			}

			if ($val != '' && $val != NULL) {
				$queryExtra .= ", $col='" . $val . "' ";
			}
		}
	}

	$timeAdded = time();
	$id = generateRandomString();
	if ($actionId == "") {
		$actionId = $id;
		$query = "insert into " . $g_projectSlug . "_" . $primaryTableName . " set id='$id' $queryExtra, timeAdded='$timeAdded', userId='$session_userId' ";
		$stmt = $con->prepare($query);
		if (!$stmt) {
			echo "err: <code>$query</code>";
		}
		if (!$stmt->execute()) {
			echo "err: <code>$query</code>";
		}
	} else {
		//update
		$query = "update " . $g_projectSlug . "_" . $primaryTableName . " set id='$actionId' $queryExtra where id='$actionId'";
		$stmt = $con->prepare($query);
		if (!$stmt) {
			echo "err: <code>$query</code>";
		}
		if (!$stmt->execute()) {
			echo "err: <code>$query</code>";
		}
	}

	//update files
	foreach ($files_array as $col => $file) {
		if ($file != "") {
			$stmt = $con->prepare("update " . $g_projectSlug . "_" . $primaryTableName . " set $col='$file' where id='$actionId'");
			if (!$stmt) {
				echo "err: <code>$query</code>";
			}
			if (!$stmt->execute()) {
				echo "err: <code>$query</code>";
			}
		}
	}

	if ($g_redirectHomeOnSave) {
		header("Location: ./home.php?m=Data was saved successfully!");
	} else {
		$rStr = "";
		if (isset($_GET['id'])) {
			$rStr =  "&id=" . $_GET['id'];
		}
		header("Location: ?m=Data was saved successfully!" . $rStr);
	}
}

if (isset($_GET['delete-record'])) {
	$id = mb_htmlentities($_GET['delete-record']);
	if ($id != "admin") {
		$stmt = $con->prepare("delete from " . $g_projectSlug . "_" . $primaryTableName . " where id=?");
		$stmt->bind_param("s", $id);
		if (!$stmt->execute()) {
			echo "err";
		}
	}
}
if (isset($_GET['delete_tag'])) {
	$id = mb_htmlentities($_GET['delete_tag']);
	if ($id != "admin") {
		$stmt = $con->prepare("delete from " . $g_projectSlug . "_" . "tags" . " where id=?");
		$stmt->bind_param("s", $id);
		if (!$stmt->execute()) {
			echo "err";
		}
	}
}

if (true) {
	if (isset($_POST['bulk_ticketIds'])) {
		$del  = "('" . implode("', '", $_POST['bulk_ticketIds']) . "')";
		$status = mb_htmlentities($_POST['bulk_status']);
		$sql = "update " . $g_projectSlug . "_" . $primaryTableName . " set status='$status' where id in $del";
		if (!mysqli_query($con, $sql)) {
			echo "can not";
		}
	}
}

if (isset($_GET['id'])) {
	$ticketId = $_GET['id'];
	$ticketDeets = getRow($con, "SELECT * FROM " . $g_projectSlug . "_tickets where id='$ticketId' order by timeAdded desc");
	$user_id = $ticketDeets['customer_id'];
	$customerDeets = getRow($con, "SELECT * FROM " . $g_projectSlug . "_users where id='$user_id'");
	$pastTickets = getRow($con, "SELECT title,status FROM " . $g_projectSlug . "_tickets where customer_id='$user_id' && id!='$ticketId' order by timeAdded desc");
	$query = "SELECT id,title,status FROM " . $g_projectSlug . "_tickets where customer_id='$user_id' && id!='$ticketId' order by timeAdded desc";
	$result_PastTickets = $con->query($query);
}

if (isset($_POST['customer_modal'])) {
    $ticket_id = $_GET['id'];
	$actionId = mb_htmlentities($_POST['actionId']);
	$name = mb_htmlentities($_POST['name']);
	$email = mb_htmlentities($_POST['email']);

	$query = "update  " . $g_projectSlug . "_users set name='$name',email='$email' where id='$actionId'";
	$result = $con->query($query);
	
	header("location:tickets.php?id=" . $ticket_id);
}

if (isset($_GET['status'])) {
	$status_get = $_GET['status'];
} else {
	$status_get = "All";
}

if (isset($_GET['_delete_note'])) {

	$id = mb_htmlentities($_GET['_delete_note']);
	$sql = "SELECT * FROM  " . $g_projectSlug . "_ticket_replies where id = '$id'";
	$run = mysqli_query($con, $sql);
	$row = mysqli_fetch_assoc($run);
	$ticket_id = $row['ticketId'];

	$stmt = $con->prepare("delete from " . $g_projectSlug . "_ticket_replies where id=?");

	$stmt->bind_param("s", $id);

	if (!$stmt->execute()) {
		echo "err";
	} else {
		header("location:tickets.php?id=" . $ticket_id);
	}
}

if (isset($_GET['del-tag'])) {
	$id = mb_htmlentities($_GET['del-tag']);
	$sql = "SELECT * FROM  " . $g_projectSlug . "_tags where id = '$id'";
	$run = mysqli_query($con, $sql);
	$row = mysqli_fetch_assoc($run);
	$ticket_id = $row['ticket_id'];
	$stmt = $con->prepare("delete from " . $g_projectSlug . "_tags where id=?");
	$stmt->bind_param("s", $id);
	if (!$stmt->execute()) {
		echo "err";
	} else {
		header("location:tickets.php?id=" . $ticket_id);
	}
}

if (isset($_POST['tags_modal'])) {
	$id = generateRandomString();
	$tag = mb_htmlentities($_POST['tag']);
	$color = mb_htmlentities($_POST['color']);
	$actionId = mb_htmlentities($_POST['actionId']);
	$ticket_id = $_GET['id'];
	if ($actionId == "") {
		$query = "insert into " . $g_projectSlug . "_tags set id='$id', ticket_id='$ticket_id', tagname='$tag', color='$color'";
		$result = $con->query($query);
	} else {
		$query = "UPDATE " . $g_projectSlug . "_tags set tagname='$tag', color='$color' WHERE id = '$actionId'";
		$result = $con->query($query);
	}
}



$ticket_id = $_GET['id'];

$tags_selected = [];
$temp = getAll($con, "select * from " . $g_projectSlug . "_ticket_tags where ticketId='$ticket_id'");
foreach($temp as $row){
    $tags_selected[] = $row['tagId'];
}
?>
<!DOCTYPE html>


<html lang="en">

<!-- begin::Head -->

<head><? require("./includes/views/head.php") ?>
	<link href="assets/css/pages/todo/todo.css" rel="stylesheet" type="text/css" />
	<style>
		.text-secondary {
			color: #a2a5b9 !important;
		}
		.container {
  display: block;
  position: relative;
  padding-left: 35px;
  margin-bottom: 12px;
  cursor: pointer;
  font-size: 22px;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}
.checkcolor{
	max-width:9.66667% !important;
}

/* Hide the browser's default checkbox */
.container input[type="checkbox"] {
  position: absolute;
  opacity: 0;
  cursor: pointer;
  height: 0;
  width: 0;
}

/* Create a custom checkbox */
.checkmark {
  position: absolute;
  top: 0;
  left: 0;
  height: 25px;
  width: 25px;
  border-radius:5px;
  
}

/* On mouse-over, add a grey background color */
.container:hover input ~ .checkmark {
  background-color: ;
}

/* When the checkbox is checked, add a blue background */
.container input:checked ~ .checkmark {
  background-color: ;
}

/* Create the checkmark/indicator (hidden when not checked) */
.checkmark:after {
  content: "";
  position: absolute;
  display: none;
}

/* Show the checkmark when checked */
.container input:checked ~ .checkmark:after {
  display: block;
}

/* Style the checkmark/indicator */
.container .checkmark:after {
  left: 9px;
  top: 5px;
  width: 5px;
  height: 10px;
  border: solid white;
  border-width: 0 3px 3px 0;
  -webkit-transform: rotate(45deg);
  -ms-transform: rotate(45deg);
  transform: rotate(45deg);
}
		.nav-link.dropdown-toggle:after, .btn.dropdown-toggle:after{
			opacity : 0 !important;
		}

		.badge-sm {
			padding: 4px;
		}

		.badge {
			margin-right: 4px;
		}

		.kt-todo .kt-todo__list .kt-todo__body .kt-todo__items .kt-todo__item .kt-todo__details {
			margin-top: 0px;
		}

		.kt-todo .kt-todo__list .kt-todo__body .kt-todo__items .kt-todo__item .kt-todo__datetime {
			margin-top: 0px;
		}

		.kt-todo__details {
			color: #a2a5b9 !important;
		}

		.kt-todo__info {
			color: #a2a5b9 !important;
		}
		
		.tagsCheckbox{
		    float: right;
            right: 35px;
            position: absolute;
		}
		.float-right{
		    float: right;
            right: 10px;
            position: absolute;
		}
		
		
	</style>
</head>

<!-- end::Head -->

<!-- begin::Body -->

<body class="<? echo $g_body_class ?>">

	<? require("./includes/views/header.php") ?>

	<div class="kt-grid kt-grid--hor kt-grid--root">
		<div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--ver kt-page">
			<div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-wrapper" id="kt_wrapper">

				<!-- begin:: Header -->

				<? require("./includes/views/topmenu.php") ?>
				<!-- end:: Header -->

				<!-- begin:: Aside -->
				<? require("./includes/views/leftmenu.php") ?>

				<!-- end:: Aside -->
				<div class="kt-body kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-grid--stretch" id="kt_body">
					<div class="kt-content  kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor" id="kt_content">

						<!-- end:: Subheader -->

						<!-- begin:: Content -->
						<div class="kt-container  kt-grid__item kt-grid__item--fluid">

							<!--Begin::Tasks-->
							<div class="kt-grid kt-grid--desktop kt-grid--ver-desktop  kt-todo" id="kt_todo">

								<!--Begin::Aside Mobile Toggle-->
								<button class="kt-todo__aside-close" id="kt_todo_aside_close">
									<i class="la la-close"></i>
								</button>


								<div class="kt-grid__item   kt-portlet kt-todo__aside" id="kt_todo_aside">
									<div class="kt-todo__nav">
										<ul class="kt-nav">
											<? $statuses = ["All", "Unassigned", "Mine", "Assigned", "Closed"];
											foreach ($statuses as $row) { ?>
												<li class="kt-nav__item <? if ($status_get == $row) { ?>kt-nav__item--active<? } ?>">
													<a href="?status=<? echo $row ?>" class="kt-nav__link" data-action="list" data-type="inbox">
														<span class="kt-nav__link-text"><? echo $row ?></span>

													</a>
												</li>

											<? } ?>



										</ul>
									</div>
								</div>



								<!--Begin:: Tasks Content-->
								<div class="kt-grid__item kt-grid__item--fluid kt-todo__content" id="kt_todo_content">

									<? if ((isset($_GET['id']))&&(!isset($_GET['iframe']))) { ?>
										<div class="kt-todo__tasks-top">
											<div class="kt-portlet">

												<!--Begin:: Tasks Toolbar-->
												<div class="kt-todo__header">
													<h3 class="kt-todo__title">Actions</h3>




													<!--Begin:: Tasks Nav-->
													<div class="kt-todo__nav">

														<form action="" method="post" enctype="multipart/form-data">
															<div class="row">
																<div class="col-md-2">
																	<!--<label>Status</label>-->
																	<select name="status" class="form-control">
																		<? foreach (["Closed", "In-Progress", "Open"] as $row) { ?>
																			<option <? if ($row == $ticketDeets['status']) {
																						echo "selected";
																					} ?> value="<? echo $row ?>"><? echo $row ?></option>
																		<? } ?>
																	</select>
																</div>

                                                                <?if(checkGlobalPermission('enableTicketCustomTags')){?>
																<div class="dropdown col-md-1">
																	<button class="btn btn-white dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
																	<i class="fas fa-tags"></i>
																	</button>
																	<div class="dropdown-menu " aria-labelledby="dropdownMenuButton">
																	<? 
																		$ticket_id = $_GET['id'];
																		$tags = getAll($con, "select * from " . $g_projectSlug . "_tags ");
																		foreach ($tags as  $row) { ?>
																		    <div class="dropdown-item dropdown-menu-tags"   >
																		        <div class="tagsAvailable w-100"  id="tag_div_<?echo $row['id']?>">
    																		        <span style="background-color:<? echo $row['color'] ?> ; color:white" class= "badge badge-primary badge-sm"><? echo $row['tagname'] ?></span>
    																		        <span id="tag_<?echo $row['id']?>" class="tagsCheckbox">
    																		            <?if( in_array($row['id'], $tags_selected)){?>
    																		                <i class="fa fa-check" aria-hidden="true"></i>
    																		            <?}?>
    																		        </span>
																		        </div>
																		        <span  class="float-right">
																		          <a href="?id=<?echo $_GET['id']?>&delete_tag=<?echo $row['id']?>">
																		              <i class="fa fa-times" aria-hidden="true"></i>
																		          </a>
																		        </span>
																		  </div>
																		<? } ?>
																		<hr>
																		<a class="dropdown-item text-primary"  data-toggle="modal" data-target="#tags_modal"  href="#"><i class="fas fa-plus text-primary"></i>Add Tag</a>
																	</div>
																</div>
																<?}?>
																
																<div class="col-md-2">
																	<input type="submit" name="update_status" style='margin-left: 50px !important;' value="Save" class="btn btn-primary">
																</div>
																<div class="col-md-7">
																	<a href="#" class="btn btn-warning" data-toggle="modal" data-target="#create_record_modal" data-mydata='<? echo (json_encode($ticketDeets, true)); ?>'>Edit Ticket</a>

																	<!--<a href="#" class="btn btn-info" data-toggle="modal" data-target="#create_modal_notes_tags" data-mydata='<? echo (json_encode($ticketDeets, true)); ?>'>Edit Tags</a>-->
																	<!--<a href="#" class="btn btn-info"  data-toggle="modal" data-target="#tags_modal">Edit Tags</a>-->

																	<a href="#" class="btn btn-primary" data-toggle="modal" data-target="#create_modal_add_reply" data-category='notes'>Add Note</a>

																	<a href="#" class="btn btn-primary" data-toggle="modal" data-target="#create_modal_add_reply" data-category='reply'>Add Reply</a>
																</div>

															</div>
														</form>





													</div>

													<!--End:: Tasks Nav-->



													<!--End:: Tasks Users-->
												</div>

												<!--End:: Tasks Toolbar-->
											</div>
										</div>
									<? } ?>


									<div class="kt-todo__tasks-bottom">
									    <form action="" method="post">
										    <div class="row">
											<div class="col-md-<? if (isset($_GET['id'])) {
																	echo "0 d-none";
																} else {
																	echo 12;
																} ?>">

												<!--Begin:: Inbox List-->
												<div class="kt-grid__item kt-grid__item--fluid  kt-portlet kt-portlet--height-fluid kt-todo__list" id="kt_todo_list">
													<div class="kt-portlet__body kt-portlet__body--fit-x">
														<div class="kt-todo__head">
															<div class="kt-todo__toolbar">
																<? if (true) { ?>
																	<div class="kt-todo__actions kt-todo__actions--expanded">
																		<div class="kt-todo__check">
																			<h3><? echo $status_get ?> Tickets</h3>
																		</div>
																	</div>
																<? } ?>
																
																<div class="btn-group">
                                                                    <select name="bulk_status" class="form-control" style="width:100px;">
    																		<option value="Closed">Closed</option>
    																		<option value="In-Progress">In-Progress</option>
    																		<option selected="" value="Open">Open</option>
    																</select>
    																<button class="btn btn-primary "  type="submit">Change Status</button>
    																<a href="#" class="btn btn-primary" data-toggle="modal" data-target="#create_record_modal">
    																	New Ticket
    																</a>
																</div>
															</div>
														</div>
														<div class="kt-todo__body" style="max-height: 600px;">
															<div class="kt-todo__items" data-type="task">
																<div class="kt-todo__item">
																	<div class="kt-todo__info">
																		<!-- <div class="kt-todo__actions"> -->
																		<b>
																		    <button type="button" class="badge badge-sm badge-primary" onclick="selectAll_tickets();">Select All</button>
																		</b>
																		<!-- </div> -->
																	</div>
																	<div class="kt-todo__datetime text-center">
																		<b>Customer</b>
																	</div>
																	<div class="kt-todo__details">
																		<!-- <div class="kt-todo__message"> -->
																		<b>Title</b>
																		<!-- </div> -->
																	</div>
																	<div class="kt-todo__datetime text-center">
																		<b>Ticket #</b>
																	</div>
																	<div class="kt-todo__datetime text-center">
																		<b>Date</b>
																	</div>
																	<div class="kt-todo__datetime text-center">
																		<b>Waiting Since</b>
																	</div>
																	<!--<div class="kt-todo__datetime text-center">-->
																	<!--	<b>Status</b>-->
																	<!--</div>-->
																	<div class="kt-todo__datetime text-center">
																		<b>Action</b>
																	</div>
																</div>
																<?
																if ($status_get == "All") {
																	$query = "SELECT * FROM " . $g_projectSlug . "_tickets where userId='$session_userId' || assigned_to like '%$session_userId%' order by timeAdded desc";
																} else if ($status_get == "Unassigned") {
																	$query = "SELECT * FROM " . $g_projectSlug . "_tickets where assigned_to='' or assigned_to='[]' order by timeAdded desc";
																} else if ($status_get == "Mine") {
																	$query = "SELECT * FROM " . $g_projectSlug . "_tickets where assigned_to like '%$session_userId%' order by timeAdded desc";
																} else if ($status_get == "Closed") {
																	$query = "SELECT * FROM " . $g_projectSlug . "_tickets where status='Closed' order by timeAdded desc";
																}
																$tickets = getAll($con, $query);
																foreach ($tickets as $row) { ?>
																	<!-- <a href="?id=<? echo $row['id'] ?>" class="kt-todo__item" data-id="13" data-type="task"> -->
																	<div class="kt-todo__item">
																		<div class="kt-todo__info">
																			<div class="kt-todo__actions">
																				<label class="kt-checkbox kt-checkbox--single kt-checkbox--tick kt-checkbox--brand">
																					<input type="checkbox" name="bulk_ticketIds[]" value="<?echo $row['id']?>">
																					<span></span>
																				</label>
																				<!--<span class="kt-todo__icon kt-todo__icon--light" data-toggle="kt-tooltip" data-placement="right" title="" data-original-title="Star">
																					<i class="flaticon-star"></i>
																				</span>-->
																			</div>
																		</div>
																		<div class="kt-todo__datetime text-left">
																			<?
																			$customer_id = $row['customer_id'];
																			$run = getAll($con, "SELECT * FROM " . $g_projectSlug . "_users where id='$customer_id'");
																			foreach ($run as $row1) {
																				echo ucfirst($row1['name']);
																			}
																			?>
																		</div>
																		<div class="kt-todo__details" data-toggle="view">
																			<div class="kt-todo__message">
																				<span class="kt-todo__subject">
																					<a href="?id=<? echo $row['id'] ?>" class="text-underline" >
																						<div><? echo $row['title'] ?></div>
																					</a>
																					<span class="badge badge-primary badge-sm"><? echo $row['status'] ?></span>
																				</span> <? $ticket_id = $row['id']; $tags = getAll($con, "select * from " . $g_projectSlug . "_tags t inner join " . $g_projectSlug . "_ticket_tags tt on tt.ticketId=t.id where tt.ticketId='$ticket_id'");
																			foreach ($tags as $tag) { ?><div class="badge badge-primary badge-sm" style="background-color:<? echo $tag['color'] ?>;"><? echo $tag['tagname'] ?></div><? } ?>
																			<? foreach(json_encode($row['assigned_to'], true) as $user){?>
																			    <div class="badge badge-primary badge-sm" style="background-color:<? echo $tag['color'] ?>;"><? echo  $g_allUsersInfo[$user]['name']; ?></div>
																			<?}?>
																				<p class="text-secondary"><? echo substr($row['description'], 0, 100) ?>...</p>
																			</div>
																		</div>
																		<div class="kt-todo__datetime">
																			#<? echo  $row['ticket_number'] ?>
																		</div>
																		<div class="kt-todo__datetime">
																			<? echo date("d M", $row['timeAdded']) ?>
																		</div>
																		<div class="kt-todo__datetime">
																			<? if ($row['status'] != "Closed") { ?>
																				<!-- Waiting since -->
																				<? echo  secondsToTime(time() - $row['timeAdded']) ?>
																			<? } else {
																				echo "Closed";
																			} ?>
																		</div>
																		<div class="kt-todo__sender" data-toggle="kt-tooltip" data-placement="top" title="" data-original-title="<? echo $row['status'] ?>">
																			<!--<span class="kt-media kt-media--sm kt-media--brand" style="background-image: url('./uploads/<? echo $g_allUsersInfo[$row['assigned_to']]['profile_pic'] ?>')">-->
																			<!--	<span></span>-->
																			<!--</span>-->

																		</div>

                                                                        <?$row['assigned_to'] = json_decode($row['assigned_to'], true);?>
																		<div class="kt-todo__datetime">
																			<div class="btn-group">
																				<a href="#" class="btn btn-warning" data-toggle="modal" data-target="#create_record_modal" data-category='reply' data-mydata='<? echo (json_encode($row, true)); ?>'>Edit</a>
																				<a href="?id=<? echo $row['id'] ?>" class="btn btn-primary">View</a>
																			</div>
																		</div>



																	</div>
																	<!-- </a> -->

																<? } ?>
															</div>
														</div>

													</div>
												</div>

												<!--End:: Inbox List-->
											</div>
											<? if (isset($_GET['id'])) { ?>
												<div class="col-md-8">

													<!--Begin:: Inbox View-->
													<div class="kt-grid__item kt-portlet kt-todo__view" id="kt_todo_view">

														<!--Begin:: Portlet Body-->
														<div class="kt-portlet__body kt-portlet__body--fit-y">

															<!--Begin:: Wrapper-->
															<div class="kt-todo__wrapper">

																<!--Begin:: Head-->
																<div class="kt-todo__head">
																	<div class="kt-todo__toolbar">
																		<div class="kt-todo__info">
																			<span class="kt-media kt-media--sm" data-toggle="expand" style="background-image: url('./uploads/<? echo $g_allUsersInfo[$ticketDeets['userId']]['profile_pic'] ?>')">
																				<span></span>
																			</span>
																			<a href="#" class="kt-todo__name">
																				<? echo $g_allUsersInfo[$ticketDeets['userId']]['name'] ?>
																			</a>
																		</div>
																		<div class="kt-todo__details">
																			<a href="#" class="kt-todo__icon kt-todo__icon--back">
																				<i class="flaticon2-left-arrow-1"></i>
																			</a>

																			<button type="button" class="btn btn-label-danger btn-upper btn-sm btn-bold mr-2"><? echo date("d M Y", $ticketDeets['timeAdded']) ?></button>
																			<? if ($ticketDeets['status'] != "Closed") { ?>
																				<a href="?status_change=Closed&id=<? echo $_GET['id'] ?>" type="button" class="btn btn-label-danger btn-upper btn-sm btn-bold">Mark as Closed</a>
																			<? } ?>
																			<? if ($ticketDeets['status'] == "Open") { ?>
																				<a href="?status_change=In-Progress&id=<? echo $_GET['id'] ?>" type="button" class="btn btn-label-success btn-upper btn-sm btn-bold">Mark as In-Progress</a>
																			<? } ?>
																			<? if ($ticketDeets['status'] == "Closed") { ?>
																				<a href="?status_change=Open&id=<? echo $_GET['id'] ?>" type="button" class="btn btn-label-warning btn-upper btn-sm btn-bold">Mark as Open</a>
																			<? } ?>
																		</div>
																	</div>
																</div>

																<!--End:: Head-->

																<!--Begin:: Body-->
																<div class="kt-todo__body">
																	<div class="kt-todo__title">
																		<a href="#" class="kt-todo__text"><? echo $ticketDeets['title'] ?></a>
																		<? $ticket_id = $_GET['id']; $tags = getAll($con, "select * from " . $g_projectSlug . "_tags where ticket_id='$ticket_id'");
																			foreach ($tags as $tag) { ?><div class="badge badge-primary badge-sm" style="background-color:<? echo $tag['color'] ?>;"><? echo $tag['tagname'] ?></div><? } ?>
																		<div class="kt-todo__labels">
																			<span class="kt-todo__label">
																				<i class="kt-todo__dot fa fa-genderless kt-font-info"></i>
																				<span class="kt-todo__text"><? echo $ticketDeets['status'] ?></span>
																			</span>

																		</div>
																	</div>
																	<div class="kt-todo__desc">
																		<? echo $ticketDeets['description'] ?>
																	</div>
																	<div class="kt-todo__files">
																		<? $ticketDeets['files'] = json_decode($ticketDeets['files'], true);
																		foreach ($ticketDeets['files'] as $file) {
																			if ($file != "") { ?>
																				<span class="kt-todo__file">
																					<i class="flaticon2-clip-symbol kt-font-warning"></i>
																					<a href="./uploads/<? echo $file ?>" target="_blank"><? echo $file ?></a>
																				</span>
																		<? }
																		} ?>

																	</div>
																	<div class="kt-todo__comments">
																		<? $ticketReplies = getAll($con, "SELECT * FROM " . $g_projectSlug . "_ticket_replies where ticketId='$ticketId' order by timeAdded desc");
																		foreach ($ticketReplies as $row) { ?>
																			<div class="row" <?if($row['category']=="notes"){?>style="background: #ffface;"<?}?>>
																				<div class="col-md-10">
																					<div class="kt-todo__comment">
																						<div class="kt-todo__box">
																							<span class="kt-media kt-media--sm" data-toggle="expand" style="background-image: url('./uploads/<? echo $g_allUsersInfo[$row['userId']]['profile_pic'] ?>')">
																								<span></span>
																							</span>
																							<a href="#" class="kt-todo__username">
																								<? echo $g_allUsersInfo[$row['userId']]['name'] ?>
																							</a>
																							<!--<div class="badge badge-primary"><?echo $row['category']?></div>-->
																							<span class="kt-todo__date">
																								<? echo date("d M Y", $row['userId']) ?>
																							</span>
																						</div>
																						<span class="kt-todo__text">
																							<? echo $row['reply'] ?>
																						</span>
																						<div class="kt-todo__files">
																							<? $row['files'] = json_decode($row['files'], true);
																							foreach ($row['files'] as $file) {
																								if ($file != "") { ?>
																									<span class="kt-todo__file">
																										<i class="flaticon2-clip-symbol kt-font-warning"></i>
																										<a href="./uploads/<? echo $file ?>" target="_blank"><? echo $file ?></a>
																									</span>
																							<? }
																							} ?>
																						</div>

																					</div>
																				</div>
																				<div class="col-md-2 text-right">
																					<div class="dropdown">
																						<button class="btn btn-secondary" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-expanded="false">
																							<i class="fas fa-ellipsis-v"></i>
																						</button>
																						<div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
																							<a href="#" class="dropdown-item" data-toggle="modal" data-target="#create_modal_add_reply" data-category='notes' data-mydata='<? echo (json_encode($row, true)); ?>'>Edit</a>
																							<a class="dropdown-item" href="?_delete_note=<? echo $row['id']; ?>">Delete</a>
																						</div>
																					</div>
																				</div>
																			</div>
																		<? } ?>

																	</div>
																</div>

																<!--End:: Body-->

																<!--End:: Foot-->
															</div>

															<!--End:: Wrapper-->
														</div>

														<!--End:: Portlet Body-->
													</div>

													<!--End:: Inbox View-->
												</div>




												<div class="col-md-4">

													<? if (false) { ?>
														<!--Begin:: Inbox View-->
														<div class=" kt-portlet ">

															<!--Begin:: Portlet Body-->
															<div class="kt-portlet__body ">

																<!--Begin:: Wrapper-->
																<div class="kt-todo__wrapper">

																	<!--Begin:: Body-->
																	<div class="kt-todo__body">

																		<div class="pt-4" id="kt_todo_post_form ">

																		</div>

																	</div>

																</div>

																<!--End:: Wrapper-->
															</div>

															<!--End:: Portlet Body-->
														</div>
													<? } ?>


													<div class=" kt-portlet ">

														<div class="kt-portlet__head ">
															<div class="kt-portlet__head-label">
																<span class="kt-portlet__head-icon">
																</span>
																<div class="row">
																	<div class="col-md-11 d-flex align-items-center">
																		<h3 class="kt-portlet__head-title">Customer Information</h3>
																	</div>
																	<div class="col-md-1 text-right">
																		<div class="dropdown">
																			<button class="btn btn-secondary" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-expanded="false">
																				<i class="fas fa-ellipsis-v"></i>
																			</button>
																			<div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
																				<a href="#" class="dropdown-item" data-toggle="modal" data-target="#customer_modal" data-mydata='<? echo (json_encode($customerDeets, true)); ?>'>Edit</a>
																			</div>
																		</div>
																	</div>
																</div>
															</div>
															<div class="kt-portlet__head-toolbar">
																<div class="kt-portlet__head-wrapper">
																	<div class="kt-portlet__head-actions">
																		<!--<a href="#" class="btn btn-brand btn-elevate btn-icon-sm" data-toggle="modal" data-target="#create_record_modal">-->
																		<!--	<i class="la la-plus"></i>-->
																		<!--	New Record-->
																		<!--</a>-->
																	</div>
																</div>
															</div>
														</div>



														<!--Begin:: Portlet Body-->
														<div class="kt-portlet__body kt-portlet__body--fit-y">

															<!--Begin:: Wrapper-->
															<div class="kt-todo__wrapper">

																<!--Begin:: Body-->
																<div class="kt-todo__body" style="margin-top:20px;">
																	<b>Name :</b>
																	<p><? echo $customerDeets['name'] ?></p>
																	<b>Email :</b>
																	<p><? echo $customerDeets['email'] ?></p>
																	<b>Role :</b>
																	<p><? echo $customerDeets['role'] ?></p>
																</div>

															</div>

															<!--End:: Wrapper-->
														</div>

														<!--End:: Portlet Body-->
													</div>
                                                    <?if(!isset($_GET['iframe'])){?>
													<div class=" kt-portlet ">

													


														<!--Begin:: Portlet Body-->
														<div class="kt-portlet__body kt-portlet__body--fit-y">

															<!--Begin:: Wrapper-->
															<div class="kt-todo__wrapper">

																<!--Begin:: Body-->
																<div class="kt-todo__body">


																</div>

															</div>

															<!--End:: Wrapper-->
														</div>

														<!--End:: Portlet Body-->
													</div>

													<div class=" kt-portlet ">

														<div class="kt-portlet__head ">
															<div class="kt-portlet__head-label">
																<span class="kt-portlet__head-icon">
																</span>
																<h3 class="kt-portlet__head-title">Past Tickets</h3>
															</div>
															<div class="kt-portlet__head-toolbar">
																<div class="kt-portlet__head-wrapper">
																	<div class="kt-portlet__head-actions">
																		<!--<a href="#" class="btn btn-brand btn-elevate btn-icon-sm" data-toggle="modal" data-target="#create_record_modal">-->
																		<!--	<i class="la la-plus"></i>-->
																		<!--	New Record-->
																		<!--</a>-->
																	</div>
																</div>
															</div>
														</div>



														<!--Begin:: Portlet Body-->
														<div class="kt-portlet__body kt-portlet__body--fit-y">

															<!--Begin:: Wrapper-->
															<div class="kt-todo__wrapper">

																<!--Begin:: Body-->
																<div class="kt-todo__body" style="margin-top:20px;">

																	<table class="table table-striped table-bordered">
																		<thead>
																			<th>Title</th>
																			<th>Status</th>
																			<th>View</th>
																		</thead>
																		<tbody>
																			<?
																			while ($row = $result_PastTickets->fetch_assoc()) {
																			?>
																				<tr>
																					<td><? echo $row['title'] ?></td>
																					<td><? echo $row['status'] ?></td>
																					<td><a target="iframe_a" data-toggle="modal" data-target="#iframe_model" data-mydata='<? echo (json_encode($row, true)); ?>' href="#" >View</a></td>
																				</tr>
																			<? } ?>
																		</tbody>
																	</table>


																</div>

															</div>

															<!--End:: Wrapper-->
														</div>
														<!--End:: Portlet Body-->
													</div>
                                                    <?if(false){?>
													    <div class=" kt-portlet ">

														<div class="kt-portlet__head ">
															<div class="kt-portlet__head-label">
																<span class="kt-portlet__head-icon">
																</span>
																<h3 class="kt-portlet__head-title">Tags</h3>
															</div>
															<div class="kt-portlet__head-toolbar">
																<div class="kt-portlet__head-wrapper">
																	<div class="kt-portlet__head-actions">
																		<!-- <a href="#" class="btn btn-primary" data-toggle="modal" data-target="#tags_modal">Add Tag</a> -->
																	</div>
																</div>
															</div>
														</div>



														<!--Begin:: Portlet Body-->
														<div class="kt-portlet__body kt-portlet__body--fit-y">

															<!--Begin:: Wrapper-->
															<div class="kt-todo__wrapper">

																<!--Begin:: Body-->
																<div class="kt-todo__body" style="margin-top:20px;">

																	<table class="table table-striped table-bordered">
																		<thead>
																			<th>Tags</th>
																			<th>Action</th>
																		</thead>
																		<tbody>
																			<?
																			$ticket_id = $_GET['id'];
																			$tags = getAll($con, "select * from " . $g_projectSlug . "_tags where ticket_id='$ticket_id'");
																			foreach ($tags as $row) { ?>
																				<tr>
																					<td>
																						<div class="badge badge-primary" style="background-color:<? echo $row['color'] ?>;"><? echo $row['tagname'] ?></div>
																					</td>

																					<td>
																						<a href="#" class="btn btn-warning btn-sm" data-toggle="modal" data-target="#tags_modal" data-mydata='<? echo (json_encode($row, true)); ?>'>Edit</a>
																						<!-- <a href="?edit-tag=<? echo $row['id'] ?>">Edit</a> -->
																						<a href="?del-tag=<? echo $row['id'] ?>" class="btn btn-danger btn-sm">Delete</a>
																					</td>
																				</tr>

																			<? } ?>
																		</tbody>
																	</table>


																</div>

															</div>

															<!--End:: Wrapper-->
														</div>

														<!--End:: Portlet Body-->
													</div>
													<?}?>
                                                    <?}?>
													<!--End:: Inbox View-->
												</div>
											<? } ?>
										</div>
										</form>
									</div>
								</div>

								<!--End:: Tasks Content-->
							</div>

							<!--End::Tasks-->
						</div>



						<!-- end:: Content -->
					</div>
				</div>

				<!-- begin:: Footer -->
                <? require("./includes/views/footer.php") ?>

				<!-- end:: Footer -->
			</div>
		</div>
	</div>


	<? require("./includes/views/footerjs.php") ?>


</body>

<!-- end::Body -->

<div class="modal fade" id="create_record_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="modelTitle">Insert</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				</button>
			</div>
			<div class="modal-body">

				<form class="kt-form" action="" method="Post" enctype="multipart/form-data">
					<div class="kt-portlet__body">

						<? foreach ($arrayFields_crud as $col => $info) { ?>
							<div class="form-group">
								<? if (strpos($info[1], "hidden") === false) { ?>
									<label><? echo ucfirst(str_replace("_", " ", $col)) ?></label>
									<? if ($info[4] != "") { ?>
										<small><? echo $info[4] ?></small>
									<? } ?>
								<? } ?>
								<? if ($info[0] == "input" && in_array($info[3], ["text", "email", "password", "number", "file", "date", "time", "color", "datetime", "checkbox", "radio"])) { ?>
									<? if (in_array($info[3], ["checkbox", "radio"])) { ?>
										<? foreach ($info[2] as $i => $option) { ?>
											<div class="form-check">
												<input name="<? echo $col ?><? if ((strpos($info[1], 'multiple') !== false)) {
																				echo '[]';
																			} ?>" class="form-check-input" type="<? echo $info[3] ?>" value="<? echo $i ?>" id="<? echo $col ?>" <? echo $info[1] ?>>
												<label class="form-check-label" for="<? echo $col ?>">
													<? echo ucfirst(str_replace("_", " ", $option)) ?>
												</label>
											</div>
										<? } ?>
									<? } else { ?>
										<input type="<? echo $info[3] ?>" name="<? echo $col ?><? if ((strpos($info[1], 'multiple') !== false)) {
																									echo '[]';
																								} ?>" class="form-control" <? echo $info[1] ?>>
									<? } ?>
								<? } else if ($info[0] == "select") { ?>
									<select name="<? echo $col ?><? if ((strpos($info[1], 'multiple') !== false)) {
																		echo '[]';
																	} ?>" class="form-control" <? echo $info[1] ?>>
										<? foreach ($info[2] as $i => $option) { ?>
											<option value="<? echo $i ?>"><? echo $option ?></option>
										<? } ?>
									</select>
								<? } else if ($info[0] == "input" && in_array($info[3], ["image"])) { ?>
									<input type="file" name="<? echo $col ?><? if ((strpos($info[1], 'multiple') !== false)) {
																				echo '[]';
																			} ?>" class="form-control" <? echo $info[1] ?>>
								<? } else if ($info[0] == "textarea") { ?>
									<textarea type="text" name="<? echo $col ?>" class="form-control" <? echo $info[1] ?>></textarea>
								<? } else { ?>
									<code><? echo $col ?> Couldn't render</code>
								<? } ?>
							</div>
						<? } ?>

						<input type="text" name="actionId" value="" hidden>

					</div>
					<div class="kt-portlet__foot">
						<div class="kt-form__actions">
							<input type="submit" name="create_package" value="Submit" class="btn btn-primary">
							<button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
						</div>
					</div>
				</form>
			</div>

		</div>
	</div>
</div>


<div class="modal fade" id="create_modal_notes_tags" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="modelTitle">Insert</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				</button>
			</div>
			<div class="modal-body">

				<form class="kt-form" action="" method="Post" enctype="multipart/form-data">
					<div class="kt-portlet__body">
						<? $arrayFields_crud_notes_tags = array(
							"tags" => ["input", "", "", "text"],
						); ?>
						<? renderFormFieldsFromCrudJson($arrayFields_crud_notes_tags) ?>

						<!--<input type="text" name="update_tags" value="" hidden>-->

					</div>
					<div class="kt-portlet__foot">
						<div class="kt-form__actions">
							<input type="submit" name="update_tags" value="Submit" class="btn btn-primary">
							<button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
						</div>
					</div>
				</form>
			</div>

		</div>
	</div>
</div>

<div class="modal fade" id="create_modal_add_reply" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="modelTitle">Insert</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				</button>
			</div>
			<div class="modal-body">

				<form class="kt-form" action="" method="Post" enctype="multipart/form-data">
					<div class="kt-portlet__body">
						<label>Add </label>
						<textarea class='form-control' id="editor" name="reply" required></textarea>
						<!-- <textarea class='form-control' name="reply" required></textarea> -->
						<Br>
						<label>Attach Files</label>
						<input type="file" name="files[]" class="form-control" multiple>
						<!--<input type="submit" name="add_reply" value="Add Reply" class="btn btn-primary mt-2">-->
						<Br>

					</div>
					<div class="kt-portlet__foot">
						<div class="kt-form__actions">
							<input type="input" name="reply_category" hidden>
							<input type="submit" name="add_reply" value="Submit" class="btn btn-primary">
							<button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
						</div>
					</div>
				</form>
			</div>

		</div>
	</div>
</div>

<div class="modal fade" id="customer_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="modelTitle">Customer</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				</button>
			</div>
			<div class="modal-body">
				<form class="kt-form" action="" method="Post" enctype="multipart/form-data">
					<div class="kt-portlet__body">
						<div class="form-group">
							<label>Name</label>
							<input type="text" name="name" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Email</label>
							<input type="email" name="email" class="form-control" required>
						</div>
						<input type="text" name="actionId" value="" hidden>
					</div>
					<div class="kt-portlet__foot">
						<div class="kt-form__actions">
							<input type="submit" name="customer_modal" value="Submit" class="btn btn-primary">
							<button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>

<div class="modal fade" id="tags_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="modelTitle">Tag</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				</button>
			</div>
			<div class="modal-body">
				<form action="" method="post" class="kt-form" enctype="multipart/form-data">
					<div class="kt-portlet__body">
						<div class="form-group">
							<p>Create Tag</p>
							<input type="text" name="tag" id = "tag" class="form-control" value="" placeholder="Tag">
						</div>
						<div class="form-group row">
						    
						    <?$colors = ["#008000", "#FF0000", "#1AA7EC", "#ccc", "#FFFF00"];
						    foreach($colors as $color){?>
							<div class = "col-md-2 checkcolor">
								<label class="container">
  									<input type="checkbox" name="ckx" class="ckx"  value = "<?echo $color?>">
  									<span class="checkmark" style="background-color: <?echo $color?>;"></span>
								</label>
							</div>
							<?}?>
							<!--<div class = "col-md-1 ">-->
							<!-- <label class="container">-->
							<!-- 	<input type="checkbox" class="ckx" value = "#FF0000">-->
							<!-- 	<span class="checkmark" style="background-color: #FF0000;"></span>-->
							<!-- </label>-->
					  <!--  	</div>-->

							<!--<div class = "col-md-1 ">-->
							<!-- <label class="container">-->
							<!-- 	<input type="checkbox" class="ckx"  value = "#0000FF">-->
							<!-- 	<span class="checkmark"  style="background-color:#1AA7EC;"></span>-->
							<!-- </label>-->
							<!--</div>-->

							<!--<div class = "col-md-1 ">-->
							<!-- <label class="container">-->
							<!-- 	<input type="checkbox" class="ckx"  value = "#ccc">-->
							<!-- 	<span class="checkmark" class="ckx" style="background-color:#ccc;"></span>-->
							<!-- </label>-->
							<!--</div>-->

							<!--<div class = "col-md-1 ">-->
							<!-- <label class="container">-->
							<!-- 	<input type="checkbox" class="ckx" value = "#FFFF00">-->
							<!-- 	<span class="checkmark" style="background-color:#FFFF00;"></span>-->
							<!-- </label>-->
							<!--</div>-->
						</div>

					
						<input type="text" value="" name="actionId" hidden>
					</div>
					<div class="kt-portlet__foot">
						<div class="kt-form__actions">
							<input type="button" name="insert_tag" id = "add_tag" value="Submit" class="btn btn-primary">
							<button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
<div class="modal fade" id="iframe_model" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="modelTitle">Past Ticket</h5>
				    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
				</button>
			</div>
			<div class="modal-body">
				<form class="kt-form" action="" method="Post" enctype="multipart/form-data">
					<div class="kt-portlet__body">
					    <iframe class="w-100" style="height:800px;" id="pastTicketIframe" src="./tickets.php" name="iframe_a" title="Iframe Example"></iframe>
                    </div>
					<div class="kt-portlet__foot">
						<div class="kt-form__actions">
							<a name="iframeLink" id="#openPastTicket" href="some.php" class="btn btn-primary">Open</a>
							<button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>


<script src="./assets/ckeditor/ckeditor.js"></script>
<script>
	CKEDITOR.replace('editor');
</script>

<script>
	

	$(document).ready(function() {
		// function get_tags(){
		// 	$.ajax({
		// 		url  : "tickets_api.php",
		// 		type : "POST",
		// 		data : {type : "get_tags"} 
		// 	})
		// }
		
		function removeArrayElement(array, element){
		    const index = array.indexOf(element);
            if (index > -1) {
              array.splice(index, 1);
            }
            return array;
		}
		



		tags_selected = <?echo json_encode($tags_selected, true);?>;
		
		
		$(".tagsAvailable").click(function(){
		    $($(".tagsAvailable .tagsCheckbox"));
		    console.log("this.", this)
		    tagId = ($(this).attr("id")).substr(8)
		    if(tags_selected.includes(tagId)){
		        action = "unchecked";
		        console.log("unchecked")
		        $($(this).find(".tagsCheckbox")).html('')
		        removeArrayElement(tags_selected, tagId)
		    }else{
		        action = "checked";
		        console.log("checked")
		        tags_selected.push(tagId);
		        $($(this).find(".tagsCheckbox")).html('<i class="fa fa-check" aria-hidden="true"></i>')
		    }
		    
		    $.ajax({
				url  : "tickets_api.php",
				type : "POST",
				data : {type : "tag_check_uncheck" , tagId : tagId , action : action , ticketId :'<?php echo $_GET['id']?>'},
				success : function(data){
				// 	alert(data);
				}
			})

		});
		
// 		$(".tagsAvailable").click();
		
		$("#add_tag").click(function(){
			var color_array = [];
    		$(".ckx").each(function(){
    			if($(this).is(":checked") == true){
    				color = $(this).val();
    				color_array.push({
    					"colors" : color
    				})
    			}
    		})
			if($("#tag").val() == ""){
				alert("Tag Field is Empty");
				return false;
			}
			var tag_name  = $("#tag").val();
			var ticket_id = "<?php echo $_GET['id']?>";
			$.ajax({
				url  : "tickets_api.php",
				type : "POST",
				data : {type : "add_tag" , tag_name : tag_name , color_array : color_array , ticket_id :ticket_id},
				success : function(data){
					window.location="?id="+ticket_id;
				}
			})
		})
		$("#customer_modal").on('show.bs.modal', function(e) {
			//get data-id attribute of the clicked element
			var mydata = $(e.relatedTarget).data('mydata');
			console.log(mydata);
			console.log("mydata")
			if (mydata != null) {
				$("#modelTitle").html("Update");
				$("input[name='name']").val(mydata['name'])
				$("input[name='email']").val(mydata['email'])
				$("input[name='actionId']").val(mydata['id'])
			} else {
				$("#modelTitle").html("Insert");
				$("input[name='name']").val("")
				$("input[name='email']").val("")
				$("input[name='actionId']").val("")
			}
		});

		$("#tags_modal").on('show.bs.modal', function(e) {
			//get data-id attribute of the clicked element
			var mydata = $(e.relatedTarget).data('mydata');
			console.log(mydata);
			console.log("mydata")
			if (mydata != null) {
				$("#modelTitle").html("Update");
				$("input[name='tag']").val(mydata['tagname'])
				$("input[name='color']").val(mydata['color'])
				$("input[name='actionId']").val(mydata['id'])
			} else {
				$("#modelTitle").html("Insert");
				$("input[name='tag']").val("")
				$("input[name='color']").val("")
				$("input[name='actionId']").val("")
			}
		});

		$("#create_modal_notes_tags").on('show.bs.modal', function(e) {
			//get data-id attribute of the clicked element
			var mydata = $(e.relatedTarget).data('mydata');
			console.log(mydata);
			//console.log("mydata", mydata)
			<? $arrayFields_crud_notes_tags = array(
				"notes" => ["textarea", "", "", ""],
				"tags" => ["input", "", "", "text"],
			);
			renderModalJqueryFromCrudJson($arrayFields_crud_notes_tags) ?>
		});

		$("#create_modal_add_reply").on('show.bs.modal', function(e) {
			//get data-id attribute of the clicked element
			var mydata = $(e.relatedTarget).data('mydata');
			var reply_category = $(e.relatedTarget).data('category');
			console.log("mydata", mydata)
			if (mydata != null) {
				$("#modelTitle").html("Update");
				// $("input[name='name']").val(mydata['name'])
				CKEDITOR.instances["editor"].setData(mydata['reply'])
			}
			
			
			$("input[name='reply_category']").val(reply_category);



		});
		$("#iframe_model").on('show.bs.modal', function(e) {
			//get data-id attribute of the clicked element
			var mydata = $(e.relatedTarget).data('mydata');
			if (mydata != null) {
			    var id=mydata['id'];
			    var link = "./tickets.php?id="+id+"&iframe=1";
			    $('#pastTicketIframe').attr("src", link);
			    link = "./tickets.php?id="+id;
				$("a[name='iframeLink']").attr('href', link);
			}
		});

		$("#create_record_modal").on('show.bs.modal', function(e) {
			//get data-id attribute of the clicked element
			var mydata = $(e.relatedTarget).data('mydata');
			console.log(mydata);
			//console.log("mydata", mydata)
			if (mydata != null) {
				$("#modelTitle").html("Update");
				<? foreach ($arrayFields_crud as $col => $info) {
					if ((strpos($info[1], "hidden") == false) && !in_array($info[3], ["file", "image"])) { ?>
						<? if (!in_array($info[3], ["checkbox", "radio"])) { ?>
							$("<? echo $info[0] ?>[name='<? echo $col ?><? if ((strpos($info[1], 'multiple') !== false)) {
																			echo '[]';
																		} ?>']").val(mydata['<? echo $col ?>'])
						<? } else { ?>
							if (mydata['<? echo $col ?>'] != "") {
								isChecked = true;
							} else {
								isChecked = false;
							}
							$("<? echo $info[0] ?>[name='<? echo $col ?><? if ((strpos($info[1], 'multiple') !== false)) {
																			echo '[]';
																		} ?>']").prop('checked', isChecked);
						<? } ?>
				<? }
				} ?>
				$("input[name='actionId']").val(mydata['id'])
			} else {
				$("#modelTitle").html("Insert");
				$("input[name='actionId']").val("")
				<? foreach ($arrayFields_crud as $col => $info) {
					if ((strpos($info[1], "hidden") == false) && !in_array($info[3], ["file", "image"])) { ?>
						<? if (!in_array($info[3], ["checkbox", "radio"])) { ?>
							$("<? echo $info[0] ?>[name='<? echo $col ?><? if ((strpos($info[1], 'multiple') !== false)) {
																			echo '[]';
																		} ?>']").val("")
						<? } ?>
				<? }
				} ?>

				$("input[name='actionId']").val("")

			}

		});
	})
	
	isCheckedAll = false;
	function selectAll_tickets(){
	    if(!isCheckedAll){
	        $("input[type='checkbox']").attr('checked', $($(this).is(":checked")));  
	        $("input[type='checkbox']").click()
	    }else{
	        $("input[type='checkbox']").attr('checked', false);
	    }
	    isCheckedAll = !isCheckedAll;
	    
	}
	
// 	atleastOneChecked = false;
// 	for(i=0; i<$("input[type='checkbox']").length; i++){
// 	    if($($("input[type='checkbox']")[i])){
// 	        atleastOneChecked = true;
// 	    }
// 	}
    hrefsEnabled = false;
    $('.text-underline').click(function(e){
        console.log("preventDefault", hrefsEnabled)
      if( !hrefsEnabled ){
          
        e.preventDefault();
      }
    });
	
	$("input[type='checkbox']").click(function(){
	    for(i=0; i<$("input[type='checkbox']").length; i++){
	        if($($("input[type='checkbox']")[i]).is(':checked')){
        	    $($(".kt-todo__item")[i+1]).css("background-color","rgb(240, 240, 240)")
        	   // $($(".kt-todo__item")[i+1]).click(false);
        	    hrefsEnabled = false;
        	}else{
        	    $($(".kt-todo__item")[i+1]).css("background-color","white")
        	}
	    }
	    
	    if(!$($("input[type='checkbox']")).is(':checked')){
	        hrefsEnabled = true;
	    }
	    
	})
	
	
	$(".dropdown-menu-tags").click(function(e){
      e.stopPropagation();
    });
</script>




</html>