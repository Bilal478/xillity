<?require("./global.php");
$primaryTableName = "logs";

?>
<!DOCTYPE html>


<html lang="en">
	
	<!-- begin::Head -->
	<head><?require("./includes/views/head.php")?>
    <style>
        td{
            white-space: nowrap;
        }
        .table th, .table td {
            padding: .25rem;
        }
    </style>
</head>

	<!-- end::Head -->

	<!-- begin::Body -->
	<body class="<?echo $g_body_class?>">

		<?require("./includes/views/header.php")?>
        
        	<div class="kt-grid kt-grid--hor kt-grid--root">
			<div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--ver kt-page">
				<div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-wrapper" id="kt_wrapper">

					<!-- begin:: Header -->
					
                    <?require("./includes/views/topmenu.php")?>
					<!-- end:: Header -->

					<!-- begin:: Aside -->
					<?require("./includes/views/leftmenu.php")?>

					<!-- end:: Aside -->
					<div class="kt-body kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-grid--stretch" id="kt_body">
						<div class="kt-content  kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor" id="kt_content">

							<!-- end:: Subheader -->

							<!-- begin:: Content -->
							<div class="kt-container  kt-grid__item kt-grid__item--fluid">
							    
							    <div class="kt-portlet kt-portlet--mobile">
                                    <div class="kt-portlet__head kt-portlet__head--lg">
                                        <div class="kt-portlet__head-label">
                                            <span class="kt-portlet__head-icon">
                                            </span>
                                            <h3 class="kt-portlet__head-title">
                                                <? echo ucfirst($primaryTableName); ?>
                                            </h3>
                                        </div>
                                        <div class="kt-portlet__head-toolbar">
                                            <div class="kt-portlet__head-wrapper">
                                                <div class="kt-portlet__head-actions">
                                                    <a class="btn btn-outline-primary" href="?all">View Visit logs</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="kt-portlet__body">
                                        <form action="" method="post">
                                            <? if ($g_modules_global['enableBulkDelete']) { ?>
                                                <button type="button" class="btn btn-info btn-sm text-white " onclick="selectAll();">Select All</button>
                                                <button type="submit" class="btn btn-danger btn-sm text-white ">Delete Bulk</button>
                                            <? } ?>
            
                                         
                                            <!--begin: Datatable -->
            
                                            <table class="table table-striped- table-bordered table-hover table-checkable add-search" id="kt_table_1">
                                                <thead>
                                                    <tr>
                                                        <th>Page</th>
                                                        <th>Name</th>
                                                        <th>Date Time</th>
                                                        <th>URL</th>
                                                        
                                                        <th>IP Address</th>
                                                        <th>Get Variable</th>
                                                        <th>Post Variable</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                    if(!isset($_GET['all'])){
                                                        $filter = " and (get_method!='[]' or post_method!='[]') ";
                                                    }
                                                    
                                                    $query = "select * from ".$g_projectSlug."_log t where t.userId like '%$session_userId_filter%' $filter order by t.timeAdded desc";
                                                    // echo $query;
                                                    // exit;
                                                    $results = getAll($con, $query);
                                                    foreach ($results as $row) {
                                                    ?>
                                                        <tr>
                                                            <td><?php echo str_replace(".php","",ucfirst($row['page'])) ?></td>
                                                            
                                                            <td><?php echo $g_allUsersInfo[$row['userId']]['name'] ?></td>
                                                            
                                                            <td><?php echo date("D, d M Y h:i",$row['timeAdded']) ?></td>
                                                            <td><a href="<?php echo $row['url'] ?>" target="_blank"><?php echo $row['url'] ?></a></td>
                                                            <td><?php echo $row['ip'] ?></td>
                                                            <td>
                                                                <?php
                                                                $get_method = json_decode($row['get_method']);
                                                                foreach ($get_method as $key => $value) {
                                                                    echo "<b>" . $key . "</b>" . ": " . $value . "<br>";
                                                                }
                                                                ?>
                                                            </td>
                                                            <td>
                                                                <?php
                                                                $post_method = json_decode($row['post_method'], true);
            
                                                                foreach ($post_method as $key => $value) {
                                                                    echo "<b>" . $key . "</b>" . ": " . $value . "<br>";
                                                                }
                                                                ?>
                                                            </td>
                                                        </tr>
                                                    <?php
                                                    }
                                                    ?>
                                                </tbody>
            
                                            </table>
            
            
            
                                        </form>
                                        <!--end: Datatable -->
                                    </div>
                                </div>
							</div>

							
							

							<!-- end:: Content -->
						</div>
					</div>

					<!-- begin:: Footer -->
					
					<?require("./includes/views/footer.php")?>

					<!-- end:: Footer -->
				</div>
			</div>
		</div>
        
        
        <?require("./includes/views/footerjs.php")?>
		

	</body>

						
</html>