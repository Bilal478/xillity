<? require("./global.php");

//customers
$arrayFields_crud = array(
    // field_name [type, isrequired, array_select, inner_type, small_comment] <= "template"
    "name" => ["input", "required", "", "text", ""],
    "email" => ["input", "required", "", "email", ""],
    // "password" => ["input", " $login_fields_hidden ", "", "password", "Type password to set/change password"],
    "phone" => ["input", "required", "", "text", ""],
    "address" => ["textarea", "required", "", "address", ""],
// 	"addedBy" => ["input", "required hidden value='$session_userId'", "", "text", ""],
    "role" => ["input", "required hidden value='customer'", "", "text", ""],
);

$primaryTableName = "View Pipelines";

array(
	// field_name [type, isrequired, array_select, inner_type] <= "template"
	"pipeline_name" => ["input", "", "", "text"],
	"description" => ["input", "", "", "text"],
	"color" => ["input", "", "", "text"],
	// "document" => ["input", "", "", "file"],
);



if (isset($_POST['create_package'])) {
	$timeAdded = time();
	$actionId = escape(($_POST['actionId']));
	$pipeline_name = escape($_POST['pipeline_name']);
	$description = escape($_POST['description']);
	$color = escape($_POST['color']);
	if ($actionId == "") {
		$id = generateRandomString();
		$actionId = $id;
		$query = "insert into " . $g_projectSlug . "_pipelines set id='$id' , pipeline_name='$pipeline_name', description='$description', color='$color', timeAdded='$timeAdded', userId='$session_userId' ";
	} else {
		$query = "update " . $g_projectSlug . "_pipelines set id='$actionId' , pipeline_name='$pipeline_name', description='$description', color='$color' where id='$actionId'";
	}
	$stmt = $con->prepare($query);
	if (!$stmt) {
		echo "err: <code>$query</code>";
	}
	if (!$stmt->execute()) {
		echo "err: <code>$query</code>";
	}

	$rStr = "";
	if (isset($_GET['id'])) {
		$rStr .=  "&id=" . $_GET['id'];
	}
	header("Location: ?m=Data was saved successfully!" . $rStr);
}

if(isset($_GET['userIds']) && isset($_GET['pipelineIds'])){
    
    $userId = $_GET['userIds'];
    $newPipelineId = $_GET['pipelineIds'];

    // Update the user's assign_pipeline field in the database
    $stmt = $con->prepare("UPDATE ".$g_projectSlug."_users SET current_pipeline_stage = ? WHERE id = ?");
    $stmt->bind_param("ss", $newPipelineId, $userId);

    if ($stmt->execute()) {
        // Database update successful
        echo json_encode(['status' => 'success']);
    } else {
        // Database update failed
        echo json_encode(['status' => 'error', 'error_message' => $stmt->error]);
    }

}
if (isset($_GET['delete-record'])) {
	$id = escape($_GET['delete-record']);
	if ($id != "admin") {
		$stmt = $con->prepare("delete from " . $g_projectSlug . "_pipelines where id=?");
		$stmt->bind_param("s", $id);
		if (!$stmt->execute()) {
			echo "err";
		}
	}
}


?>
<!DOCTYPE html>


<html lang="en">
<!--begin::Page Custom Styles(used by this page) -->
<link href="assets/plugins/custom/kanban/kanban.bundle.css" rel="stylesheet" type="text/css" />

<!--end::Page Custom Styles -->

<!-- begin::Head -->

<head><? require("./includes/views/head.php") ?>
<style>
    
.kanban-item:hover {
  cursor: move;
}
</style>
<!-- <style>
* {
	box-sizing: border-box;
}

body {
	background: #33363D;
	color: white;
	font-family: 'Roboto', sans-serif;
	font-weight: 400;
	line-height: 1.5;
  text-align: center;
	-webkit-font-smoothing: antialiased;
}

h1 {
  font-size: 40px;
  font-weight: 500;
  letter-spacing: 1px;
}

h2 {
	font-size: 16px;
	margin: 0;
	text-transform: uppercase;
	font-weight: 400;
}

h4 {
	font-size: 18px;
}

a {
	color: #00BCD4;
	font-weight: 500;
	text-decoration: none;
}

/* Intro */

header {
	padding: 20px;
	text-align: center;
}

/* Kanban board */

.kanban-container {
	margin: 20px auto;
	max-width: 1000px;
}

ul {
	list-style-type: none;
	padding: 0;
}

.kanban-list {
	display: flex;
	align-items: flex-start;
}

.kanban-column {
	flex: 1;
	margin: 0 10px;
	position: relative;
	background: rgba(0, 0, 0, 0.2);
	overflow: hidden;
}

.kanban-column-header {
	display: flex;
	align-items: center;
	justify-content: space-between;
	padding: 10px;
}

.header-onhold {
	background: #FF9800;
}

.header-inprogress {
	background: #009688;
}

.header-approved {
	background: #8BC34A;
}

.drag-inner-list {
	min-height: 50px;
}

.drag-item {
	margin: 10px;
	height: 100px;
	background: rgba(0, 0, 0, 0.4);
}


/* micro-interactions */
/* add glowing border here */


/* mobile */

@media (max-width: 690px) {
	.kanban-list {
		display: block;
	}

	.kanban-column {
		margin-bottom: 30px;
	}
}

</style> -->
</head>

<!-- end::Head -->

<!-- begin::Body -->

<body class="<? echo $g_body_class ?>">

	<? require("./includes/views/header.php") ?>

	<div class="kt-grid kt-grid--hor kt-grid--root">
		<div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--ver kt-page">
			<div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-wrapper" id="kt_wrapper">

				<!-- begin:: Header -->

				<? require("./includes/views/leftmenu.php") ?>
				<!-- end:: Header -->

				<!-- begin:: Aside -->
				<? require("./includes/views/topmenu.php") ?>

				<!-- end:: Aside -->
				<div class="kt-body kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-grid--stretch" id="kt_body">
					<div class="kt-content  kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor" id="kt_content">

						<!-- end:: Subheader -->

						<!-- begin:: Content -->
						<div class="kt-container  kt-grid__item kt-grid__item--fluid">

							<? if (isset($_GET['m'])) { ?>
								<div class="alert alert-info"><? echo $_GET['m'] ?></div>
							<? } ?>

							<div class="kt-portlet kt-portlet--mobile">
								<div class="kt-portlet__head kt-portlet__head">
									<div class="kt-portlet__head-label">
										<span class="kt-portlet__head-icon">
										</span>
										<h3 class="kt-portlet__head-title">
											<? echo ucfirst($primaryTableName) ?>
										</h3>
									</div>
									<div class="kt-portlet__head-toolbar">
										<div class="kt-portlet__head-wrapper">
											<div class="kt-portlet__head-actions">
											    <?if($session_role=="admin"){?>
												<a href="./pipelines.php" class="btn btn-primary">Manage Pipelines</a>
												<?}?>
											</div>
										</div>
									</div>
								</div>
								<div class="kt-portlet__body">
								  <div class="kanban-container" style="width: 1250px;">
                                       
									   <?$getPipelines=getAll($con,"SELECT * FROM ".$g_projectSlug."_pipelines")?>
										   
									   <?foreach($getPipelines as $pipelines){?>
										   <div data-id="_todo" data-order="1"  data-pipelineids="<?echo $pipelines['id']?>" class="kanban-board" style="width: 250px; height:380px; margin-left: 0px; margin-right: 0px;">
											   <header class="kanban-board-header brand py-3" style="background-color:<?echo $pipelines['color']?> !important;">
											   		<div class="kanban-title-board text-center"><?echo $pipelines['pipeline_name'] ?></div>
											   </header>
											   <?$pipline_id= $pipelines['id']?>
											   <main class="kanban-drag">
												   <? $query=getAll($con,"SELECT * FROM ".$g_projectSlug."_users where current_pipeline_stage='$pipline_id'")?>
												   <?foreach($query as $row){?>
														<div data-ids="<?echo $row['id']?>" class="kanban-item p-2" 
															href="#" data-toggle="modal" data-target="#create_record_modal" 
															data-mydata='<?php echo json_encode($row, JSON_HEX_QUOT | JSON_HEX_TAG); ?>' 
															data-class="info" draggable="true"><?echo $row['name']?><br><span 
															style="font-size:12px;"><?echo $row['email']?></span>
														</div>
												   <?}?>
											   </main>
											   <footer></footer>
										   </div>
										  <?}?>
								   </div>

     
										
									</div>
								</div>
							</div>


						


						<!-- end:: Content -->
					</div>
				</div>

				<!-- begin:: Footer -->

				<? require("./includes/views/footer.php") ?>

				<!-- end:: Footer -->
			</div>
		</div>
	</div>

	<? require("./includes/views/footerjs.php") ?>

</body>

<!-- end::Body -->

	<div class="modal fade" id="create_record_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="modelTitle">View</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					</button>
				</div>
				<div class="modal-body">
					
					<form class="kt-form" action="" method="Post" enctype="multipart/form-data">
						<div class="kt-portlet__body">
						    
						    <?foreach($arrayFields_crud as $col => $info){
						    $col_print = $col;
						    if($col=="addedBy"){$col_print = "Assign To";}
						    ?>
						    <div class="form-group">
						        <?if(strpos($info[1], "hidden")==false){?>
								    <label><?echo ucwords(str_replace("_", " ", $col))?></label>
								    <?if($info[4]!=""){?>
								        <small><?echo $info[4]?></small>
								    <?}?>
								<?}?>
								<?if($info[0]=="input" && in_array($info[3], ["text", "email", "password", "number", "file"])){?>
								    <input type="<?echo $info[3]?>" name="<?echo $col?>" class="form-control" <?echo $info[1]?>  readonly>
								<?}else if($info[0]=="select"){?>
								    <select name="<?echo $col?>" class="form-control" <?echo $info[1]?>  readonly>
    								    <?foreach($info[2] as $i=> $option){?>
    								        <option value="<?echo $i?>"><?echo $option?></option>
    								    <?}?>
								    </select>
								<?}else if($info[0]=="input" && in_array($info[3], ["image"])){?>
								    <input type="file" name="<?echo $col?>" class="form-control" readonly <?echo $info[1]?>  >
								<?}else if($info[0]=="textarea"){?>
								    <textarea type="text" name="<?echo $col?>" class="form-control" readonly <?echo $info[1]?>  ></textarea>
								<?}else{?>
								    <code><?echo $col?> Couldn't render</code>
								<?}?>
							</div>
							<?}?>
						
							<input type="text" name="actionId" value="" hidden>
							
						</div>
						<?if($g_modules_global['enableCustomerProfile']){?>
    						<div class="kt-portlet__foot">
    							<div class="kt-form__actions">
    								<a href="" id="view-user" class="btn btn-block btn-primary">View Profile</a>
    								<!--<input type="submit" name="create_package" value="Submit" class="btn btn-primary">-->
    								<!--<button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>-->
    							</div>
    						</div>
						<?}?>
					</form>
				</div>
			
			</div>
		</div>
	</div>
	
	
	<script>
	    $(document).ready(function(){
	    	

          $("#create_record_modal").on('show.bs.modal', function (e) {
            //get data-id attribute of the clicked element
            var mydata = $(e.relatedTarget).data('mydata');
            console.log(mydata);
            //console.log("mydata", mydata)
            if(mydata!= null){
            	<?foreach($arrayFields_crud as $col => $info){
            	   if(strpos($info[1], "hidden")==false){?>
                    $("<?echo $info[0]?>[name='<?echo $col?>']").val(mydata['<?echo $col?>'])
                <?}}?>
                 $("#view-user").attr("href", "./view_user.php?id="+mydata['id']);

            }

            
          });
	    })
	</script>
				
		
<script>

$(document).ready(function() {
  let lastDropTarget = null; // Track the last drop target

  $('.kanban-item')
    .on('dragstart', function(e) {
      e.originalEvent.dataTransfer.setData('text/plain', $(this).data('ids'));
      e.originalEvent.dataTransfer.setData('listItem', $(this).index());
      e.originalEvent.dataTransfer.setData('listBoard', $(this).closest('.kanban-board').index());
    })
    .on('dragend', function(e) {
      // Save the updated item positions to local storage
      //saveItemPositions();
	  //$("body").css("display","none");
    });

  // Attach the event listeners to elements with class 'kanban-board'
  $('.kanban-board')
    .on('drop', function(e) {
      e.preventDefault();
      lastDropTarget = $(this); // Set the last drop target
      $(this).removeClass('drop-zone-active');
      let listItemIndex = e.originalEvent.dataTransfer.getData('listItem');
      let listBoardIndex = e.originalEvent.dataTransfer.getData('listBoard');
      let sourceBoard = $('.kanban-board').eq(listBoardIndex);
	  
	  
	   // Check if the source and target boards are the same
    if (sourceBoard[0] !== $(this)[0]) {
      // Append the item to the target board
      $(this).find('.kanban-drag').append(sourceBoard.find('.kanban-item').eq(listItemIndex));

      // Remove the item from the source board
      sourceBoard.find('.kanban-item').eq(listItemIndex).remove();
    }

      

	  
      // Save the updated item positions to local storage
      let draggedItemId = e.originalEvent.dataTransfer.getData('text/plain');
      let droppedPipelineId = lastDropTarget.data('pipelineids'); // Use lastDropTarget here
	  console.log(draggedItemId);
	  console.log(droppedPipelineId);
      updateAssignPipeline(draggedItemId, droppedPipelineId);

    })
    .on('dragover', function(e) {
      e.preventDefault();
    })
    .on('dragenter', function(e) {
      $(this).addClass('drop-zone-active');
    })
    .on('dragleave', function(e) {
      $(this).removeClass('drop-zone-active');
    });

	function updateAssignPipeline(userId, pipelineId) {
            // Send an AJAX request to update the user's assign_pipeline
            $.ajax({
                type: 'GET',
                url: '', // Replace with your PHP script to update the database
                data: {
                    userIds: userId,
                    pipelineIds: pipelineId
                },
                success: function (response) {
                   // window.location.href = './view_pipeline.php';
				   console.log("Item moved successfully");
                    toastr.success('Data updated successfully', 'Success');
                },
                error: function (error) {
					//window.location.href = './view_pipeline.php';
					 console.log("Error moving item");
                }
            });
        }
});




				// updateAssignPipeline(draggedItemId, droppedPipelineId);
		// draggedItemId="";
		//e.originalEvent.dataTransfer.setData('text/plain', $(this).data('id'));
</script>





</html>