<?  require("./global.php");
$primaryTableName = "questionnaires_answers";

$questionnaire_id = $_GET['id'];

$arrayFields_crud = array(
    // field_name [type, isrequired, array_select, inner_type] <= "template"
    "question_id" => ["input", "required", "", "text"],
    "answer" => ["input", "required", "", "text"],
    "questionnaire_id" => ["input", "hidden value='$questionnaire_id'", "", "text"],
);

//for generating table generation queries
if(false){
    $t = "DROP TABLE IF EXISTS ".$g_projectSlug."_".$primaryTableName."; CREATE TABLE ".$g_projectSlug."_".$primaryTableName."(<br>id VARCHAR(200) PRIMARY KEY,<br>";
    foreach($arrayFields_crud as  $col => $info){
        if((strpos($info[1], 'multiple') !== false) || $col[0]=="textarea"){$textSide = "longtext";}else{$textSide = "VARCHAR(256)";}
        $t.= "$col $textSide DEFAULT '' ,<Br>";
    }
    $t.= "timeAdded VARCHAR(256) NULL,<br>userId VARCHAR(256) NULL);";
    echo "<code>$t</code>";
}

//for insert & update
if(isset($_POST['question'])){
    $answer = $_POST['answer'];
    $question = $_POST['question'];
    $question_type = $_POST['question_type'];
    $imageI = 0;
    

    for($i=0;$i<count($question);$i++)
    {
        $question_i = mb_htmlentities($question[$i]);
        $answer_i = mb_htmlentities($answer[$i]);
        $question_type_i = mb_htmlentities($question_type[$i]);
        
        
        
        if($question_type_i=="Audio Answers"){
            
            //upload pics
            if(isset($_FILES['fileToUpload'])){
        
                //upload pic
                if(isset($_FILES["fileToUpload"])){
                        $random = generateRandomString();
                        $target_dir = "./uploads/";
                        $fileName_db = "Anomoz_"."$random".basename($_FILES["fileToUpload"]["name"][$imageI]);
                        $realname =  basename($_FILES["fileToUpload"]["name"]);
                        $target_file = $target_dir . "Anomoz_"."$random".basename($_FILES["fileToUpload"]["name"][$imageI]);
                        $uploadOk = 1;
                        $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
                        // Check if image file is a actual image or fake image
                        if($_FILES["fileToUpload"]["tmp_name"][$imageI]!="") {
                            
                            $uploadOk = 1;
                        
                            // Check if file already exists
                            if (file_exists($target_file)) {
                                //echo "Sorry, file already exists.";
                                $filename=basename( $_FILES["fileToUpload"]["name"][$imageI]);
                                $uploadOk = 1;
                            }
                            // Check file size
                            if ($_FILES["fileToUpload"]["size"][$imageI] > 500000000000000000000) {
                                echo "Sorry, your file is too large.";
                                $uploadOk = 0;
                            }
                            // Allow certain file formats
                            if(false) {
                                echo "Sorry, only JPG, JPEG, PNG, & GIF files are allowed.";
                                $uploadOk = 0;
                            }
                            // Check if $uploadOk is set to 0 by an error
                            if ($uploadOk == 0) {
                                echo "Sorry, your file was not uploaded.";
                            // if everything is ok, try to upload file
                            } else {
                                if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"][$imageI], $target_file)) {
                                    echo "The file ". basename( $_FILES["fileToUpload"]["name"][$imageI]). " has been uploaded.";
                                    $filename=basename( $_FILES["fileToUpload"]["name"][$imageI]);
                                    $uploadOk = 1;
                                } else {
                                    echo "Sorry, there was an error uploading your file.";
                                }
                            }
                        }
                        
                        $imageI = $imageI+1;
                    
                }
                
                if(($filename!="Noe") && ($uploadOk=='1')){
                    $answer_i = $fileName_db;
                }

            }
                    
        }    
    
    
        $survey_id = mb_htmlentities(($_GET['id']));
        $userId = mb_htmlentities(($_GET['userId']));
        $timeAdded = time();
        
        //echo $question_i."->".$answer_i."->".$question_type_i."<br>";
        $sql="insert into aida_responses (`question_id`, `answer`,`surveyId`, `timeAdded`, `userId`, `ip`) values ('$question_i', '$answer_i', '$survey_id', '$timeAdded', '$userId', '')";
        if(!mysqli_query($con,$sql))
        {
            echo "err";
        }
        
        
        
    }
    

    ?>
    <script type="text/javascript">
        window.location = "./survey_submitted.php";
    </script>
    <?
    
    
}

?>
<!DOCTYPE html>


<html lang="en">

	<!-- begin::Head -->
	<head><?require("./includes/views/head.php")?>
</head>

	<!-- end::Head -->

	<!-- begin::Body -->
	<body class="<?echo $g_body_class?>">

		<?require("./includes/views/header.php")?>
        
        	<div class="kt-grid kt-grid--hor kt-grid--root">
			<div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--ver kt-page">
				<div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-wrapper" id="kt_wrapper">

					<!-- begin:: Header -->
					
                    <?require("./includes/views/topmenu.php")?>
					<!-- end:: Header -->

					<!-- begin:: Aside -->
					<?require("./includes/views/leftmenu.php")?>

					<!-- end:: Aside -->
					<div class="kt-body kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-grid--stretch" id="kt_body">
						<div class="kt-content  kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor" id="kt_content">

							<!-- end:: Subheader -->

							<!-- begin:: Content -->
							<div class="kt-container  kt-grid__item kt-grid__item--fluid">
							    
							    <?if(isset($_GET['m'])){?>
							        <div class="alert alert-info"><?echo $_GET['m']?></div>
							    <?}?>

								<div class="kt-portlet kt-portlet--mobile">
									<div class="kt-portlet__head kt-portlet__head--lg">
										<div class="kt-portlet__head-label">
											<span class="kt-portlet__head-icon">
											</span>
											<h3 class="kt-portlet__head-title">
												<?echo ucfirst(str_replace("_", " ", $primaryTableName));?>
											</h3>
										</div>
										<div class="kt-portlet__head-toolbar">
											<div class="kt-portlet__head-wrapper">
												<div class="kt-portlet__head-actions">
												    
												    
												</div>
											</div>
										</div>
									</div>
									<div class="kt-portlet__body">
                                        <form action="" method="post">
                                           
    										<!--begin: Datatable -->
    										
    										
    										 <?$query = "select * from ".$g_projectSlug."_"."questionnaires_questions"." t where t.questionnaire_id='$questionnaire_id' order by timeAdded desc";
    										 $results = getAll($con, $query);
    										 foreach($results as  $row){?>
    										<div class="mb-3 card">
                                                <div class="card-header-tab card-header-tab-animation card-header">
                                                    <div class="card-header-title">
                                                        <?echo $row['question']?> 
                                                    </div>
                                                    
                                                </div>
                                                <div class="card-body">
                                                    <div class="row">
                                                        
                                                        <input required hidden type="text" name="question[]" value="<?echo $row['id']?>">
                                                        <input required hidden type="text" name="question_type[]" value="<?echo $row['type']?>">
                                                        
                                                        <?if($row['type']=="Short Answer"){?>
                                                            
                                                            <div class="col-md-12">
                                                                <input required type="text" name="answer[]" class="form-control" placeholder="Response" />
                                                            </div>
                                                            
                                                        <?}else if ($row['type']=="Long Answer"){?>
                                                            
                                                            <div class="col-md-12">
                                                                <textarea required type="text" name="answer[]" class="form-control" placeholder="Question" ></textarea>
                                                            </div>
                                                            
                                                        <?}else if ($row['type']=="Multiple Choice"){?>
                                                            <?
                                                            $html = json_decode($row['html'], true);
                                                            ?>
                                                            <div class="col-md-12">
                                                                <div class="form-group">
                                                                    <select class="form-control" name="answer[]" id="type">
                                                                        <option value="<?echo $html['A']?>"><?echo  $html['A']?></option>
                                                                        <option value="<?echo $html['B']?>"><?echo  $html['B']?></option>
                                                                        <option value="<?echo $html['C']?>"><?echo  $html['C']?></option>
                                                                        <option value="<?echo $html['D']?>"><?echo  $html['D']?></option>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                        <?}else if ($row['type']=="Score Answers"){?>
                                                            <?
                                                            $html = json_decode($row['html'], true);
                                                            ?>
                                                            <div class="col-md-12">
                                                                <div class="form-group">
                                                                    <div class="range-slider">
                                                                        <div class="range-slider ">
                                                                          <input required class="range-slider__range " name="answer[]" type="range" value="<?echo (($html['score_min']+$html['score_max'])/2)?>" min="<?echo $html['score_min']?>" max="<?echo $html['score_max']?>">
                                                                          <span class="range-slider__value">0</span>
                                                                        </div> 
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            
                                                        <?}else if ($row['type']=="File Upload Answers"){?>
                                                            
                                                           <div class="col-md-12">
                                                               <?
                                                            $html = json_decode($row['html'], true);
                                                            ?>
                                                              
                                                                <label for="exampleFormControlInput1">Upload Response File</label>
                                                                <input required hidden  value="--" type="text" name="answer[]" class="form-control" placeholder="Question" />
                                                                <input required type="file" accept="*" name="fileToUpload[]" class="form-control" id="exampleFormControlInput1" />
                                                                
                                                              
            
                                                            </div>
                                                            
                                                         <?}else if ($row['type']=="True False Question"){?>
                                                            
                                                           <div class="col-md-12">
                                                               <?
                                                            $html = json_decode($row['html'], true);
                                                            ?>
                                                            
                                                                <select class="form-control" name="answer[]" id="type">
                                                                        <option value="True">True</option>
                                                                        <option value="False">False</option>
                                                                    </select>
                                                                    
                                                                    
                                                            </div>
                                                            
                                                         <?}else if ($row['type']=="Yes No Question"){?>
                                                            
                                                           <div class="col-md-12">
                                                               <?
                                                            $html = json_decode($row['html'], true);
                                                            ?>

                                                                 <select class="form-control" name="answer[]" id="type">
                                                                        <option value="Yes">Yes</option>
                                                                        <option value="No">No</option>
                                                                    </select>
                                                                    
                                                                </div>
                                                            
                                                         <?}else if ($row['type']=="Rating Question"){?>
                                                            
                                                           <div class="col-md-12">
                                                               <?
                                                            $html = json_decode($row['html'], true);
                                                            ?>
                                                            
                                                            <div class="rating">
                                                                <span><input required type="radio" name="answer[]" id="str5" value="5"><label for="str5"></label></span>
                                                                <span><input required type="radio" name="answer[]" id="str4" value="4"><label for="str4"></label></span>
                                                                <span><input required type="radio" name="answer[]" id="str3" value="3"><label for="str3"></label></span>
                                                                <span><input required type="radio" name="answer[]" id="str2" value="2"><label for="str2"></label></span>
                                                                <span><input required type="radio" name="answer[]" id="str1" value="1"><label for="str1"></label></span>
                                                            </div>
                                                            
                                                            </div>
                                                                         
                                                         <?}else if ($row['type']=="Phonenumber Question"){?>
                                                            
                                                           <div class="col-md-12">
                                                               <div class="col-md-12">
                                                                <input required type="text" name="answer[]" class="form-control" id="exampleFormControlInput1" placeholder="Phone number" />
                                                            </div>
                                                            </div>
                                                                                                               
                                                         <?}else if ($row['type']=="Email Question"){?>
                                                            
                                                           <div class="col-md-12">
                                                               <div class="col-md-12">
                                                                <input required type="email" name="answer[]" class="form-control" id="exampleFormControlInput1" placeholder="Email Address" />
                                                            </div>
                                                            </div>
                                                              
                                                            
                                                        <?}?>
                                                        
                                                        
                                                    </div>
                                                </div>
                                            </div>
                                            <?}?>
                                        
                                        
                                        </form>
										<!--end: Datatable -->
									</div>
								</div>
							
							
							</div>

							
							

							<!-- end:: Content -->
						</div>
					</div>

					<!-- begin:: Footer -->
					
					<?require("./includes/views/footer.php")?>

					<!-- end:: Footer -->
				</div>
			</div>
		</div>
        
        
        <?require("./includes/views/footerjs.php")?>
		

	</body>

	<!-- end::Body -->
	
	<div class="modal fade" id="create_record_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="modelTitle">Insert</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					</button>
				</div>
				<div class="modal-body">
					
					<form class="kt-form" action="" method="Post" enctype="multipart/form-data">
						<div class="kt-portlet__body">
						    
						    <?foreach($arrayFields_crud as $col => $info){?>
						    <div class="form-group">
						        <?if(strpos($info[1], "hidden")===false){?>
								    <label><?echo ucfirst(str_replace("_", " ", $col))?></label>
								    <?if($info[4]!=""){?>
								        <small><?echo $info[4]?></small>
								    <?}?>
								<?}?>
								<?if($info[0]=="input" && in_array($info[3], ["text", "email", "password", "number", "file", "date", "time", "color", "datetime", "checkbox", "radio"])){?>
								    <?if(in_array($info[3], ["checkbox", "radio"])){?>
								        <?foreach($info[2] as $i=> $option){?>
    								        <div class="form-check">
                                              <input name="<?echo $col?><?if((strpos($info[1], 'multiple') !== false)){echo '[]'; }?>" class="form-check-input" type="<?echo $info[3]?>" value="<?echo $i?>" id="<?echo $col?>" <?echo $info[1]?>>
                                              <label class="form-check-label" for="<?echo $col?>">
                                                <?echo ucfirst(str_replace("_", " ", $option))?>
                                              </label>
                                            </div>
                                        <?}?>
								    <?}else{?>
								    <input type="<?echo $info[3]?>" name="<?echo $col?><?if((strpos($info[1], 'multiple') !== false)){echo '[]'; }?>" class="form-control" <?echo $info[1]?>  >
								    <?}?>
								<?}else if($info[0]=="select"){?>
								    <select name="<?echo $col?><?if((strpos($info[1], 'multiple') !== false)){echo '[]'; }?>" class="form-control" <?echo $info[1]?>  >
    								    <?foreach($info[2] as $i=> $option){?>
    								        <option value="<?echo $i?>"><?echo $option?></option>
    								    <?}?>
								    </select>
								<?}else if($info[0]=="input" && in_array($info[3], ["image"])){?>
								    <input type="file" name="<?echo $col?><?if((strpos($info[1], 'multiple') !== false)){echo '[]'; }?>" class="form-control" <?echo $info[1]?>  >
								<?}else if($info[0]=="textarea"){?>
								    <textarea type="text" name="<?echo $col?>" class="form-control" <?echo $info[1]?>  ></textarea>
								<?}else{?>
								    <code><?echo $col?> Couldn't render</code>
								<?}?>
							</div>
							<?}?>
						
							<input type="text" name="actionId" value="" hidden>
							
						</div>
						<div class="kt-portlet__foot">
							<div class="kt-form__actions">
								<input type="submit" name="create_package" value="Submit" class="btn btn-primary">
								<button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
							</div>
						</div>
					</form>
				</div>
			
			</div>
		</div>
	</div>
	
	
	<script>
	    $(document).ready(function(){
	    	
          $("#create_record_modal").on('show.bs.modal', function (e) {
            //get data-id attribute of the clicked element
            var mydata = $(e.relatedTarget).data('mydata');
            console.log(mydata);
            //console.log("mydata", mydata)
            if(mydata!= null){
            	$("#modelTitle").html("Update");
            	<?foreach($arrayFields_crud as $col => $info){
            	    if((strpos($info[1], "hidden")===false) && !in_array($info[3], ["file", "image"])){?>
            	        <?if(!in_array($info[3], ["checkbox", "radio"])){?>
                            $("<?echo $info[0]?>[name='<?echo $col?><?if((strpos($info[1], 'multiple') !== false)){echo '[]'; }?>']").val(mydata['<?echo $col?>'])
                        <?}else{?>
                            if(mydata['<?echo $col?>']!=""){isChecked = true;}else{isChecked = false;}
                            $("<?echo $info[0]?>[name='<?echo $col?><?if((strpos($info[1], 'multiple') !== false)){echo '[]'; }?>']").prop('checked', isChecked);
                        <?}?>
                <?}}?>
                $("input[name='actionId']").val(mydata['id'])
            }else{
            	$("#modelTitle").html("Insert");
                $("input[name='actionId']").val("")
                <?foreach($arrayFields_crud as $col => $info){
                    if((strpos($info[1], "hidden")===false) && !in_array($info[3], ["file", "image"])){?>
                        <?if(!in_array($info[3], ["checkbox", "radio"])){?>
                            $("<?echo $info[0]?>[name='<?echo $col?><?if((strpos($info[1], 'multiple') !== false)){echo '[]'; }?>']").val("")
                        <?}?>
                <?}}?>

                $("input[name='actionId']").val("")
                
            }

          });
	    })
	</script>
				
		
								
</html>