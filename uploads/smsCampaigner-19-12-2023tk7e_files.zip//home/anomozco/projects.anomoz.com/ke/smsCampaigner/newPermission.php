<?

if(!isset($_GET['userId']))
{
    // header("Location:./home.php");
}

require("./global.php");
$modules=array("Customers");
$permissions=array("Read","Edit","Delete");


if(isset($_POST['submit_permissions']))
{
    $userId=$_POST['userId'];
    $query="delete from " . $g_projectSlug . "_permissions where userId='$userId'";
    $result=$con->query($query);
    foreach($_POST['myCheckbox'] as $checkbox) 
    {
        $value=explode("_",$checkbox);  //string format module_permission
        $id=generateRandomString();
        $query="insert into " . $g_projectSlug . "_permissions set id='$id' , userId='$userId' , permission='$value[1]' ,module='$value[0]' ";
        $result=$con->query($query);
        if(!$result)
            echo $con->error;
    }  
}
?>


<!DOCTYPE html>


<html lang="en">

	<!-- begin::Head -->
	<head><?require("./includes/views/head.php")?>

</head>

	<!-- end::Head -->

	<!-- begin::Body -->
	<body class="<?echo $g_body_class?>">

		<?require("./includes/views/header.php")?>
        
        	<div class="kt-grid kt-grid--hor kt-grid--root">
			<div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--ver kt-page">
				<div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-wrapper" id="kt_wrapper">

					<!-- begin:: Header -->
					
                    <?require("./includes/views/topmenu.php")?>
					<!-- end:: Header -->

					<!-- begin:: Aside -->
					<?require("./includes/views/leftmenu.php")?>

					<!-- end:: Aside -->
					<div class="kt-body kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-grid--stretch" id="kt_body">
						<div class="kt-content  kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor" id="kt_content">

							<!-- end:: Subheader -->

							<!-- begin:: Content -->
							<form action="" enctype="multipart/form-data" method="post">
							<div class="kt-container  kt-grid__item kt-grid__item--fluid">
							    <div class="kt-portlet kt-portlet--mobile">
									<div class="kt-portlet__head kt-portlet__head--lg">
										<div class="kt-portlet__head-label">
											<span class="kt-portlet__head-icon">
											</span>
											<h3 class="kt-portlet__head-title">
												Permissions
											</h3>
										</div>
										<div class="kt-portlet__head-toolbar">
											<div class="kt-portlet__head-wrapper">
												<div class="kt-portlet__head-actions">
												    <input type="submit" value="Update Permissions" class="btn btn-primary" name="submit_permissions">
												</div>
											</div>
										</div>
									</div>
									<div class="kt-portlet__body">

										<!--begin: Datatable -->
										<table class="table table-striped- table-bordered table-hover table-checkable add-search" id="kt_table_1">
											<thead>
												<tr>
													<th>Module</th>
													<?foreach($permissions as $permission){?>
													<th><?echo $permission;?></th>
													<?}?>
												</tr>
											</thead>
											<tbody>
											    
                                                <?foreach($modules as $module){?> 
												<tr>
												    <input type="text" value="<?echo $_GET['userId'];?>" name="userId" hidden>
												    <td><?echo $module?></td>
												    <?foreach($permissions as $permission){?>
												    <td>
												        <div class="form-check" style=" padding-bottom:20px; ">
                                                          <input type="checkbox" value="<?echo $module."_".$permission;?>" name="myCheckbox[]" class="form-check-input">
                                                        </div>
												    </td>
												    <?}?>
												</tr>
												<?}?>
												
											</tbody>
										</table>

										<!--end: Datatable -->
									</div>
								</div>
							</div>
                            </form>
							
							

							<!-- end:: Content -->
						</div>
					</div>

					<!-- begin:: Footer -->
					
					<?require("./includes/views/footer.php")?>

					<!-- end:: Footer -->
				</div>
			</div>
		</div>
        
        
        <?require("./includes/views/footerjs.php")?>
		

	</body>

	<!-- end::Body -->
	
</html>