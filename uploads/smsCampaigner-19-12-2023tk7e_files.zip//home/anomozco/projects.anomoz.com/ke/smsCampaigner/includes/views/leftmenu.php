<?if(!isset($_GET['print'])){?>
<?if($g_modules_global['enableLeftMenu']){?>
    <button class="kt-aside-close " id="kt_aside_close_btn"><i class="la la-close"></i></button>
    <div class="kt-aside  kt-aside--fixed  kt-grid__item kt-grid kt-grid--desktop kt-grid--hor-desktop" id="kt_aside">
    
    	<div class="kt-aside-menu-wrapper kt-grid__item kt-grid__item--fluid" id="kt_aside_menu_wrapper">
    		<div id="kt_aside_menu" class="kt-aside-menu " data-ktmenu-vertical="1" data-ktmenu-scroll="1" style="margin:0px;height:100%;border-right: 1px <?echo $g_primaryColor?> solid;background: #f6fcff17 !important;backdrop-filter: blur(10px);">
    			<ul class="kt-menu__nav ">
    			    <li class=" " aria-haspopup="true"><a target="_blank" href="./home.php" class="kt-menu__link "><span class="kt-menu__link-text"><img style="height:50px;width:auto;margin: 10px;margin-bottom: 20px;" src="<? echo $g_modules_global['logo'] ?>"></span></a></li>

    				<!--<li class="kt-menu__item " aria-haspopup="true"><a target="_blank" href="./home.php" class="kt-menu__link "><span class="kt-menu__link-text"><img src="<?echo $g_modules_global['logo']?>" class="w-100 "></span></a></li>-->
    				<li class="kt-menu__item <?if($filenameLink=='home.php'){echo 'kt-menu__item--here';}?>" data-ktmenu-submenu-toggle="click" aria-haspopup="true">
                        <a href="./home.php" class="kt-menu__link"><i class="kt-menu__link-icon <?echo $icons_array["home.php"]?> text-primary"></i><span class="kt-menu__link-text">Home</span><i class="kt-menu__ver-arrow fa fa-angle-right text-primary" style="font-size: 15px;"></i></a>
                    </li>
    				<?
    				$menuItems[] = ['?logout=1', 'Logout'];
    				foreach($menuItems as $menuItem){?>
    				    <li class="kt-menu__item <?if($filenameLink==$menuItem[0]){echo 'kt-menu__item--here';}?>" aria-haspopup="true">
    				        <a href="./<?echo $menuItem[0]?>" class="kt-menu__link ">
    				            <i class="kt-menu__link-icon <?echo $icons_array[$menuItem[0]]?> text-primary"></i>
        				        <span class="kt-menu__link-text"><?echo ucfirst($menuItem[1])?></span>
        				        <i class="kt-menu__ver-arrow fa fa-angle-right text-primary" style="font-size: 15px;"></i>
    				        </a>
    				    </li>
    				<?}?>
    				
    			</ul>
    		</div>
    	</div>
    
    </div>
<?}?>
<?}?>