<? require("./global.php");


//if(!checkEmployeeAccessPermission('Leads')){header("Location: ./home.php?m=No permission");}
$primaryTableName = "users";

$getCustomersFromDB = getAll($con, "SELECT * FROM " . $g_projectSlug . "_users where role='employee'");
$customerArr = [];
foreach ($getCustomersFromDB as $k => $v) {
	$customerArr[$v['id']] = ucfirst($v['firstname']);
}

array(
    // field_name [type, isrequired, array_select, inner_type] <= "template"
    "first_name" => ["input", "", "", "text"],
    "last_name" => ["input", "", "", "text"],
    "email" => ["input", "", "", "text"],
    "phone" => ["input", "", "", "text"],
    "city" => ["input", "", "", "text"],
    "state" => ["input", "", "", "text"],
    "address" => ["input", "", "", "text"],
    "password" => ["input", "", "", "text"],
    "notes" => ["input", "", "", "text"],
     "assign_Employee" => ["select", "", $customerArr, "text"],
);;



if (isset($_POST['create_package'])) {
    $timeAdded = time();
    $actionId = mb_htmlentities(($_POST['actionId']));
    $first_name = mb_htmlentities($_POST['first_name']);
    $last_name = mb_htmlentities($_POST['last_name']);
    $email = mb_htmlentities($_POST['email']);
    $phone = mb_htmlentities($_POST['phone']);
    $city = mb_htmlentities($_POST['city']);
    $state = mb_htmlentities($_POST['state']);
    $address = mb_htmlentities($_POST['address']);
    $password = mb_htmlentities($_POST['password']);
    $notes = mb_htmlentities($_POST['notes']);
	$assign_employee = mb_htmlentities($_POST['assign_employee']);
	$assign_pipeline = mb_htmlentities($_POST['assign_pipeline']);
	
	
    if (isset($_POST['password'])) {
        $email = $_POST['email'];
        $password = $_POST['password'];
        $password=$_POST['password'] = mb_htmlentities(md5(md5(sha1($_POST['password'])) . 'Anomoz'));
    }
	
	
    if ($actionId == "") 
	{
		 $sql = "select email from ".$g_projectSlug."_users  where email='$email' and role='leads'";
         $results = getAll($con, $sql);
		 if($results)
		 {
			 header("Location: ?m=Duplicate emails not allowed");
			 exit();
		 }
        $id = generateRandomString();
        $actionId = $id;
        $query = "insert into ".$g_projectSlug."_users set id='$id' , first_name='$first_name', last_name='$last_name', email='$email', phone='$phone', city='$city', state='$state', address='$address', password='$password', notes='$notes', timeAdded='$timeAdded',assign_employee='$assign_employee',workflow='$assign_pipeline', role='leads', userId='$session_userId' ";
        // echo  "insert into alaHrSystem_users set id='$id' , first_name='$first_name', last_name='$last_name', email='$email', phone='$phone', city='$city', state='$state', address='$address', password='$password', notes='$notes', timeAdded='$timeAdded', role='leads', userId='$session_userId' ";
        // exit;
	}
	
	else {
        $query = "update ".$g_projectSlug."_users set id='$actionId' , first_name='$first_name', last_name='$last_name', email='$email', phone='$phone', city='$city', state='$state', address='$address', password='$password', notes='$notes',assign_employee='$assign_employee',workflow='$assign_pipeline' where id='$actionId'";
    }
    $stmt = $con->prepare($query);
    if (!$stmt) {
        echo "err: <code>$query</code>";
    }
    if (!$stmt->execute()) {
        echo "err: <code>$query</code>";
    }
    $rStr = "";
    if (isset($_GET['id'])) {
        $rStr .=  "&id=" . $_GET['id'];
		
    }
        header("Location: ?m=Data was saved successfully!" . $rStr);
	
	
	   
}

if (isset($_GET['delete-record'])) {
    $id = mb_htmlentities($_GET['delete-record']);
    if ($id != "admin") {
        $stmt = $con->prepare("update ".$g_projectSlug."_users set is_archived='Yes' where id=?");
        $stmt->bind_param("s", $id);
        if (!$stmt->execute()) {
            echo "err";
        }
    }
}


?>
<!DOCTYPE html>


<html lang="en">

<!-- begin::Head -->

<head><? require("./includes/views/head.php") ?>
</head>

<!-- end::Head -->

<!-- begin::Body -->

<body class="<? echo $g_body_class ?>">

    <? require("./includes/views/header.php") ?>

    <div class="kt-grid kt-grid--hor kt-grid--root">
        <div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--ver kt-page">
            <div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-wrapper" id="kt_wrapper">

                <!-- begin:: Header -->

                <? require("./includes/views/topmenu.php") ?>
                <!-- end:: Header -->

                <!-- begin:: Aside -->
                <? require("./includes/views/leftmenu.php") ?>

                <!-- end:: Aside -->
                <div class="kt-body kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-grid--stretch" id="kt_body">
                    <div class="kt-content  kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor" id="kt_content">

                        <!-- end:: Subheader -->

                        <!-- begin:: Content -->
                        <div class="kt-container  kt-grid__item kt-grid__item--fluid">

                            <? if (isset($_GET['m'])) { ?>
                                <div class="alert alert-info"><? echo $_GET['m'] ?></div>
                            <? } ?>

                            <div class="kt-portlet kt-portlet--mobile">
                                <div class="kt-portlet__head kt-portlet__head--lg">
                                    <div class="kt-portlet__head-label">
                                        <span class="kt-portlet__head-icon">
                                        </span>
                                        <h3 class="kt-portlet__head-title">
                                            <? ;
                                            if(isset($_GET['archived'])){
                                                echo "Archived - ";
                                                
                                            }
                                            echo ucfirst(str_replace("_", " ", "leads")); ?>
                                        </h3>
                                    </div>
                                    <div class="kt-portlet__head-toolbar">
                                        <div class="kt-portlet__head-wrapper">
                                            <div class="kt-portlet__head-actions">

                                                <? renderImportExportButtons($primaryTableName); 
														if($session_role=="admin"){?>
                                                <a href="#" class="btn btn-brand btn-elevate btn-icon-sm" data-toggle="modal" data-target="#create_record_modal">
                                                    <i class="la la-plus"></i>
                                                    New Record
                                                </a>
												
													<a href="?archived=1" class="btn btn-warning btn-elevate btn-icon-sm">View Archived</a>
														<?}?>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="kt-portlet__body">
                                    <form action="" method="post">
                                        <? if (checkGlobalPermission('g_enableBulkDelete')) { ?>
                                            <button type="button" class="btn btn-info btn-sm text-white " onclick="selectAll();">Select All</button>
                                            <button type="submit" class="btn btn-danger btn-sm text-white ">Delete Bulk</button>
                                        <? } ?>


                                        <table class="table table-striped- table-bordered table-hover table-checkable add-search">
                                            <thead>
                                                <tr>
                                                    <th>First name</th>
                                                    <th>Last name</th>
                                                    <th>Email</th>
                                                    <th>Phone</th>
                                                    <th>City</th>
                                                    <th>State</th>
                                                    <th>Address</th>
                                                    <th>Notes</th>
													 <th>Assign Employee</th>
													 <th>Workflow</th>

                                                      <th>Actions</th>
													  
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?  
                                                $archived = "No";
                                                if(isset($_GET['archived'])){
                                                    $archived = "Yes";
                                                }
                                                $query = "select t.first_name,t.last_name,t.email,t.id,t.phone,t.city,t.state,t.address,t.notes,t.assign_employee,p.pipeline_name as workflow, t.workflow as workflowId,
                                                p.color from ".$g_projectSlug."_users t  left outer join " . $g_projectSlug . "_pipelines p on p.id=t.workflow 
                                                where t.assign_employee like '%$session_userId_filter%' AND t.role='leads' and t.is_archived='$archived' order by t.timeAdded desc";

                                                $results = getAll($con, $query);
                                                foreach ($results as $row) { ?>
                                                    <tr>
                                                        <td><? echo $row['first_name'] ?></td>
                                                        <td><? echo $row['last_name'] ?></td>
                                                        <td><? echo $row['email'] ?></td>
                                                        <td><? echo $row['phone'] ?></td>
                                                        <td><? echo $row['city'] ?></td>
                                                        <td><? echo $row['state'] ?></td>
                                                        <td><? echo $row['address'] ?></td>
                                                        <td><? echo $row['notes'] ?></td>
														<td><? echo $g_allUsersInfo[$row['assign_employee']]['name'] ?></td>
														<td >
														    <?if($row['workflow']!=""){?>
														    <div class="badge badge-primary" style="background:<? echo $row['color'] ?>;">
														         <?echo $row['workflow'] ?>
														  </div>
														  <?}?>
														 
														 </td>
						
                                                        <td>
														<?
														if(true){?>
                                                            <div class="btn-group">
                                                                <a href="#" class="btn btn-warning" data-toggle="modal" data-target="#create_record_modal" data-mydata='<? echo  htmlspecialchars(json_encode($row, JSON_UNESCAPED_SINGLEQUOTES | JSON_UNESCAPED_UNICODE)); ?>'>Edit</a>
                                                                <a href="#" class="btn btn-danger" data-toggle="modal" data-target="#delete_record" data-url="?<? if (isset($_GET['id'])) {
                                                                                                                                                                    echo "id=" . $_GET['id'] . "&";
                                                                                                                                                                } ?>delete-record=<? echo $row['id'] ?>">Archive</a>
                                                            </div>
														<?}?>
                                                        </td>
                                                    </tr>
                                                <? } ?>
                                            </tbody>
                                        </table>


                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <? require("./includes/views/footer.php") ?>
            </div>
        </div>
    </div>
    <? require("./includes/views/footerjs.php") ?>
</body>

<!-- end::Body -->

<div class="modal fade" id="create_record_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modelTitle">Insert</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                </button>
            </div>
            <div class="modal-body">

                <form class="kt-form" action="" method="Post" enctype="multipart/form-data">
                    <div class="kt-portlet__body">

                        <!-- modal -->

                      

                        <div>
                            <div class="form-group">
                                <label>First name</label>
                                <input type="text" name="first_name" class="form-control">
                            </div>

                            <div class="form-group">
                                <label>Last name</label>
                                <input type="text" name="last_name" class="form-control">
                            </div>

                            <div class="form-group">
                                <label>Email</label>
                                <input type="text" name="email" class="form-control">
                            </div>

                            <div class="form-group">
                                <label>Phone</label>
                                <input type="text" name="phone" class="form-control">
                            </div>

                            <div class="form-group">
                                <label>City</label>
                                <input type="text" name="city" class="form-control">
                            </div>

                            <div class="form-group">
                                <label>State</label>
                                <input type="text" name="state" class="form-control">
                            </div>

                            <div class="form-group">
                                <label>Address</label>
                                <input type="text" name="address" class="form-control">
                            </div>
                            <div class="form-group">
                                <label>Notes</label>
                                <input type="text" name="notes" class="form-control">
                            </div>
							<div class="form-group">
							
							 <label>Assign Employee</label>
														<select class="form-control" name="assign_employee" >
															<option value="">Select Employee</option>
															<?php
															$getcustomer = getAll($con, "SELECT * FROM " . $g_projectSlug . "_users where role = 'employee' or role='admin'");
															foreach ($getcustomer as $c) { ?>
																<option <?{
																			
																		} ?> value="<?php echo $c['id'] ?>"><?php echo  $c['name'] ?></option>
															<?php
															}
															?>
														</select>
							
							
						</select>
					</div>
					
					<div class="form-group">
							
							 <label>Select Pipeline</label>
							<select class="form-control" name="assign_pipeline" >
								<option value="">Select Pipeline</option>
								<?php
								$temp = getAll($con, "select * from " . $g_projectSlug . "_" . "pipelines" . " order by timeAdded desc");
									foreach ($temp as $row) {  ?>
									<option <?{
												
											} ?> value="<?php echo $row['id'] ?>"><?php echo  $row['pipeline_name'] ?></option>
								<?php
								}
								?>
							</select>

							
						</select>
					</div>
                            <input type="text" name="actionId" value="" hidden>
                        </div>

                    </div>
                    <div class="kt-portlet__foot">
                        <div class="kt-form__actions">
                            <input type="submit" name="create_package" value="Submit" class="btn btn-primary">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<script>
    function checkCheckboxes(inputname, valuesToCheck) {
        valuesToCheck.forEach(value => {
            const $checkbox = $(`input[name='${inputname}'][value='${value}']`);
            if ($checkbox.length > 0) {
                $checkbox.prop('checked', true);
            }
        });
    }

    $(document).ready(function() {


        $("#create_record_modal").on('show.bs.modal', function(e) {
            var mydata = $(e.relatedTarget).data('mydata');
            console.log("mydata->", mydata);
            $("input[type='checkbox']").prop('checked', false);
            if (mydata != null) {
                $("#modelTitle").html("Update");
                $("input[name='first_name']").val(mydata['first_name'])
                $("input[name='last_name']").val(mydata['last_name'])
                $("input[name='email']").val(mydata['email'])
                $("input[name='phone']").val(mydata['phone'])
                $("input[name='city']").val(mydata['city'])
                $("input[name='state']").val(mydata['state'])
                $("input[name='address']").val(mydata['address'])
                $("input[name='notes']").val(mydata['notes'])
                $("input[name='actionId']").val(mydata['id'])
				$("select[name='assign_employee']").val(mydata['assign_employee'])
				$("select[name='assign_pipeline']").val(mydata['workflowId'])
            } else {
                $("#modelTitle").html("Insert");
                $("input[name='first_name']").val("")
                $("input[name='last_name']").val("")
                $("input[name='email']").val("")
                $("input[name='phone']").val("")
                $("input[name='city']").val("")
                $("input[name='state']").val("")
                $("input[name='address']").val("")
                $("input[name='notes']").val("")
				$("select[name='assign_employee']").val("")
				$("select[name='assign_pipeline']").val("");

                $("input[name='actionId']").val("")
            }
        });
    })
</script>



</html>