<? require("./global.php");

function highlightWordInSentence($sentence, $word) {
    // Use case-insensitive search
    $position = stripos($sentence, $word);

    if ($position !== false) {
        // Word found, wrap it in a badge
        $highlightedSentence = substr($sentence, 0, $position) ."<span class='badge badge-primary' style='display: inline;padding: 1px;'>" . substr($sentence, $position, strlen($word)) . "</span>" .substr($sentence, $position + strlen($word));
        return $highlightedSentence;
    } else {
        // Word not found, return the original sentence
        return $sentence;
    }
}

// Example usage:
// $sentence = "my name is ahsan";
// $word = "ahsan";
// $result = highlightWordInSentence($sentence, $word);

// echo $result;

?>
<!DOCTYPE html>
<html lang="en">

<!-- begin::Head -->

<head>
	<? require("./includes/views/head.php") ?>
</head>

<!-- end::Head -->

<!-- begin::Body -->

<body class="<? echo $g_body_class ?>">

	<? require("./includes/views/header.php") ?>

	<div class="kt-grid kt-grid--hor kt-grid--root">
		<div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--ver kt-page">
			<div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-wrapper" id="kt_wrapper">

				<!-- begin:: Header -->

				<? require("./includes/views/topmenu.php") ?>
				<!-- end:: Header -->

				<!-- begin:: Aside -->
				<? require("./includes/views/leftmenu.php") ?>

				<!-- end:: Aside -->
				<div class="kt-body kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-grid--stretch"
					id="kt_body">
					<div class="kt-content  kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor" id="kt_content">

						<!-- end:: Subheader -->

						<!-- begin:: Content -->
						<div class="kt-container  kt-grid__item kt-grid__item--fluid">

							<? if (isset($_GET['m'])) { ?>
								<div class="alert alert-info">
									<? echo $_GET['m'] ?>
								</div>
							<? } ?>
                            
                            <form action="" method="get">
                                <div class="input-group mb-3 mx-auto" style="max-width:500px;">
                                    <input class="form-control" required name="search" placeholder="Search anything..." value="<?echo $_GET['search']?>">
                                    <button class="btn btn-primary">Search</button>
                                </div>
                            </form>
                            
							<div class="kt-portlet kt-portlet--mobile">
								<div class="kt-portlet__head kt-portlet__head--lg">
									<div class="kt-portlet__head-label">
										<span class="kt-portlet__head-icon">
										</span>
										<h3 class="kt-portlet__head-title">
											<?if($_GET['search']!=''){echo "Searching for '".$_GET['search']."'";}else{echo "Search";}?>
										</h3>
									</div>
									<div class="kt-portlet__head-toolbar">
										<div class="kt-portlet__head-wrapper">
											<div class="kt-portlet__head-actions">


											</div>
										</div>
									</div>
								</div>
								<div class="kt-portlet__body" style="display: inline;">
									    <?
									    $search = $_GET['search'];

                                        // Get all table names starting with "slug_"
                                        $query = "SHOW TABLES LIKE '".$g_projectSlug."_%'";
                                        $result = $con->query($query);
                                        
                                        // Check if any tables are found
                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_row()) {
                                                $tableName = $row[0];
                                                $showTableName = false;
                                                $tableNameDisplayed = false;
                                        
                                                // Get all columns in the current table
                                                $columnsQuery = "SHOW COLUMNS FROM $tableName";
                                                $columnsResult = $con->query($columnsQuery);
                                                $columnsResult_getall = getAll($con, $columnsQuery);
                                        
                                                // Check if the current table has any columns
                                                if ($columnsResult->num_rows > 0) {
                                                    // Search the input in each column
                                                    $input = $con->real_escape_string($search);
                                        
                                                    while ($column = $columnsResult->fetch_assoc()) {
                                                        $columnName = $column['Field'];
                                        
                                                        // Search for the input in the current column
                                                        $searchQuery = "SELECT * FROM $tableName WHERE $columnName LIKE '%$input%'";
                                                        $searchResult = $con->query($searchQuery);
                                        
                                                        // Check if the input is found in the current column
                                                        if ($searchResult->num_rows > 0) {
                                                            $showTableName = true;
                                        
                                                            if ($showTableName && !$tableNameDisplayed) {
                                                                echo "<table border='1'>";
                                                                echo "<div class='h4 w-100 bg-primary text-white p-1 mt-2'>Table: ".ucfirst(str_replace("$g_projectSlug".'_', "", $tableName))."</div>";
                                                                // echo "<tr><th>Column</th>";
                                        
                                                                // Display column names in the header row
                                                                // var_dump($columnsResult_getall);
                                                                foreach($columnsResult_getall as $col) {
                                                                    echo "<th>" . ucfirst($col['Field']) . "</th>";
                                                                }
                                        
                                                                echo "</tr>";
                                                                $tableNameDisplayed = true;
                                                            }
                                        
                                                            // Display the results in a table
                                                            while ($row = $searchResult->fetch_assoc()) {
                                                                // echo "<tr><td>$columnName</td>";
                                        
                                                                // Display entry values in separate columns
                                                                foreach ($row as $key => $value) {
                                                                    echo "<td>" . highlightWordInSentence($value, $search) . "</td>";
                                                                }
                                        
                                                                echo "</tr>";
                                                            }
                                                        }
                                                    }
                                        
                                                    if ($showTableName && !$tableNameDisplayed) {
                                                        echo "No matching entries found in the project.";
                                                    } elseif ($showTableName && $tableNameDisplayed) {
                                                        echo "</table>";
                                                    }
                                                }
                                            }
                                        } else {
                                            echo "No tables found in the project.";
                                        }

                                        
                                        ?>
								</div>
							</div>


						</div>


						<!-- end:: Content -->
					</div>
				</div>

				<!-- begin:: Footer -->

				<? require("./includes/views/footer.php") ?>

				<!-- end:: Footer -->
			</div>
		</div>
	</div>

	<? require("./includes/views/footerjs.php") ?>

</body>

</html>