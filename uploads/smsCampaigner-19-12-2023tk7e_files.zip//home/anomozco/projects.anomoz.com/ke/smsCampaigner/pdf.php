<!DOCTYPE html>
<html lang="en">

<head>

    <?php require("./includes/views/head.php") ?>

    <link href="assets/css/pages/invoices/invoice-1.css" rel="stylesheet" type="text/css" />
</head>

<body>


    <div class="kt-grid kt-grid--hor kt-grid--root">

        <div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--ver kt-page">

            <div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-wrapper" id="kt_wrapper">

                <!-- end:: Aside -->

                <div class="kt-body kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-grid--stretch" id="kt_body">

                    <div class="kt-content  kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor" id="kt_content">

                        <!-- end:: Subheader -->

                        <!-- begin:: Content -->
                        <div class="kt-container  kt-grid__item kt-grid__item--fluid">
                            <div class="kt-portlet">

                                <div class="kt-portlet__body kt-portlet__body--fit">

                                    <div class="kt-invoice-1">

                                        <div class="kt-invoice__head" style="background-image: url(assets/media/bg/bg-5.jpg);">

                                            <div class="kt-invoice__container">

                                                <div class="kt-invoice__brand">

                                                    <h1 class="kt-invoice__title">
                                                        <? if ($type == "invoice") {
                                                            echo "Rechnung";
                                                        } else {
                                                            echo "Invoice";
                                                        } ?>
                                                    </h1>
                                                </div>
                                            </div>

                                        </div>



                                        <? if ($type != "invoice") { ?>

                                            <div class="kt-invoice__footer">

                                                <div class="kt-invoice__container">

                                                    <div class="kt-invoice__bank">

                                                        <div class="kt-invoice__title">Customer Invoice</div>

                                                        <div class="kt-invoice__item">

                                                            <span class="kt-invoice__label">Client ID:</span>

                                                            <span class="kt-invoice__value"><?php echo $formVariables['name'] ?></span>

                                                        </div>

                                                        <div class="kt-invoice__item">

                                                            <span class="kt-invoice__label">Invoice ID:</span>

                                                            <span class="kt-invoice__value"><?php echo $formVariables['anschrift'] ?></span>

                                                        </div>

                                                        <div class="kt-invoice__item">

                                                            <span class="kt-invoice__label">Attachment:</span>

                                                            <span class="kt-invoice__value"><?php echo $formVariables['geburtsdatum'] ?></span>

                                                        </div>

                                                        <div class="kt-invoice__item">

                                                            <span class="kt-invoice__label">Custom Description:</span>
                                                            <span class="kt-invoice__value"><?php echo $formVariables['geburtsdatum'] ?></span>

                                                        </div>

                                                        <div class="kt-invoice__item">

                                                            <span class="kt-invoice__label">Total :</span>
                                                            <span class="kt-invoice__value"><?php echo $formVariables['geburtsdatum'] ?></span>

                                                        </div>
                                                        <hr>
                                                    </div>
                                                </div>
                                            </div>
                                        <? } ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php require("./includes/views/footerjs.php") ?>
</body>

<script>
    function submitForm() {

        $("#languagechange").submit();

    }
</script>

</html>