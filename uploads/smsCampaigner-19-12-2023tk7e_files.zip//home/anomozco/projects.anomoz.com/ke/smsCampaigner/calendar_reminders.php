<? require("./global.php");

// if(!checkGlobalPermission('enableCalendarReminder')){header("Location: ./home.php?m=Oops! Error occured");}

$arrayFields_personal = array("firstname", "dob", "telephone", "email", "address");

if (isset($_POST['create_package'])) {
    $title = mb_htmlentities(($_POST['title']));
    $color = mb_htmlentities(($_POST['color'])); if($color==""){$color = '#ffffff';}
    $date = mb_htmlentities(($_POST['date']));

    // $date = implode('-', array_reverse(explode('-', $date)));

    $apptTime = mb_htmlentities(($_POST['apptTime']));
    $endTime = mb_htmlentities(($_POST['endTime']));
    $description = mb_htmlentities(($_POST['description']));
    $timeAdded = time();
    $actionId = mb_htmlentities(($_POST['actionId']));
    $user_id = mb_htmlentities(($_POST['user_id']));

    $timeAdded = time();
    $id = generateRandomString();
    if ($actionId == "") {
        $actionId = $id;
        $stmt = $con->prepare("insert into " . $g_projectSlug . "_calendar_reminders set color=?, title=?, description=?,customer_id=?, apptDate=?, apptTime=?,endTime=?, timeAdded=?, id=?, userId=?");
        $stmt->bind_param("ssssssssss", $color, $title, $description, $user_id, $date, $apptTime,$endTime, $timeAdded, $id, $session_userId);
        if (!$stmt->execute()) {
            echo "err";
        }
    } else {
        //update
        $stmt = $con->prepare("update " . $g_projectSlug . "_calendar_reminders set color=?, title=?, description=?,customer_id=?, apptDate=?, apptTime=?,endTime=?, timeAdded=?, userId=? where id=?");
        $stmt->bind_param("ssssssssss", $color, $title, $description, $user_id, $date, $apptTime,$endTime, $timeAdded, $session_userId, $actionId);
        if (!$stmt->execute()) {
            echo "err";
        }
    }

    header("Location: ?m=Calendar updated successfully.");
}

if ($_POST['action'] == 'resize_event') {
    $eventId = $_POST['id'];
    $newStart = $_POST['start'];
    $newEndTime = $_POST['end'];
    
    if($newEndTime!=''){
        $newEndTime_time = substr($newEndTime, 11,5);
        $newStart_time = substr($newStart, 11,5);
        
        // Update the database record with the new end time
        $sql = "UPDATE smsCampaigner_calendar_reminders SET apptTime='$newStart_time',endTime = '$newEndTime_time' WHERE id = '$eventId'";
        echo $sql;
        $stmt = $con->prepare($sql);

        if ($stmt->execute()) {
            echo "Event resized successfully.";
        } else {
            echo "Error: " . $con->error;
        }
        
        $stmt->close();
        exit();
    }
}

// Handle event dropping
if ($_POST['action'] == 'drop_event') {
    $eventId = $_POST['id'];
    $newStart = $_POST['start'];
    $newEndTime = $_POST['end'];
    
    if($newStart!=''){
        $newEndTime_time = substr($newEndTime, 11,5);
        $newStart_date = substr($newStart, 0, 10);
        $newStart_time = substr($newStart, 11,5);
        // Update the database record with the new start time
        $sql = "UPDATE smsCampaigner_calendar_reminders SET apptDate = '$newStart_date',apptTime='$newStart_time',endTime = '$newEndTime_time' WHERE id = '$eventId'";
        echo $sql;
        $stmt = $con->prepare($sql);

        if ($stmt->execute()) {
            echo "Event dropped successfully.";
        } else {
            echo "Error: " . $con->error;
        }
        $stmt->close();
    }
    
    
    exit();
}


if (isset($_GET['delete-record'])) {
    $id = mb_htmlentities($_GET['delete-record']);
    $stmt = $con->prepare("delete from " . $g_projectSlug . "_calendar_reminders where id=?");
    $stmt->bind_param("s", $id);
    if (!$stmt->execute()) {
        echo "err";
    }
}

if (isset($_POST['delete_package'])) {
    $id = escape($_POST['actionId']);
    $stmt = $con->prepare("delete from " . $g_projectSlug . "_calendar_reminders where id=?");
    $stmt->bind_param("s", $id);
    if (!$stmt->execute()) {
        echo "err";
    }
}

?>
<!DOCTYPE html>


<html lang="en">

<!-- begin::Head -->

<head>
    <? require("./includes/views/head.php") ?>
    <style>
    .color-picker {
        display: flex;
     
      position: relative;
    }
    
    .color {
        width: 20px;
        height: 20px;
        border-radius: 50%;
        cursor: pointer;
        margin: 5px;
    }
    

    .selected {
        border: 3px solid black; /* You can customize the border style */
    }
    
 
        <?php
        // Define an array of color names and their lighter shades
        $colors = [
            'red' => ['#FF8F8F'],
            'green' => ['#8FFF8F'],
            'blue' => ['#8F8FFF',],
            'yellow' => ['#FFFF8F'],
            'orange' => ['#FFC28F'],
        ];

        // Generate CSS rules for each color and its lighter shades
        foreach ($colors as $color => $shades) {
            echo ".color.$color { background-color: $shades[0]; }";
            foreach ($shades as $i => $shade) {
                echo ".color.$color-$i { background-color: $shade; }";
            }
        }
        ?>
    

    </style>
</head>

<!-- end::Head -->

<!-- begin::Body -->

<body class="<? echo $g_body_class ?>">

    <? require("./includes/views/header.php") ?>

    <div class="kt-grid kt-grid--hor kt-grid--root">
        <div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--ver kt-page">
            <div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-wrapper" id="kt_wrapper">

                <!-- begin:: Header -->

                <? require("./includes/views/topmenu.php") ?>
                <!-- end:: Header -->

                <!-- begin:: Aside -->
                <? require("./includes/views/leftmenu.php") ?>

                <!-- end:: Aside -->
                <div class="kt-body kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-grid--stretch" id="kt_body">
                    <div class="kt-content  kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor" id="kt_content">

                        <!-- end:: Subheader -->

                        <!-- begin:: Content -->
                        <div class="kt-container  kt-grid__item kt-grid__item--fluid">



                            <link href="./assets/plugins/custom/fullcalendar/fullcalendar.bundle.css" rel="stylesheet" type="text/css" />
                            <div class="kt-portlet" id="kt_portlet">
                                <div class="kt-portlet__head">
                                    <div class="kt-portlet__head-label">
                                        
                                        <h3 class="kt-portlet__head-title">
                                            Reminders
                                        </h3>
                                    </div>
                                    <div class="kt-portlet__head-toolbar">
                                        <a href="#" class="btn btn-brand btn-elevate btn-icon-sm" data-toggle="modal" data-target="#create_record_modal">
                                            <i class="fa fa-plus"></i>
                                            Add Reminder
                                        </a>
                                    </div>
                                </div>
                                <div class="kt-portlet__body">
                                    <div id="kt_calendar"></div>
                                </div>
                            </div>
                            <? if (checkGlobalPermission('enableCalendarEdit') || true) { ?>
                                <div class="kt-portlet kt-portlet--mobile">
                                    <div class="kt-portlet__head kt-portlet__head--lg">
                                        <div class="kt-portlet__head-label">
                                            <span class="kt-portlet__head-icon">
                                            </span>
                                            <h3 class="kt-portlet__head-title">
                                                <? echo ucfirst("Reminders"); ?>
                                            </h3>
                                        </div>
                                        <div class="kt-portlet__head-toolbar">
                                            <div class="kt-portlet__head-wrapper">
                                                <div class="kt-portlet__head-actions">


                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="kt-portlet__body">
                                        <form action="" method="post">
                                            <? if (checkGlobalPermission('g_enableBulkDelete')) { ?>
                                                <button type="button" class="btn btn-info btn-sm text-white " onclick="selectAll();">Select All</button>
                                                <button type="submit" class="btn btn-danger btn-sm text-white ">Delete Bulk</button>
                                            <? } ?>
                                            <!--begin: Datatable -->
                                            <table class="table table-striped- table-bordered table-hover table-checkable add-search" id="kt_table_1">
                                                <thead>
                                                    <tr>
                                                        <? $query = "select * from " . $g_projectSlug . "_calendar_reminders where userId like '%$session_userId_filter%'";
                                                        $header = getRow($con, $query . " limit 1");
                                                        if (checkGlobalPermission('g_enableBulkDelete')) { ?><th>Select</th><? } ?>

                                                        <th>Title</th>
                                                        <th>Description</th>
                                                        <th>Date </th>
                                                        <th>Time</th>
                                                        <th>End Time</th>
                                                        <? if (checkGlobalPermission('enableCalendarAssignToOthers')) { ?>
                                                            <th>Assigned to</th>
                                                        <? } ?>

                                                        <th>Actions</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <? $results = getAll($con, $query);
                                                    foreach ($results as $row) { ?>
                                                        <tr>
                                                            <? if (checkGlobalPermission('g_enableBulkDelete')) { ?>
                                                                <th>
                                                                    <div class="form-check">
                                                                        <label class="form-check-label">
                                                                            <input class="form-check-input" type="checkbox" name="delete_bulk[]" value="<? echo $row['id'] ?>">
                                                                            <span class="form-check-sign">
                                                                                <span class="check"></span>
                                                                            </span>
                                                                        </label>
                                                                    </div>
                                                                </th>
                                                            <? } ?>



                                                            <td><? echo $row['title'] ?></td>
                                                            <td><? echo $row['description'] ?></td>
                                                            <td><? echo  $row["apptDate"]; ?></td>
                                                            <td><? echo $row['apptTime'] ?></td>
                                                            <td><? echo $row['endTime'] ?></td>
                                                            <? if (checkGlobalPermission('enableCalendarAssignToOthers')) { ?>
                                                                <td><? echo $g_allUsersInfo[$row['customer_id']]['name'] ?></td>
                                                            <? } ?>

                                                            <td>
                                                                <div class="btn-group">
                                                                    <?php
                                                                    // To add event to google calendar                                                      
                                                                    $eventTitle = urlencode($row['title']);
                                                                    $eventDescription = urlencode($row['description']);
                                                                    $startDate = date('Ymd', strtotime($row["apptDate"]));
                                                                    $startTime = str_replace(':', '', $row['apptTime']);
                                                                    $endTime = str_replace(':', '', $row['endTime']);
        
                                                                    $googleCalendarUrl = "https://www.google.com/calendar/render?action=TEMPLATE&text={$eventTitle}&dates={$startDate}T{$startTime}00/{$startDate}T{$endTime}00&details={$eventDescription}";
                                                                    ?>
                                                            
                                                                    <? if ($session_role == "admin") { ?>
                                                                        <? if (checkGlobalPermission('enableAddToGoogleCalendar')) { ?>
                                                                            <a href="<?php echo $googleCalendarUrl; ?>" class="btn btn-primary" target='_blank'>Add to Google Calendar</a>
                                                                        <? } ?>
                                                                        <? if (checkGlobalPermission('enableEdit')) { ?>
                                                                            <a href="#" class="btn btn-warning" data-toggle="modal" data-target="#create_record_modal" data-mydata='<? echo (json_encode($row, true)); ?>'>Edit</a>
                                                                        <? } ?>
                                                                        <? if (checkGlobalPermission('enableDelete')) {?>
                                                                            <a href="#" class="btn btn-danger" data-toggle="modal" data-target="#delete_record" data-url="?delete-record=<? echo $row['id'] ?>">Delete</a>
                                                                        <? } ?>
                                                                        
                                                                        
                                                                    <? } ?>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    <? } ?>

                                                </tbody>
                                            </table>
                                        </form>
                                        <!--end: Datatable -->
                                    </div>
                                </div>
                            <? } ?>


                        </div>




                        <!-- end:: Content -->
                    </div>
                </div>

                <!-- begin:: Footer -->

                <? require("./includes/views/footer.php") ?>

                <!-- end:: Footer -->
            </div>
        </div>
    </div>


    <? require("./includes/views/footerjs.php") ?>


</body>

<!-- end::Body -->

<div class="modal fade" id="create_record_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modelTitle">Insert Reminder</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                </button>
            </div>
            <div class="modal-body">

                <form class="kt-form" action="" method="Post" enctype="multipart/form-data">
                    <div class="kt-portlet__body">
                        <? if (checkGlobalPermission('enableCalendarAssignToOthers')) { ?>
                            <div class="form-group">
                                <label>Assign to</label>
                                <select name="user_id" class="form-control" required>
                                    <?
                                    $users = getAll($con, "select * from " . $g_projectSlug . "_users where role='customer' or role='admin'");
                                    foreach ($users as $row) { ?>
                                        <option value="<? echo $row['id'] ?>"><? echo $row['name'] ?></option>
                                    <? } ?>
                                </select>
                            </div>
                        <? } ?>

                        <div class="form-group">
                            <label>Title</label>
                            <input type="text" name="title" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label>Description</label>
                            <input type="text" name="description" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label>Date</label>
                            <input type="date" name="date" class="form-control date-mask" required>
                        </div>
                        <div class="form-group">
                            <label>Start Time</label>
                            <input type="time" name="apptTime" class="form-control date-masktime" required>
                        </div>
                        <div class="form-group">
                            <label>End Time</label>
                            <input type="time" name="endTime" class="form-control date-masktime" required>
                        </div>
                        <div class="form-group">
                            <label>Color</label>
                            
                            <div class="color-picker">
                                <?php
                                // Create color divs with their lighter shades
                                foreach ($colors as $color => $shades) {
                                    foreach ($shades as $i => $shade) {
                                        echo "<div class='color $color-$i' data-color='$shade'></div>";
                                    }
                                }
                                ?>
                            </div>
                            
                        </div>






                        <input type="text" name="actionId" value="" hidden>
                        <input type="hidden" id="selected-color" name="color">
                        
                            

                    </div>
                    <div class="kt-portlet__foot">
                        <div class="kt-form__actions">
                            <div>
                                <input type="submit" name="create_package" value="Submit" class="btn btn-primary">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                <input type="submit" name="delete_package" value="Delete" class="btn btn-danger">
                            </div>
                            
                            
                            
                        </div>
                    </div>
                </form>
            </div>

        </div>
    </div>
</div>


<script>
    $(document).ready(function() {


        $("#create_record_modal").on('show.bs.modal', function(e) {
            //get data-id attribute of the clicked element
            var mydata = $(e.relatedTarget).data('mydata');
            console.log(mydata);
            //console.log("mydata", mydata)
            if (mydata != null) {
                $("#modelTitle").html("Update");
                <? foreach ($arrayFields_personal as $col) { ?>
                    $("input[name='<? echo $col ?>']").val(mydata['<? echo $col ?>'])
                <? } ?>

                $("input[name='actionId']").val(mydata['id'])


            } else {
                $("#modelTitle").html("Insert");
                $("input[name='actionId']").val("")
                <? foreach ($arrayFields_personal as $col) { ?>
                    $("input[name='<? echo $col ?>']").val("")
                <? } ?>

                $("select").val("")
                $("input[name='actionId']").val("")

            }


        });
    })
</script>


<!--begin::Page Vendors(used by this page) -->
<script src="./assets/plugins/custom/fullcalendar/fullcalendar.bundle.js" type="text/javascript"></script>

<!--end::Page Vendors -->

<!--<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/5.10.0/main.min.css">-->
<!--<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>-->
<!--<script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/5.10.0/main.min.js"></script>-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/5.10.0/interaction.min.js"></script>

<script>
    function formatTimeToISOString(dateTimeString) {
        
        var date = new Date(dateTimeString);
        date.setMinutes(date.getMinutes() - date.getTimezoneOffset()); // Adjust for the local timezone
        
        var formattedDateTime = date.toISOString();
        
        console.log("dateTimeString", dateTimeString, formattedDateTime);
        
        return formattedDateTime;


    }

    function formatTwoDigits(number) {
        return number.toString().padStart(2, '0');
    }
    function populateColor(colorName) {
        // Remove "selected" class from all colors
        $('.color').removeClass('selected');
        // Find the color element with the data-color attribute matching the colorName
        var color = $('.color[data-color="' + colorName + '"]');
        // Add "selected" class to the chosen color
        color.addClass('selected');
        // Set the hidden input value to the color name
        $('#selected-color').val(colorName);
    }
    
    
    "use strict";

    var KTCalendarBasic = function() {

        return {
            //main function to initiate the module
            init: function() {
                var todayDate = moment().startOf('day');
                var YM = todayDate.format('YYYY-MM');
                var YESTERDAY = todayDate.clone().subtract(1, 'day').format('YYYY-MM-DD');
                var TODAY = todayDate.format('YYYY-MM-DD');
                var TOMORROW = todayDate.clone().add(1, 'day').format('YYYY-MM-DD');

                var calendarEl = document.getElementById('kt_calendar');
                var calendar = new FullCalendar.Calendar(calendarEl, {
                    timezone: 'local',
                    plugins: ['interaction', 'dayGrid', 'timeGrid', 'list'],

                    isRTL: KTUtil.isRTL(),
                    header: {
                        left: 'prev,next today',
                        center: 'title',
                        right: 'dayGridMonth,timeGridWeek,timeGridDay'
                    },

                    height: 800,
                    contentHeight: 780,
                    aspectRatio: 3, // see: https://fullcalendar.io/docs/aspectRatio

                    // nowIndicator: true,
                    // now: TODAY + 'T09:25:00', // just for demo
                    selectable: true,
                    slotMinTime: '08:00', /* calendar start Timing */
                    slotMaxTime: '23:59',  /* calendar end Timing */
                    views: {
                        dayGridMonth: {
                            buttonText: 'month'
                        },
                        timeGridWeek: {
                            buttonText: 'week'
                        },
                        timeGridDay: {
                            buttonText: 'day'
                        }
                    },

                    defaultView: 'dayGridMonth',
                    defaultDate: TODAY,

                    editable: true,
                    eventLimit: true, // allow "more" link when too many events
                    navLinks: true,
                    events: [

                        <? $query = "select * from " . $g_projectSlug . "_calendar_reminders where userId='$session_userId'";
                        $result = $con->query($query);
                        while ($row = $result->fetch_assoc()) { ?> {
                                id: '<? echo $row['id'] ?>',
                                title: '<? echo $row['title'] ?>',
                                start: '<?php echo $row['apptDate'] ?>T<?php echo date("H:i", strtotime($row['apptTime'])) ?>',
                                end: '<?php echo $row['apptDate'] ?>T<?php echo date("H:i", strtotime($row['endTime'])) ?>',
                                
                                description: '<? echo $row['description'] ?> (Time: <? echo $row['apptTime'] ?>)',
                                className: "fc-event-solid-light",
                                backgroundColor: '<? echo $row['color'] ?>'
                            },
                        <? } ?>
                    ],
                    select: function(jsEvent, view) {
                        console.log("jsEvent", jsEvent)
                        var starttimestamp = jsEvent['start'];
                        var endtimestamp = jsEvent['end'];
                
                        var dt = new Date(starttimestamp);
                        var start_time = formatTwoDigits(dt.getHours()) + ":" + formatTwoDigits(dt.getMinutes());
                        
                        var dt = new Date(endtimestamp);
                        var end_time = formatTwoDigits(dt.getHours()) + ":" + formatTwoDigits(dt.getMinutes());
                
                        var month = dt.getMonth() + 1;
                        var day = dt.getDate();
                
                        var startDate = dt.getFullYear() + '-' +
                            (month < 10 ? '0' : '') + month + '-' +
                            (day < 10 ? '0' : '') + day;
                
                        console.log("start_time", start_time)
                        $("input[name=apptTime]").val(start_time)
                        
                        console.log("end_time", end_time)
                        $("input[name=endTime]").val(end_time)
                
                        console.log("startDate", startDate)
                        $("input[name=date]").val(startDate)
                        
                        $("#create_record_modal").modal("show");
                    },
                    eventClick: function(info) {
                        var event_id_from_calendar = info.event.id;
                        var allarray = <?php echo json_encode($results, true) ?>;
                        console.log("allarray", allarray, event_id_from_calendar)
                        for (var i = 0; i <= allarray.length; i++) {
                            if (allarray[i]['id'] == event_id_from_calendar) {
                                var myarray = allarray[i];
                                console.log(myarray);
                                break;
                            }
                        }
                        $('#create_record_modal').modal('show');
                        
                        $("select[name='user_id']").val(myarray['customer_id'])
                        $("input[name='title']").val(myarray['title']);
                        $("input[name='description']").val(myarray['description']);
                        $("input[name='date']").val(myarray['apptDate']);
                        $("input[name='apptTime']").val(myarray['apptTime']);
                        $("input[name='endTime']").val(myarray['endTime']);
                     
                        $("input[name='actionId']").val(myarray['id']);
                        $("input[name='ac']").val(myarray['std_id']);
                        populateColor(myarray['color'])
                       
                    },

                    eventRender: function(info) {
                        var element = $(info.el);

                        if (info.event.extendedProps && info.event.extendedProps.description) {
                            if (element.hasClass('fc-day-grid-event')) {
                                element.data('content', info.event.extendedProps.description);
                                element.data('placement', 'top');
                                KTApp.initPopover(element);
                            } else if (element.hasClass('fc-time-grid-event')) {
                                element.find('.fc-title').append('<div class="fc-description">' + info.event.extendedProps.description + '</div>');
                            } else if (element.find('.fc-list-item-title').lenght !== 0) {
                                element.find('.fc-list-item-title').append('<div class="fc-description">' + info.event.extendedProps.description + '</div>');
                            }
                        }
                    },
                    eventResize: function(info) {
                        // Handle event resizing here
                        console.log('Event resized: ' + info.event.title);
                    
                        $.ajax({
                            url: '',
                            type: 'POST',
                            data: {
                                action: 'resize_event',
                                id: info.event.id,
                                end: formatTimeToISOString(info.event.end.toLocaleString()),
                                start: formatTimeToISOString(info.event.start.toLocaleString())
                            },
                            success: function(response) {
                                console.log(response);
                                toastr.success('Calendar updated successfully.', 'Success');
                            }
                        });
                    },
                    eventDrop: function(info) {
                        // Handle event drop (moving) here
                        console.log('Event dropped', info.event);
                    
                        $.ajax({
                            url: '',
                            type: 'POST',
                            data: {
                                action: 'drop_event',
                                id: info.event.id,
                                end: formatTimeToISOString(info.event.end.toLocaleString()),
                                start: formatTimeToISOString(info.event.start.toLocaleString())
                            },
                            success: function(response) {
                                console.log(response);
                                toastr.success('Calendar updated successfully.', 'Success');
                            }
                        });
                    }

                    
                });

                calendar.render();
            }
        };
    }();

    jQuery(document).ready(function() {
        KTCalendarBasic.init();

        $("#create_record_modal").on('show.bs.modal', function(e) {
            //get data-id attribute of the clicked element
            var mydata = $(e.relatedTarget).data('mydata');
            console.log(mydata);
            //console.log("mydata", mydata)
            if (mydata != null) {
                $("#modelTitle").html("Update");



                $("select[name='user_id']").val(mydata['customer_id'])
                $("input[name='title']").val(mydata['title'])
                $("input[name='description']").val(mydata['description'])
                $("input[name='date']").val(mydata['apptDate'])
                $("input[name='apptTime']").val(mydata['apptTime'])
                $("input[name='endTime']").val(mydata['endTime'])
                populateColor(mydata['color'])

                $("input[name='actionId']").val(mydata['id'])



            } else {
                $("#modelTitle").html("Insert");
                $("select[name='user_id']").val("")
                $("input[name='title']").val("")
                $("input[name='description']").val("")
                // $("input[name='date']").val("")
                // $("input[name='apptTime']").val("")
                // $("input[name='endTime']").val("")

                $("input[name='actionId']").val("")

            }


        });
        
        
        const colorDivs = $('.color');
        const colorForm = $('#color-form');
        const selectedColorInput = $('#selected-color');
    
        colorDivs.click(function() {
            colorDivs.removeClass('selected'); // Remove selected class from all colors
            $(this).addClass('selected'); // Add selected class to the clicked color
    
            const selectedColor = $(this).data('color');
            selectedColorInput.val(selectedColor);
        });
        
        
    });



    <? if (false) { ?>
        $(".date-mask").inputmask({
            mask: '99-99-9999',
            placeholder: ' ',
            showMaskOnHover: false,
            showMaskOnFocus: false,
            onBeforePaste: function(pastedValue, opts) {
                var processedValue = pastedValue;

                //do something with it

                return processedValue;
            }
        });
        $(".date-masktime").inputmask({
            mask: '99:99',
            placeholder: ' ',
            showMaskOnHover: false,
            showMaskOnFocus: false,
            onBeforePaste: function(pastedValue, opts) {
                var processedValue = pastedValue;

                //do something with it

                return processedValue;
            }
        });
    <? } ?>
</script>


</html>