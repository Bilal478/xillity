<? require("./global.php");

if (!checkGlobalPermission('enableCustomerManagement')) {
	header("Location: ./home.php?m=Oops! Error occured");
}

$primaryTableName = "Pricing";

$login_fields_hidden = "";
if (!checkGlobalPermission('enableCustomerToLogin')) {
	$login_fields_hidden = "hidden";
}

if(isset($_GET['pricing'])){
    $p_id=  $_GET['pricing'];
    $p_title=  $pricing[$p_id]['title'];
    
    // $stmt = $con->prepare("update ".$g_projectSlug."_users set subscription_id=? where id=?");
    // $stmt->bind_param("ss",$p_id, $session_userId);
    // if($stmt->execute()){header("Location: ./pricing.php?m=You Can Get ".$p_title." Subscription Plan");}

    $price = $pricing[$p_id]['price'];
    $_SESSION['buy_plan_number'] = $p_id;
    $_SESSION['buy_plan_number_type'] = "month";
    if(isset($_GET['yearly'])){
        $price = $pricing[$p_id]['price_yearly'];
        $_SESSION['buy_plan_number_type'] = "year";
    }
    
    
    header("Location: ./payment.php?pay_amount=$price&invoiceId=buy_plan");
    
    $p_title=  $pricing[$p_]['title'];
    exit();
}
?>
<!DOCTYPE html>


<html lang="en">

	<!-- begin::Head -->
	<head><?require("./includes/views/head.php")?>

    <style>
    .card {
      border:none;
      padding: 10px 50px;
    }

    .card::after {
      position: absolute;
      z-index: -1;
      opacity: 0;
      -webkit-transition: all 0.6s cubic-bezier(0.165, 0.84, 0.44, 1);
      transition: all 0.6s cubic-bezier(0.165, 0.84, 0.44, 1);
    }

    .card:hover {


      transform: scale(1.02, 1.02);
      -webkit-transform: scale(1.02, 1.02);
      backface-visibility: hidden; 
      will-change: transform;
      box-shadow: 0 1rem 3rem rgba(0,0,0,.75) !important;
    }

    .card:hover::after {
      opacity: 1;
    }

    .card:hover .btn-outline-primary{
      color:white;
      background:#007bff;
    }

  </style>

	</head>

	<!-- end::Head -->

	<!-- begin::Body -->
	<body class="<?echo $g_body_class?>" onload="">

		<?require("./includes/views/header.php")?>
        
        	<div class="kt-grid kt-grid--hor kt-grid--root">
			<div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--ver kt-page">
				<div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-wrapper" id="kt_wrapper">

					<!-- begin:: Header -->
					
                    <?require("./includes/views/topmenu.php")?>
					<!-- end:: Header -->

					<!-- begin:: Aside -->
					<?require("./includes/views/leftmenu.php")?>

					<!-- end:: Aside -->
					<div class="kt-body kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-grid--stretch" id="kt_body">
						<div class="kt-content  kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor" id="kt_content">

        							<!-- end:: Subheader -->
                                <div class="kt-container">
                                </div>
							<!-- begin:: Content -->
							<div class="kt-container  kt-grid__item kt-grid__item--fluid">

							    <?if(isset($_GET['m'])){?>
							        <div class="alert alert-info"><?echo $_GET['m']?></div>
							    <?}?>
                                
							    <?if($msg!=""){?>
							        <div class="alert alert-info"><?echo $msg?></div>
							    <?}?>
						      
						        <? if ($session_role != "admin" && $session_userId!=$_SESSION['user_original_id'] && $_SESSION['user_original_id']!="") { ?>
                                    <a href="./home.php?access_account=<?echo $_SESSION['user_original_id'];?>&nosetorg=1" class="alert alert-info" style="background: #1ad91a;">Click here to return to your account</a>
                                <? } ?>
						        
							    <div class="alert alert-outline-info">
							        
							       Get your Subscription Plan

							    </div>

                                <div class="container-fluid bg-primary">
    <div class="container p-5">
    <div class="pt-4 pl-4 kt-font-light">
                                                        <h1>Transparent & Simple Pricing </h1>
                                                        <h4>Current Plan: <?echo $pricing[$session_subscription_id]['title']?></h4>
                                                    </div>
      <div class="row">
      <?foreach($pricing as $i=>$val){?>
        <div class="col-lg-4 col-md-12 mb-4">
          <div class="card h-100 shadow-lg">
            <div class="card-body">
              <div class="text-center p-3">
                <h5 class="card-title"> <?php
        																echo $pricing[$i]['title'];
                                                                       ?></h5>
                <br><br>
                <span class="h2">£<?echo $pricing[$i]['price']?></span>/month
                <br>OR<br>
                <span class="h6">£<?echo $pricing[$i]['price_yearly']?></span>/year
                <br><br>
              </div>
            </div>
            <ul class="list-group list-group-flush">
              <li class="list-group-item"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check" viewBox="0 0 16 16">
                <path d="M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425a.267.267 0 0 1 .02-.022z"/>
              </svg> Number of Users:
                                                               <? echo $pricing[$i]['nos_of_employee'];?></li>
              <li class="list-group-item"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check" viewBox="0 0 16 16">
                <path d="M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425a.267.267 0 0 1 .02-.022z"/>
              </svg>  Number of Clients:
                                                               <? echo $pricing[$i]['no_of_clients'];?></li>
              <li class="list-group-item"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check" viewBox="0 0 16 16">
                <path d="M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425a.267.267 0 0 1 .02-.022z"/>
              </svg>  Appointments:
                                                                       <? if( $pricing[$i]['appointments']==10000){
                                                                            echo "Unlimited";
                                                                       }else{echo $pricing[$i]['appointments']." Per Month";}?>   </li>
                                                                       <li class="list-group-item"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check" viewBox="0 0 16 16">
                <path d="M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425a.267.267 0 0 1 .02-.022z"/>
              </svg>   Invoices:
                                                               <? if( $pricing[$i]['invoices']==10000){
                                                                            echo "Unlimited";
                                                                       }else{echo $pricing[$i]['invoices']." Per Month";}?>   </li>
                                                                       <li class="list-group-item"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check" viewBox="0 0 16 16">
                <path d="M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425a.267.267 0 0 1 .02-.022z"/>
              </svg>  Messages :   
                                                               <? if( $pricing[$i]['message']==10000){
                                                                            echo "Unlimited";
                                                                       }else{echo $pricing[$i]['message']." ";}?>      </li>
                      <?if($pricing[$i]['title']=="Professional"||$pricing[$i]['title']=="Agency"){?>
                      <li class="list-group-item"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check" viewBox="0 0 16 16">
                <path d="M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425a.267.267 0 0 1 .02-.022z"/>
              </svg>  
                                                                
                                                                Payment integration 
                                                                  </li><?}?>
                                                                <?if($pricing[$i]['title']=="Agency"){?>
                      <li class="list-group-item"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check" viewBox="0 0 16 16">
                <path d="M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425a.267.267 0 0 1 .02-.022z"/>
              </svg>  
              Learning management system   </li><?}?>
                                                                <?if($pricing[$i]['title']=="Agency"){?>
                      <li class="list-group-item"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check" viewBox="0 0 16 16">
                <path d="M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425a.267.267 0 0 1 .02-.022z"/>
              </svg>  
                                                                
              Shop integration  </li><?}?>
            </ul>
            <div class="card-body text-center">
                <a href="./pricing.php?pricing=<?echo $i;?>" class="btn btn-outline-primary " >Select Monthly</a>
                
                <br><br>
                <a href="./pricing.php?pricing=<?echo $i;?>&yearly=1" class=" " >Select Yearly</a>
              
            </div>
          </div>
        </div>
        <?}?>
    </div>						    
							           

							

							<!-- end:: Content -->
						</div>
					</div>

					<!-- begin:: Footer -->
					
					<?require("./includes/views/footer.php")?>

					<!-- end:: Footer -->
				</div>
			</div>
		</div>
        
        
        <?require("./includes/views/footerjs.php")?>
		

	</body>

	<!-- end::Body -->

</html>