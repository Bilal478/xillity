<?require("./global.php");


/*start: getReferrals */
$getReferrals_Sql = "select * from ".$g_projectSlug."_users WHERE `userId`='".$session_userId."' and usernumber='referral' order by timeAdded desc";
$getReferrals = getAll($con,$getReferrals_Sql);
/*end: getReferrals*/
?>
<!DOCTYPE html>


<html lang="en">
	
	<!-- begin::Head -->
	<head><?require("./includes/views/head.php")?>
	<link rel="stylesheet" href="article-editor.min.css" />
	<style type="text/css">
		i.rightIcon{
			font-size: 16px;
			margin-top: 8px;
			cursor: pointer;
		}
	</style>
</head>

	<!-- end::Head -->

	<!-- begin::Body -->
	<body class="<?echo $g_body_class?>">

		<?require("./includes/views/header.php")?>
        
        	<div class="kt-grid kt-grid--hor kt-grid--root">
			<div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--ver kt-page">
				<div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-wrapper" id="kt_wrapper">

					<!-- begin:: Header -->
					
                    <?require("./includes/views/topmenu.php")?>
					<!-- end:: Header -->

					<!-- begin:: Aside -->
					<?require("./includes/views/leftmenu.php")?>

					<!-- end:: Aside -->
					<div class="kt-body kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-grid--stretch" id="kt_body">
						<div class="kt-content  kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor" id="kt_content">

							<!-- end:: Subheader -->

							<!-- begin:: Content -->
							<div class="kt-container  kt-grid__item kt-grid__item--fluid">
							    
							    <div class="alert alert-outline-info">
							    	<div class="row w-100">
    							    	<div class="col-md-11"><strong>Refrral Link: </strong> <p class="mb-0" id="referralLink"><?php echo $g_website.'/signup.php?_ref='.$session_userId ?></p> </div>
    							    	<div class="col-md-1 text-right"><i onclick="copyToClipboard('#referralLink')" class="far fa-copy rightIcon"></i></div>
    							    </div>
							    </div>
							
								<div class="kt-portlet kt-portlet--mobile">
									<div class="kt-portlet__head kt-portlet__head--lg">
										<div class="kt-portlet__head-label">
											<span class="kt-portlet__head-icon">
											</span>
											<h3 class="kt-portlet__head-title">
												Referrals
											</h3>
										</div>
										<div class="kt-portlet__head-toolbar">
											<div class="kt-portlet__head-wrapper">
												<div class="kt-portlet__head-actions">
												    		
												</div>
											</div>
										</div>
									</div>
									
									<div class="kt-portlet__body">

										<!--begin: Datatable -->
										<table class="table table-striped- table-bordered table-hover table-checkable add-search" id="kt_table_1">
											<thead>
												<tr>
													<th>Sr. no.</th>
													<th>Username</th>
													<th>Date</th>
												</tr>
											</thead>
											<tbody>
											    <?
											    
											    foreach ($getReferrals as $key => $refUser) {
											    ?>
												<tr>
													<td><?echo ($key+1);?></td>
													
													<td><?echo $refUser['name']?></td>
													<td><?echo date("M d, Y h:i A",strtotime($refUser['referral_at'])); ?></td>
												</tr>
												<?}?>
												
											</tbody>
										</table>

										<!--end: Datatable -->
									</div>
								</div>
							</div>

							
							

							<!-- end:: Content -->
						</div>
					</div>

					<!-- begin:: Footer -->
					
					<?require("./includes/views/footer.php")?>

					<!-- end:: Footer -->
				</div>
			</div>
		</div>
        
        
        <?require("./includes/views/footerjs.php")?>
		

	</body>

	<!-- end::Body -->
	
	<div class="modal fade" id="create_record_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="modelTitle">Add Request</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					</button>
				</div>
				<div class="modal-body">
					
					<form class="kt-form" action="" method="Post" enctype="multipart/form-data">
						<div class="kt-portlet__body">
						    <div class="form-group">
								<label>Title</label>
								<input type="text" name="title" class="form-control" required>
							</div>
							<div class="form-group">
								<label>Description</label>
								<textarea type="text" name="description" class="form-control" required></textarea>
							</div>
							<div class="form-group">
								<label>Budget</label>
								<input type="number" min=0 name="budget" class="form-control" required>
							</div>
							<div class="form-group">
								<label>Deadline (Number of days.)</label>
								<input type="number" name="deadline" min=0 class="form-control" required>
							</div>
						    
						   
							<input type="text" name="actionId" value="" hidden>
							
						</div>
						<div class="kt-portlet__foot">
							<div class="kt-form__actions">
								<input type="submit" name="create_package" value="Submit" class="btn btn-primary">
								<button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
							</div>
						</div>
					</form>
				</div>
			
			</div>
		</div>
	</div>
	
	
	<script>
		
	    $(document).ready(function(){
	    
          $("#create_record_modal").on('show.bs.modal', function (e) {
            //get data-id attribute of the clicked element
            var mydata = $(e.relatedTarget).data('mydata');
            console.log(mydata);
            console.log("mydata", mydata)
            if(mydata!= null){
            	$("#modelTitle").html("Update");
                $("input[name='title']").val(mydata['title'])
                $("textarea[name='description']").val(mydata['title'])
                $("input[name='deadline']").val(mydata['title'])
                $("input[name='budget']").val(mydata['title'])

                $("input[name='actionId']").val(mydata['id'])

                // var opt = $(e.relatedTarget).data("subs");

            }else{
            	$("#modelTitle").html("Insert");
                $("input[name='title']").val("")
                $("textarea[name='description']").val("")
                $("input[name='deadline']").val("")
                $("input[name='budget']").val("")
                $("select").val("")
                $("input[name='actionId']").val("")
                
            }

            
          });
	    })
	</script>
				
				
<!-- call -->
<script>
	function copyToClipboard(element) {
		var $temp = $("<input>");
		$("body").append($temp);
		$temp.val($(element).text()).select();
		document.execCommand("copy");
		$temp.remove();
	}

</script>				
								
</html>