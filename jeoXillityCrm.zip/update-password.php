<?require("./global.php");?>
<!DOCTYPE html>

<html lang="en" data-menu="vertical" data-nav-size="nav-default">

<head>


<?include("./includes/views/head2.php");?>

</head>

<body>

    <!-- preloader start -->

    <div class="preloader d-none">

        <div class="loader">

            <span></span>

            <span></span>

            <span></span>

        </div>

    </div>

    <!-- preloader end -->



    <!-- theme color hidden button -->

    <button class="header-btn theme-color-btn d-none"><i class="fa-light fa-sun-bright"></i></button>

    <!-- theme color hidden button -->



    <!-- main content start -->

    <div class="main-content login-panel">

        <div class="login-body">

            <div class="top d-flex justify-content-between align-items-center">

                <div class="logo">

                    <img src="assets/images/logo-big.png" alt="Logo">

                </div>

                <a href="index.html"><i class="fa-duotone fa-house-chimney"></i></a>

            </div>

            <div class="bottom">

                <h3 class="panel-title">Update Password</h3>

                <form>

                    <div class="input-group mb-25">

                        <span class="input-group-text"><i class="fa-regular fa-lock"></i></span>

                        <input type="password" class="form-control" placeholder="New Password">

                    </div>

                    <div class="input-group mb-25">

                        <span class="input-group-text"><i class="fa-regular fa-lock"></i></span>

                        <input type="password" class="form-control" placeholder="Confirm New Password">

                    </div>

                    <button class="btn btn-primary w-100 login-btn">Update Password</button>

                </form>

            </div>

        </div>



        <!-- footer start -->

        <div class="footer">

            <p>Copyright© <script>document.write(new Date().getFullYear())</script> All Rights Reserved By <span class="text-primary">xillity</span></p>

        </div>

        <!-- footer end -->

    </div>

    <!-- main content end -->

    

    <?include("./includes/views/footerjs.php"); ?>

</body>

</html>