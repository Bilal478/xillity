<?include_once("global.php");
if(isset($_GET['logout'])){
    $_SESSION['email'] = "";
    $_SESSION['password'] = "";
    header("Location: ./?");
}

$g_modules_global['enable2fa'] = false;

if(isset($_POST['login_code'])){
    $code= $_POST['login_code'];
}

//send_verification_email //forget password
if(isset($_POST['send_verification_email'])){
    $email = mb_htmlentities(($_POST['email']));
    // Remove all illegal characters from email
    $email = filter_var($email, FILTER_SANITIZE_EMAIL);
    
    $userId = 1;
    $rand = generateRandomString(20);
    $time = time();
    // echo "data"."-".$rand."-".$time."-".$email."-";
    
    //remove previous links
    
    $stmt = $con->prepare("update ".$g_projectSlug."_password_resets set resetlinktimestamp=0 where email=?");
    $stmt->bind_param("s", $email);
    if($stmt->execute())
    {}
    
    
    $stmt = $con->prepare("insert into ".$g_projectSlug."_password_resets set passwordResetId=?, resetlinktimestamp=?, email=?, userId=?");
    $stmt->bind_param("ssss", $rand, $time, $email, $userId);
    if($stmt->execute())
    {
        // echo "entry inserted to ".$g_projectSlug."_password_resets";
        
        
        $query = ("select * from ".$g_projectSlug."_users where email='$email'");
        $result = $con->query($query);
        if ($result->num_rows > 0){
            while($row = $result->fetch_assoc()) 
            {
                
                $id = $row['id'];
                $passwordLink = $g_website."/password_reset.php?id=$rand";
                $password_org = "<a href='$passwordLink'>$passwordLink</a>";
                // sendEmailNotification_sendgrid("Reset Password", "Reset your password here.", $email, [$passwordLink, "Reset Password"]);
                sendEmailNotification_mailjet("Reset Password", "Reset your password here: $password_org", $email);
                // echo "email sent 1";
                header("Location: ?success=1111");
                            ?>
            <!--<script>window.location="?success=1"</script>-->
            <?
            }
        }
        
    
        
    }else{
        // echo "error: ".$g_projectSlug."_password_resets not inserted";
        echo $stmt->error;
    }
    
    
    
    
                
}



if(isset($_POST['password_reset'])){
    $id = mb_htmlentities(($_GET['id']));
    $password = mb_htmlentities(($_POST['password']));
    $password0 = mb_htmlentities( md5(md5(sha1( $_POST['password'])).'Anomoz')); 
    if($_POST['password']==$_POST['password1']){
        $password = mb_htmlentities( md5(md5(sha1( $_POST['password'])).'Anomoz')); 
        
        $stmt = getAll($con, "select r.resetlinktimestamp, u.id, u.password, u.email from ".$g_projectSlug."_password_resets r inner join ".$g_projectSlug."_users u on r.email=u.email where r.passwordResetId='$id'");
        foreach ($stmt as $row ) {
            $resetlinktimestamp = $row['resetlinktimestamp'];
            $password_old = $row['password'];
            $email = $row['email'];
            $id = $row['id'];
        
        }
       
    
        if( true){
            $stmt = $con->prepare("update ".$g_projectSlug."_users set password=? where id=?");
            $stmt->bind_param("ss", $password, $id);
            if(!$stmt->execute())
            {
                die('bind_param() failed: ' . htmlspecialchars($stmt->error));
                echo "err";
                exit();
            }else{
                sendEmailNotification_mailjet("Password changed", "Your account password has been changed successfully.", $email);
                
                header("location: ./?success=1");
                ?>
                <script>window.location="settings.php?err=true"</script>
                <?
            }
        }
        
                
    }
    else{
        header("location: ./?success=0");
        ?>
        <script>window.location="./settings.php?err=false"</script>
        <?
    }
}

// var_dump($_POST);
if(isset($_POST['login'])){
    
    $email = mb_htmlentities(($_POST['email']));
    $password = mb_htmlentities( md5(md5(sha1( $_POST['password'])).'Anomoz')); 
    $query= "select * from ".$g_projectSlug."_users where email='$email' and password='$password'"; 
    $result = $con->query($query);
    
    if($result->num_rows>0){
        
        while($row = $result->fetch_assoc()) { 
            $query= "UPDATE ".$g_projectSlug."_users SET login_status='Active' WHERE id='{$row['id']}'"; 
            $result = $con->query($query);
            
            $_SESSION['email'] = $row['email'];
            $_SESSION['password'] = $row['password'];
            $country = (ip_info("Visitor", "country", true));
            $city = (ip_info("Visitor", "city", true));
            $address = "$city, $country";
            
            if($address==""){$address=="--";}
        
            $_SESSION['location'] = $address;
            
            // echo "g_enable2fa: $g_modules_global['enable2fa'] ";exit();
            if ($g_modules_global['enable2fa']) {
                $code = rand(1000, 9999);
                $sql = "update ".$g_projectSlug."_users set loginAuth='$code' where email='$email' ";
                if (!mysqli_query($con, $sql)) {
                    echo "can not 1";
                }
            }
    
            if (!isset($_GET['redir'])) {
                $_GET['redir'] = "./home.php?";
            }
    
    
          if ($g_modules_global['enable2fa']) {
            $email_body = "$code is your login code.";
            sendEmailNotification_mailjet("Login code", $email_body, $email);
          }
    
          if (!$g_modules_global['enable2fa']) {
            $_SESSION['loginAuthCorrect'] = true;
            header("Location: " . ($_GET['redir'] . "$err"));
          }
    
          $_SESSION['loginAuth'] = $code;
          header("Location: ?code=1&redir=" . urlencode($_GET['redir'] . "$err"));exit();
        }
    }else{
        header("Location: ?err=failed");exit();
    }
}

if(isset($_GET['user_account'])){
    $name = mb_htmlentities(($_GET['user_account']));
    $query= "select * from ".$g_projectSlug."_users where id='$name'"; 
    $result = $con->query($query);
    while($row = $result->fetch_assoc()) 
    { 
        $_SESSION['email'] = $row['email'];
        $_SESSION['password'] = $row['password'];
        header("Location: ?");exit();
    }
}


if(isset($_POST['create_user'])){
    $name = mb_htmlentities(($_POST['name']));
    $name = preg_replace('/[^a-zA-ZÀ-ÿ \-]/', '', $name);
    
    $email = mb_htmlentities(($_POST['email']));
    $email = filter_var($email, FILTER_SANITIZE_EMAIL);
    
    $phone = mb_htmlentities(($_POST['phone']));
    $phone = preg_replace('/[^(0-9.+ \-)]/', '', $phone);
    
    $company = mb_htmlentities(($_POST['company']));
    
    $actionId = mb_htmlentities(($_POST['actionId']));
    

    $businessName = mb_htmlentities(($_POST['businessName']));
    $mobilePhone = mb_htmlentities(($_POST['mobilePhone']));
    $address = mb_htmlentities(($_POST['address']));
    $city = mb_htmlentities(($_POST['city']));
    $state = mb_htmlentities(($_POST['state']));
    $zip = mb_htmlentities(($_POST['zip']));
    $website = mb_htmlentities(($_POST['website']));
    $company = mb_htmlentities(($_POST['company']));
    $homePhone = mb_htmlentities(($_POST['homePhone']));
    $userId = mb_htmlentities(($_POST['userId']));
    $usernumber = mb_htmlentities(($_POST['usernumber']));
    $username = mb_htmlentities(($_POST['username']));
    
    
    $id = generateRandomString();
    $rand = generateRandomString(20);
    
    
    $actionId = mb_htmlentities($_POST['actionId']);
    $password = mb_htmlentities( md5(md5(sha1( $_POST['password'])).'Anomoz')); 
    
    if($actionId==""){
        
        $role = 'user';
        $lang = "EN";
        $time = time();
        
        if($actionId==""){
            $query = "insert into ".$g_projectSlug."_users set id='$id', name='$name', email='$email', phone='$phone', password='$password', username='$username',
            businessName='$businessName', mobilePhone='$mobilePhone', homePhone='$homePhone', address='$address', city='$city', state='$state', zip='$zip', 
            website='$website', company='$company', role='$role', userId='$userId', usernumber='$usernumber', timeAdded='$time';";
            // echo $query;
            $stmt = $con->prepare($query);
            if(!$stmt->execute())
            {
                header("Location: ?m=Account creation failed. Email is already in use!");exit();
            }else{
                
            //   $_SESSION['id'] = $id;
                $query= "UPDATE ".$g_projectSlug."_users SET login_status='Active' WHERE id='$id'"; 
                $result = $con->query($query);

               $_SESSION['email'] = $email;
               $_SESSION['password'] = $password;
               header("Location: ./home.php?m=Welcome! Your account was created successfully!");exit();
            }
        }else{
            
            
        }
    }else{
        //update
        
            
    }
    
}




if(isset($_GET['allowAccess'])){
    $id = $_GET['allowAccess'];
    $sql="update ".$g_projectSlug."_users set isAllowed='yes' where id='$id'";
    if(!mysqli_query($con,$sql)){echo "err";}
}


if(isset($_GET['delete-record'])){
    $id = $_GET['delete-record'];
    if($id!="admin"){
        $sql="delete from ".$g_projectSlug."_users where id='$id'";
        if(!mysqli_query($con,$sql)){echo "err";}
    }
}



if(isset($_POST['save_settings'])){
    $name = mb_htmlentities(($_POST['name']));
    $email = mb_htmlentities(($_POST['email']));

    $phone = mb_htmlentities(($_POST['phone']));
    $location=mb_htmlentities(($_POST['location']));
    $post=mb_htmlentities(($_POST['post']));
    $file_name=htmlspecialchars( basename( $_FILES["fileToUpload"]["name"]));
    $profile_pic=mb_htmlentities($file_name);
    $description=mb_htmlentities(($_POST['description']));
    
    if(isset($_FILES["fileToUpload"])){
        $profile_pic = storeFile($_FILES['fileToUpload']); 
        $sql="update ".$g_projectSlug."_users set profile_pic='$profile_pic' where id='$session_userId'";
        if(!mysqli_query($con,$sql))
        {
            echo "err";
            
        }
    }
    
    
   
    $sql="update ".$g_projectSlug."_users set name='$name', email='$email',  phone='$phone' , location='$location', post='$post' where id='$session_userId'";
    //echo $sql;
    if(!mysqli_query($con,$sql))
    {
        echo "err";
    }else{
        header("Location:?success=12&m=Your account settings was updated successfully");exit();
    }
    
}


if(isset($_POST['password0'])){

    $password0 = mb_htmlentities( md5(md5(sha1( $_POST['password0'])).'Anomoz'));
    $password = mb_htmlentities( md5(md5(sha1( $_POST['password'])).'Anomoz'));
    if($password0==$session_password){
        $sql="update ".$g_projectSlug."_users set password='$password' where id='$session_userId'";
        if(!mysqli_query($con,$sql))
        {
            echo "err";
        }else{
            $_SESSION['password'] = $password;
            header("Location:?success=1&m=Your password was updated successfully");exit();
        }
    }else{
        header("Location:?m=Passwords don't match. Please try again.");exit();
    }
    
}

?>